<?php 


include("mpdf/mpdf.php");

$mpdf=new mPDF('c','A4','16','' , 0 , 0 , 0 , 0 , 0 , 0); 
 
$mpdf->SetDisplayMode('fullpage');
 
$mpdf->list_indent_first_level = 0;  // 1 or 0 - whether to indent the first level of a list

$dataResult='<h1>hello</h1>';
			
//print_r($data);
$mpdf->WriteHTML($dataResult);
$mpdf->Output();
$mpdf->Output('MyPDF.pdf', 'D');

?>