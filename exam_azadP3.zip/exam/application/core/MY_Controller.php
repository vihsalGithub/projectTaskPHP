<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {

	 function __construct(){
		parent::__construct();
		$this->load->model('my_model');
		 
	}  

	public function test_input($data) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}

	public function logout()
	{
		session_destroy();
		$this->session->sess_destroy();
		redirect('home');
	}

}
?>