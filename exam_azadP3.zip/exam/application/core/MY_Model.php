<?php
class My_Model extends CI_Model {

	
	
	public function checkpostinput($index) {
        $return = $this->input->post($index);
        $return = $this->security->xss_clean($return);
        return trim($return);
    }

    public function valid_email($str) {
	return (!preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $str)) ? FALSE : TRUE;
	}

	public function valid_mobile($str) {
	return (!preg_match("/^(\+\d{1,3}[- ]?)?\d{10}$/", $str)) ? FALSE : TRUE;
	}

    public function user_session_create($userId)
	{
		$userData = $this->db->select('*')->from(USERS)->where('user_id',$userId)->get()->row();
		  	$user_id = base64_encode($userData->user_id);
            $first_name = $userData->first_name;
            $last_name = $userData->last_name;
            $email = $userData->email;
            $type = $userData->type;
            $status = $userData->status;
			$session = array(
                    'user_id' => $user_id,
                    'token' => $user_id ,
                    'status' => $status ,
                    'user_name' => $first_name . " " . $last_name,
                    'email' => $email,
                    'logintype' => "user",
                    'logged_in' => true,

            );
         	$this->session->set_userdata($session);
	}

	public function user_session_check() {
        if ($this->session->userdata('token') && $this->session->userdata('user_name') && $this->session->userdata('email') && $this->session->userdata('logintype')) {
            $token = $this->session->userdata('token');
            $user_name = $this->session->userdata('user_name');
            $logintype = $this->session->userdata('logintype');
            $email = $this->session->userdata('email');
            if (trim($logintype) == "user" && trim($user_name) != "" && trim($token) != "" && trim($email) != "") {
                return 1;
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    }
	
	public function user_data($email,$contact_no,$username,$where=''){
		if(!empty($where)){
			$data = $this->db->select('*')->from('users')->where($where)->get()->result();
		}else{
			$data = $this->db->select('*')->from('users')->get()->result();
		}
		return $data ;
	}
	

	public function loggedInUser(){
		if(!empty($_SESSION['user_id'])){
			$userId = base64_decode($_SESSION['user_id']);
			$data = $data = $this->db->select('*')->from('users')->where(array('user_id' => $userId ))->get()->row();
		}else{
			 $data = '';
		}
		
		return $data ;
		//return $this->db->last_query();
	}

	
	
	/* insert Data in table */
	public function insertData($table,$insertdata){
		
		//print_r($insertdata); die;
		$insertUserData = $this->db->insert($table,$insertdata);
		 $count = $this->db->insert_id();
		 if($count >0 ){
				$userId = $this->db->insert_id() ;
				$data['status'] = TRUE;
				$data['last_id'] = $userId;
				$data['message'] = "paper added.";
				return $data ;
		}else{
				$data['status'] = false;
				$data['message'] = "Something went wrong for registration.";
				return $data ;
		}
	}	
	
	/* get Single Data in table */
	public function getSingeleTable($table){

		$data = $this->db->select('*')->from($table)->get()->result();
		return $data ;
	}

	/* get Single Row in table */
	public function getSingeleRow($table,$wherecolumn,$id){
		$where  = array($wherecolumn => $id );
		$data = $this->db->select('*')->from($table)->where($where)->get()->row();
		return $data ;
	}
	
	public function getSingeleRow2cond($table,$wherecolumn1,$id1,$wherecolumn2,$id2){
		$where  = array($wherecolumn1 => $id1 ,$wherecolumn2 => $id2 );
		$data = $this->db->select('*')->from($table)->where($where)->get()->row();
		return $data ;
	}

	/*********"All Data With OrderBy"**********/
	public function getFilterTableOrderBy($table,$orderByclm, $value){
		$data = $this->db->select('*')->from($table)->order_by($orderByclm,$value)->get()->result();
		return $data ;
	}
	
	
	public function getFilterTable($table,$selectcolumn='',$wherecolumn, $id){

		 if(empty($selectcolumn)){
		 	$selectcolumn1 = '*' ;
		 }else{
			 $selectcolumn1 = array($selectcolumn);
		 }
		 $where  = array($wherecolumn => $id );
		$data = $this->db->select($selectcolumn1)->from($table)->where($where)->order_by($id,'desc')->get()->result();
		return $data ;
	}

	/*********"array in"**********/
	public function getFilterTableWithIn($table,$filtercol,$column,$array){
		//$where  = array($array );
		if(empty($filtercol)){
			$filtercol = '*';
		}
		$data = $this->db->select($filtercol)->from($table)->where_in($column ,$array)->get()->result();
		return $data ;
	}
	/*********"Group And Order by"**********/
	
	public function getGroupByTableGvnId($table,$where='',$groupByClm,$orderBy,$orderByClm){
		if(empty($where)){
			$data = $this->db->select('*')->from($table)->group_by($groupByClm)->order_by($orderBy,$orderByClm)->get()->result();
		}else{
			$data = $this->db->select('*')->from($table)->where($where)->group_by($groupByClm)->order_by($orderBy,$orderByClm)->get()->result();
		}
		return $data ;
	}
	
	
	
	/*********"array in"**********/
	public function getFilterTableWithOrderBy($table,$filtercol,$whereCol,$whereVal,$OrderBy,$value = 'desc'){
		//$where  = array($array );
		if(empty($filtercol)){
			$filtercol = '*';
		}
		$data = $this->db->select($filtercol)->from($table)->where(array($whereCol=>$whereVal))->order_by($OrderBy, $value)->get()->result();
		return $data ;
	}
	
	
	/*********"Order With Limit"**********/
	public function getFilterTableWithOrderByLimit($table,$filtercol,$whereCol,$whereVal,$OrderBy,$value = 'desc',$limit ,$limitStart ){
		//$where  = array($array );
		if(empty($filtercol)){
			$filtercol = '*';
		}
		$data = $this->db->select($filtercol)->from($table)->where(array($whereCol=>$whereVal))->order_by($OrderBy, $value)->limit($limit,$limitStart)->get()->result();
		//return $this->db->last_query() ;
		return $data ;
	}

	public   function getCounteRows($table,$where=''){

		if(empty($where)){
			$query  = $this->db->select('*')->get($table);
		}else{
			$query  = $this->db->select('*')->where($where)->get($table);
		}
		return $query->num_rows();
	}

	public   function updateRow($table,$id,$wherecolumn,$arrayData){	
			
			$this->db->where($wherecolumn , $id);			
			$query = $this->db->update($table, $arrayData);		
		
			if($query){			
			
			return true ;			
			
			}else{				
			
			return false ;		
			
			}	
	}


}