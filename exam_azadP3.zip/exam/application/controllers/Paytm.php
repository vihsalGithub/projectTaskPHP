<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Paytm extends My_Controller {

	
	
	
	public function __construct() {
        parent::__construct();
        $this->load->model("admin_model");
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
    }
	
	public function index()
	{
		$this->load->view('paytm/TxnTest') ;
	}  


	public function paymantRedirect(){
		
		header("Pragma: no-cache");
		header("Cache-Control: no-cache");
		header("Expires: 0");
		// following files need to be included
		require_once("./lib/config_paytm.php");
		require_once("./lib/encdec_paytm.php");

			//echo "vishal";die;
		$checkSum = "";
		$paramList = array();

		$ORDER_ID = $_POST["ORDER_ID"];
		$CUST_ID = $_POST["CUST_ID"];
		$INDUSTRY_TYPE_ID = $_POST["INDUSTRY_TYPE_ID"];
		$CHANNEL_ID = $_POST["CHANNEL_ID"];
		$TXN_AMOUNT = $_POST["TXN_AMOUNT"];

		// Create an array having all required parameters for creating checksum.
		$paramList["MID"] = PAYTM_MERCHANT_MID;
		$paramList["ORDER_ID"] = $ORDER_ID;
		$paramList["CUST_ID"] = $CUST_ID;
		$paramList["INDUSTRY_TYPE_ID"] = $INDUSTRY_TYPE_ID;
		$paramList["CHANNEL_ID"] = $CHANNEL_ID;
		$paramList["TXN_AMOUNT"] = $TXN_AMOUNT;
		$paramList["WEBSITE"] = PAYTM_MERCHANT_WEBSITE;
		$paramList["CALLBACK_URL"] = base_url("/paytm/paymantResponce");
		//$paramList["MSISDN"] = $MSISDN; //Mobile number of customer
		//$paramList["EMAIL"] = $EMAIL; //Email ID of customer
		//$paramList["VERIFIED_BY"] = "EMAIL"; //
		//$paramList["IS_USER_VERIFIED"] = "YES"; //
		$checkSum = getChecksumFromArray($paramList,PAYTM_MERCHANT_KEY);
		  $string = '<html>
						<head>
						<title>Merchant Check Out Page</title>
						</head>
						<body>
							<center><h1>Please do not refresh this page...</h1></center>
								<form method="post" action="'.PAYTM_TXN_URL.'" name="f1">
								<table border="1">
									<tbody>';
									foreach($paramList as $name => $value) {
										$string  .=  '<input type="hidden" name="' . $name .'" value="' . $value . '">';
									}
		  				$string  .= '<input type="hidden" name="'.CHECKSUMHASH.'" value="'.$checkSum.'">
									</tbody>
								</table>
								<script type="text/javascript">
									document.f1.submit();
								</script>
							</form>
						</body>
					</html>';

		$data['formdata'] = $string ;
		echo $string ;
		//$this->load->view('paytm/paymantRedirect',$data) ;
		//echo PAYTM_TXN_URL ;
	}
	public function paymantResponce(){
		header("Pragma: no-cache");
		header("Cache-Control: no-cache");
		header("Expires: 0");

		// following files need to be included
		require_once("./lib/config_paytm.php");
		require_once("./lib/encdec_paytm.php");

		$paytmChecksum = "";
		$paramList = array();
		$isValidChecksum = "FALSE";
		$paramList = $_POST;
		$paytmChecksum = isset($_POST["CHECKSUMHASH"]) ? $_POST["CHECKSUMHASH"] : ""; //Sent by Paytm pg.
		$isValidChecksum = verifychecksum_e($paramList, PAYTM_MERCHANT_KEY, $paytmChecksum); 
		/*if($isValidChecksum == "TRUE") {*/
			 //echo "<b>Checksum matched and following are the transaction details:</b>" . "<br/>";
			if ($_POST["STATUS"] == "TXN_SUCCESS") {
				/*sdmakmsda*/
				$userUpdate = array('status' => 1 ,'payment_status' => 1  );

					$this->db->where('user_id',$_SESSION['user_id']);
					$this->db->update('oe_users',$userUpdate) ;



					$this->db->where('user_id',$_SESSION['reg_user_id']);
					$this->db->update('oe_users',$userUpdate) ;



					$contact_no = $_SESSION['mobile'] ;
					$sms_message = 'ASHG%0AThankyou%20For%20Registration%0A';
					$smsurl ="http://bulk.bulksmsguru.in/sendsms?uname=lakhanpatelhelp&pwd=lakhan2222&senderid=ASHGCT&to=".$contact_no."&msg=".$sms_message."&route=T" ;
				   file_get_contents($smsurl);


				 $user_id = $_SESSION['reg_user_id'];
				 $firstname = $_SESSION['fname'];
				 $email =  $_SESSION['email'];
				$paymentdata = array(
  					'user_id' => $user_id ,
  					'txnid' => $this->input->post('TXNID') ,
  					'amount' =>  $this->input->post('TXNAMOUNT'),
  					'productinfo' => $this->input->post('ORDERID') ,
  					'firstname' => $firstname ,
  					'email' => $email  ,
  					'mihpayid' => $this->input->post('BANKTXNID') ,
  					'status' => $this->input->post('STATUS') ,
  					'hash' => $this->input->post('CHECKSUMHASH') ,
  					'signup_type' => 1 ,
  					'package_type' =>  $_SESSION['pinfo'],
  					 'date' => $this->input->post('TXNDATE'),
  					 'exp_date' => $this->input->post('TXNDATE'),
  				);
				$this->db->insert('payments',$paymentdata);
				$lastid = $this->db->insert_id() ;
				$this->session->set_flashdata('paymantStatus', '<b class="text-success text-center">Thanks You for Login</b>');	
				redirect('exam');

			}
			else {
				session_start();
		  	 	session_destroy();
		 		unset($_SESSION);
				//echo "<b>Transaction status is failure</b>" . "<br/>";
				$this->session->set_flashdata('paymantStatus', '<b class="text-danger text-center">Transaction status is failure</b>');	
				redirect('exam/registration');
			}

			/*if (isset($_POST) && count($_POST)>0 )
			{ 
				foreach($_POST as $paramName => $paramValue) {
						echo "<br/>" . $paramName . " = " . $paramValue;
				}
			}*/
			//print_r($this->input->post()); 
		/*}else {
			session_start();
		  	 	session_destroy();
		 		unset($_SESSION);
			$this->session->set_flashdata('paymantStatus', '<b class="text-danger text-center">Some Thing went Wrong</b>');	
			redirect('exam/registration');
			//echo "<b>Checksum mismatched.</b>";
		}*/
	}


/****************************************************************************************************/

	public function paymantRedirect2(){
		header("Pragma: no-cache");
		header("Cache-Control: no-cache");
		header("Expires: 0");
		require_once("./lib/config_paytm.php");
		require_once("./lib/encdec_paytm.php");
		$checkSum = "";
		$paramList = array();

		$ORDER_ID = $_POST["ORDER_ID"];
		$CUST_ID = $_POST["CUST_ID"];
		$INDUSTRY_TYPE_ID = $_POST["INDUSTRY_TYPE_ID"];
		$CHANNEL_ID = $_POST["CHANNEL_ID"];
		$TXN_AMOUNT = $_POST["TXN_AMOUNT"];
		$paramList["MID"] = PAYTM_MERCHANT_MID;
		$paramList["ORDER_ID"] = $ORDER_ID;
		$paramList["CUST_ID"] = $CUST_ID;
		$paramList["INDUSTRY_TYPE_ID"] = $INDUSTRY_TYPE_ID;
		$paramList["CHANNEL_ID"] = $CHANNEL_ID;
		$paramList["TXN_AMOUNT"] = $TXN_AMOUNT;
		$paramList["WEBSITE"] = PAYTM_MERCHANT_WEBSITE;
		$paramList["CALLBACK_URL"] = base_url("/paytm/paymantResponce2");
		
		$checkSum = getChecksumFromArray($paramList,PAYTM_MERCHANT_KEY);
		  $string = '<html>
						<head>
						<title>Merchant Check Out Page</title>
						</head>
						<body>
							<center><h1>Please do not refresh this page...</h1></center>
								<form method="post" action="'.PAYTM_TXN_URL.'" name="f1">
								<table border="1">
									<tbody>';
									foreach($paramList as $name => $value) {
										$string  .=  '<input type="hidden" name="' . $name .'" value="' . $value . '">';
									}
		  				$string  .= '<input type="hidden" name="'.CHECKSUMHASH.'" value="'.$checkSum.'">
									</tbody>
								</table>
								<script type="text/javascript">
									document.f1.submit();
								</script>
							</form>
						</body>
					</html>';

		$data['formdata'] = $string ;
		echo $string ;
	}
	public function paymantResponce2(){
		header("Pragma: no-cache");
		header("Cache-Control: no-cache");
		header("Expires: 0");

		// following files need to be included
		require_once("./lib/config_paytm.php");
		require_once("./lib/encdec_paytm.php");

		$paytmChecksum = "";
		$paramList = array();
		$isValidChecksum = "FALSE";
		$paramList = $_POST;
		$paytmChecksum = isset($_POST["CHECKSUMHASH"]) ? $_POST["CHECKSUMHASH"] : ""; //Sent by Paytm pg.
		$isValidChecksum = verifychecksum_e($paramList, PAYTM_MERCHANT_KEY, $paytmChecksum); 
			if ($_POST["STATUS"] == "TXN_SUCCESS") {
				/*sdmakmsda*/
				
					$orderid = $this->input->post('ORDERID') ;

					  $arrayData = explode('_', $orderid) ;

					  //rand(10000,99999999).'_'.$this->my_model->checkpostinput('paymentType').'_'.$this->my_model->checkpostinput('userId').'_'.$this->my_model->checkpostinput('regpackage')


					if($arrayData[3] == 1){
            	    	$expiradate = date('d-m-Y', strtotime("+30 days")) ;
            	    	//$amount = '20.00';
            	    }elseif($arrayData[3] == 2){
            	    	$expiradate = date('d-m-Y', strtotime("+60 days")) ;
            	    	//$amount = '40.00';
            	    }elseif($arrayData[3] ==3){
            	    	$expiradate = date('d-m-Y', strtotime("+90 days")) ;
            	    	//$amount = '60.00';
            	    }elseif($arrayData[3] ==4){
            	    	$expiradate = date('d-m-Y', strtotime("+150 days")) ;
            	    	//$amount = '60.00';
            	    }

            	    $package_type =  $arrayData[3] ;
            	    $payment_type = $arrayData[1] ;




				$userUpdate = array('status' => 1 ,'payment_status' => 1,'package_type' =>$package_type,'payment_type' => $payment_type,'exp_date' => $expiradate  );

					


					$this->db->where('user_id',$_SESSION['user_id']);
					$this->db->update('oe_users',$userUpdate) ;



					$this->db->where('user_id',$_SESSION['reg_user_id']);
					$this->db->update('oe_users',$userUpdate) ;



					$contact_no = $_SESSION['mobile'] ;
					$sms_message = 'ASHG%0AThankyou%20For%20Registration%0A';
					$smsurl ="http://bulk.bulksmsguru.in/sendsms?uname=lakhanpatelhelp&pwd=lakhan2222&senderid=ASHGCT&to=".$contact_no."&msg=".$sms_message."&route=T" ;
				   file_get_contents($smsurl);


				 $user_id = $_SESSION['reg_user_id'];
				 $firstname = $_SESSION['fname'];
				 $email =  $_SESSION['email'];
				$paymentdata = array(
  					'user_id' => $user_id ,
  					'txnid' => $this->input->post('TXNID') ,
  					'amount' =>  $this->input->post('TXNAMOUNT'),
  					'productinfo' => $this->input->post('ORDERID') ,
  					'firstname' => $firstname ,
  					'email' => $email  ,
  					'mihpayid' => $this->input->post('BANKTXNID') ,
  					'status' => $this->input->post('STATUS') ,
  					'hash' => $this->input->post('CHECKSUMHASH') ,
  					'signup_type' => 1 ,
  					'package_type' =>  $_SESSION['pinfo'],
  					 'date' => $this->input->post('TXNDATE'),
  					 'exp_date' => $this->input->post('TXNDATE'),
  				);
				$this->db->insert('payments',$paymentdata);
				$lastid = $this->db->insert_id() ;
				$this->session->set_flashdata('paymantStatus', '<b class="text-success text-center">Thanks You for Login</b>');	
				redirect('exam');

			}
			else {
				session_start();
		  	 	session_destroy();
		 		unset($_SESSION);
				//echo "<b>Transaction status is failure</b>" . "<br/>";
				$this->session->set_flashdata('paymantStatus', '<b class="text-danger text-center">Transaction status is failure</b>');	
				redirect('exam');
			}
	}



	public function paytmTest(){
		$html = '<html>
					<head>
					<title>Merchant Check Out Page</title>
					<meta name="GENERATOR" content="Evrsoft First Page">
					</head>
					<body>
						<h1>Merchant Check Out Page</h1>
						<pre>
						</pre>
						<form method="post" action="'.base_url('paytm/paymantRedirect').'">
							<table border="1">
								<tbody>
									<tr>
										<th>S.No</th>
										<th>Label</th>
										<th>Value</th>
									</tr>
									<tr>
										<td>1</td>
										<td><label>ORDER_ID::*</label></td>
										<td><input id="ORDER_ID" tabindex="1" maxlength="20" size="20"
											name="ORDER_ID" autocomplete="off"
											value="'. rand(10000,99999999).'">
										</td>
									</tr>
									<tr>
										<td>2</td>
										<td><label>CUSTID ::*</label></td>
										<td><input id="CUST_ID" tabindex="2" maxlength="12" size="12" name="CUST_ID" autocomplete="off" value="CUST001"></td>
									</tr>
									<tr>
										<td>3</td>
										<td><label>INDUSTRY_TYPE_ID ::*</label></td>
										<td><input id="INDUSTRY_TYPE_ID" tabindex="4" maxlength="12" size="12" name="INDUSTRY_TYPE_ID" autocomplete="off" value="Retail"></td>
									</tr>
									<tr>
										<td>4</td>
										<td><label>Channel ::*</label></td>
										<td><input id="CHANNEL_ID" tabindex="4" maxlength="12"
											size="12" name="CHANNEL_ID" autocomplete="off" value="WEB">
										</td>
									</tr>
									<tr>
										<td>5</td>
										<td><label>txnAmount*</label></td>
										<td><input title="TXN_AMOUNT" tabindex="10"
											type="text" name="TXN_AMOUNT"
											value="1">
										</td>
									</tr>
									<tr>
										<td></td>
										<td></td>
										<td><input value="CheckOut" type="submit"	onclick=""></td>
									</tr>
								</tbody>
							</table>
							* - Mandatory Fields
						</form>
					</body>
					</html>' ;

		 echo $html ;
	}
	
	

}
