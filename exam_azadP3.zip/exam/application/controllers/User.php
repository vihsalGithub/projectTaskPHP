<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends My_Controller {
	
    function __construct(){
		parent::__construct();
		$this->load->model('user_model');
		$this->load->model('my_model');
		 
	}  

	public function index()
	{
		if ($this->my_model->user_session_check()){ 
			$data['userCount']   = $this->my_model->getCounteRows('events');
			$data['userData']   = $this->my_model->loggedInUser();
			$this->load->view('users/header',$data);
			if($this->session->status){ 
				$this->load->view('users/index.php');
			}else{
				$this->load->view('users/userprofile.php',$data);
			}
			$this->load->view('users/footer');
		}else{
			redirect('home');
		} 
	}


	public function userprofile()
	{
		if ($this->my_model->user_session_check()){ 

 			$data['userData']   = $this->my_model->loggedInUser();
			$this->load->view('users/header',$data);
			$this->load->view('users/userprofile.php',$data);
			$this->load->view('users/footer');
		}else{
			redirect('home');
		} 
	}

    public function bloodgroupinfo()
	{
		if ($this->my_model->user_session_check()){ 

 			$data['userData']   = $this->my_model->loggedInUser();
 			$data['bloodDataGroup']   = $this->my_model->getSingeleTable('blood_group');
			$this->load->view('users/header',$data);
			$this->load->view('users/bloodgroupinfo.php',$data);
			$this->load->view('users/footer');
		}else{
			redirect('home');
		} 
	}

	public function profileform()
	{
		
	  $data = $this->user_model->profileform();	
	  if($data){
	  	redirect('user');
	  }else{
	  	redirect('user');
	  }
               
	}

	public function paymentprocess()
	{
	  if($this->my_model->user_session_check()){
	  		$data['userData']   = $this->my_model->loggedInUser();
 			$data['chargeData']   = $this->my_model->getSingeleTable('CHARGES');
			$this->load->view('users/header',$data);
			$this->load->view('users/paymentprocess.php',$data);
			$this->load->view('users/footer');
	  }else{
	  	redirect('user');
	  }
               
	}


	public function library()
	{
	  if($this->my_model->user_session_check()){
	  		$data['userData']   = $this->my_model->loggedInUser();
 			$data['chargeData']   = $this->my_model->getSingeleTable('CHARGES');
			$this->load->view('users/header',$data);
			$this->load->view('users/paymentprocess.php',$data);
			$this->load->view('users/footer');
	  }else{
	  	redirect('user');
	  	base64_encode(data) ;
	  }
               
	}   

	public function events()
	{
	  if($this->my_model->user_session_check()){
	  		$data['userData']   = $this->my_model->loggedInUser();
 			$data['chargeData']   = $this->my_model->getSingeleTable('CHARGES');
			$this->load->view('users/header',$data);
			$this->load->view('users/paymentprocess.php',$data);
			$this->load->view('users/footer');
	  }else{
	  	redirect('user');
	  }
               
	}

	/*stripe*/
	public function stripe_payment(){
		 require 'system/libstripe/Stripe.php';
		 	$cardname = $this->my_model->checkpostinput('cardname');
		 	$cardnumber =$this->my_model->checkpostinput('cardnumber') ;
		 	$exp_month = $this->my_model->checkpostinput('exp_month');
		 	$exp_year = $this->my_model->checkpostinput('exp_year');
		 	$cvv =  $this->my_model->checkpostinput('cardcvv');
		 	$total_amount = $this->my_model->checkpostinput('payamount');

		 	return false ;

		 	   //echo $cardname .'-'.$cardnumber .'-'.$exp_month.'-'.$exp_year.'-'.$cvv.'-'.$total_amount ;
		 	/*$cardname = 'MasterCard';
		 	$cardnumber = '5105105105105100';
		 	$exp_month = '08';
		 	$exp_year = '2020';
		 	$cvv = '1122';
		 	$total_amount = '100';*/
            // Stripe::setApiKey("sk_live_sihVblRp7mWU9Zev2efH13fx");
            /*Stripe::setApiKey("pk_test_9EqtdvTE6zsMt81BGp2R9qcl");
            Stripe::setApiKey("sk_test_MUc3G88Hhk05EtP1GrdDpjIA");*/
            /*Stripe::setApiKey("pk_test_lBXWelMRrHeRF6MI01zyqYo0");
            Stripe::setApiKey("sk_test_I626qCOF1tnyrdCIPvdWxl15");*/

            try {
                $result = Stripe_Token::create(
                                array(
                                    "card" => array(
                                        "name" => $cardname,
                                        "number" => $cardnumber,
                                        "exp_month" => $exp_month,
                                        "exp_year" => $exp_year,
                                        "cvc" => $cvv
                                    )
                                )
                );
                $stripeToken = $result['id'];
            } catch (Stripe_CardError $e) {
                //print_r($e->jsonBody['error']['message']);
                $alerts = json_encode(array(
                    'status' => false,
                    'message' => $e->jsonBody['error']['message'],
                    'data' => '',
                    'txn_success' => false
                ));
            }
            $total =  $total_amount ;
            $paymenetresponse = Stripe_Charge::create(array(
                        "amount" => $total,
                        "currency" => "EUR",
                        "card" => $stripeToken,
                        "description" => "Payment"
            ));
            echo '<pre>';
            print_r($paymenetresponse);die('check');
            echo '<pre>';

}
	/*stripe end*/
}
