<script src="<?php echo base_url() ; ?>/assets//ckeditor/ckeditor.js" type="text/javascript"></script>
<div id="wrapper">
    <?php $this->load->view('admin/sidebar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
          <!-- Breadcrumbs-->
			<?php 
				$this->load->view('admin/test-exammanu.php'); 
					//print_r($OE_TEST_EDITQUES);
			?>
		<?php if($message == 1){ ?>
		      <div class="container">
			<form class="form " action="<?php echo site_url('onlineexam/insertTestQuestion'); ?>" method="post" >
				<div class="row">	
					<div class="col-md-12">
					  <div class="form-group">
						<label class="label-control" for="lname">Question In *</label>
						<textarea type="text"  class="form-control border-primary ckeditor" placeholder="Question in English" name="question" required></textarea> 
					  </div>
                    </div>
					
					<div class="col-md-6">
					  <div class="form-group">
						<label class="label-control" for="lname">Option 1 In English*</label>
						<input type="text"  class="form-control border-primary" placeholder="Option 1 In English" name="opt1" value="" required>
					  </div>
					</div>
					
					<div class="col-md-6">
					  <div class="form-group">
						<label class="label-control" for="lname">Option 2 In English*</label>
						<input type="text" class="form-control border-primary" placeholder="Option 2 In English" name="opt2" value="" required>
					  </div>
					</div>
					
					<div class="col-md-6">
					  <div class="form-group">
						<label class="label-control" for="lname">Option 3 In English*</label>
						<input type="text"  class="form-control border-primary" placeholder="Option 3 In English" name="opt3" value="" required >
					  </div>
					</div>
					
					<div class="col-md-6">
					  <div class="form-group">
						<label class="label-control" for="lname">Option 4 In English*</label>
						<input type="text"   class="form-control border-primary" placeholder="Option 4 In English" name="opt4" value="" required>
					  </div>
					</div>
				    <div class="col-sm-6"> 
						<div class="form-group">
						<label class="control-label col-sm-12" for="answer">Answer *</label>
						 <select class="form-control" required name="answer" id="answer">
							<option value="">Select Ans</option>
							<option  value="1">(option-1)</option>
							<option  value="2">(option-2)</option>
							<option  value="3">(option-3)</option>
							<option  value="4">(option-4)</option>
						  </select>
                      </div>
                    </div>
					
				    <div class="col-sm-6"> 
						<div class="form-group">
						<label class="control-label col-sm-12" for="answer">Question Status *</label>
						 <select class="form-control" required name="qusStatus" id="qusStatus">
							<option value="">Select Ans</option>
							<option  value="1">Active</option>
							<option  value="0">Deactive</option>
						  </select>
                      </div>
                    </div>
					
					<div class="col-sm-6"> 
						<div class="form-group">
						<label class="control-label col-sm-12" for="answer">Select Paper *</label>
						 <select class="form-control" required name="qusPaper" id="qusPaper">
							<option value="">Select Ans</option> 
							<?php foreach($OE_TEST_PAPERS as $key=>$value){?>
							<option  value="<?php echo $value->id ?>"><?php echo $value->ppr_name ?></option>
							<?php } ?>
						  </select>
                      </div>
                    </div>

				<input type="hidden" name="qid" value="<?php echo $OE_TEST_EDITQUES->id ?>" >
				 <div class="col-md-12">
				  <div class="form-group">
					<label class="label-control" for="crewcount"></label></br>
					<input  type="submit" class="btn btn-primary" value="Submit Now" />
				  </div>
				</div>
			     </div>
				</form>
			</div>
		<?php }else{ ?>
			<div class="container">
			<form class="form " action="<?php echo site_url('onlineexam/updateTestQuestion'); ?>" method="post" >
				<div class="row">	
					<div class="col-md-12">
					  <div class="form-group">
						<label class="label-control" for="lname">Question In *</label>
						<textarea type="text"  class="form-control border-primary ckeditor" placeholder="Question in English" name="question" required><?php echo $OE_TEST_EDITQUES->question ?></textarea> 
					  </div>
                    </div>
					
					<div class="col-md-6">
					  <div class="form-group">
						<label class="label-control" for="lname">Option 1 In English*</label>
						<input type="text"  class="form-control border-primary" placeholder="Option 1 In English" name="opt1" value="<?php echo $OE_TEST_EDITQUES->op_1 ?>" required>
					  </div>
					</div>
					
					<div class="col-md-6">
					  <div class="form-group">
						<label class="label-control" for="lname">Option 2 In English*</label>
						<input type="text" class="form-control border-primary" placeholder="Option 2 In English" name="opt2" value="<?php echo $OE_TEST_EDITQUES->op_2 ?>" required>
					  </div>
					</div>
					
					<div class="col-md-6">
					  <div class="form-group">
						<label class="label-control" for="lname">Option 3 In English*</label>
						<input type="text"  class="form-control border-primary" placeholder="Option 3 In English" name="opt3" value="<?php echo $OE_TEST_EDITQUES->op_3 ?>" required >
					  </div>
					</div>
					
					<div class="col-md-6">
					  <div class="form-group">
						<label class="label-control" for="lname">Option 4 In English*</label>
						<input type="text"   class="form-control border-primary" placeholder="Option 4 In English" name="opt4" value="<?php echo $OE_TEST_EDITQUES->op_4 ?>" required>
					  </div>
					</div>
					<?php
					   if($OE_TEST_EDITQUES->ans == 1){
						   $opt1 = 'selected';$opt2 = ""; $opt3 = "";  $opt4 ="";
					   }
					   if($OE_TEST_EDITQUES->ans == 2){
						   $opt1 = '';$opt2 = "selected"; $opt3 = "";  $opt4 ="";
					   }
					   if($OE_TEST_EDITQUES->ans == 3){
						   $opt1 = '';$opt2 = ""; $opt3 = "selected";  $opt4 ="";
					   }
					   if($OE_TEST_EDITQUES->ans == 4){
						   $opt1 = '';$opt2 = ""; $opt3 = "";  $opt4 ="selected";
					   }
					?>
				    <div class="col-sm-6">  
                      <label class="control-label col-sm-12" for="answer">Answer *</label>
                      <div class="form-group"> 
						 <select class="form-control" required name="answer" id="answer">
							<option value="<?php echo $optionValue ?>">Select Ans</option>
							<option <?php echo $opt1 ;?> value="1">(option-1)<?php echo $OE_TEST_EDITQUES->op_1 ?></option>
							<option <?php echo $opt2 ;?> value="2">(option-2)<?php echo $OE_TEST_EDITQUES->op_2 ?></option>
							<option <?php echo $opt3 ;?> value="3">(option-3)<?php echo $OE_TEST_EDITQUES->op_3 ?></option>
							<option <?php echo $opt4 ;?> value="4">(option-4)<?php echo $OE_TEST_EDITQUES->op_4 ?></option>
						  </select>
                      </div>
                    </div>
					
					<?php
					   if($OE_TEST_EDITQUES->ques_status == 1){
						   $status1 = 'selected';$status2 = ""; 
					   }
					   if($OE_TEST_EDITQUES->ques_status == 0){
						   $status1 = '';$status2 = "selected"; 
					   }
					  
					?>
				    <div class="col-sm-6"> 
						<div class="form-group">
						<label class="control-label col-sm-12" for="answer">Question Status *</label>
						 <select class="form-control" required name="qusStatus" id="qusStatus">
							<option value="">Select Ans</option>
							<option   <?php echo $status1 ?>  value="1">Active</option>
							<option  <?php echo $status2 ?>  value="0">Deactive</option>
						  </select>
                      </div>
                    </div>
					
					<div class="col-sm-6"> 
						<div class="form-group">
						<label class="control-label col-sm-12" for="answer">Select Paper *</label>
						 <select class="form-control" required name="qusPaper" id="qusPaper">
							<option value="">Select Ans</option> 
							<?php foreach($OE_TEST_PAPERS as $key=>$value){
									if($value->id == $OE_TEST_EDITQUES->ppr_id){
										$selected = 'selected';
									}else{
										$selected = '';
									}
							?>
							<option  <?php echo $selected ?> value="<?php echo $value->id ?>"><?php echo $value->ppr_name ?></option>
							<?php } ?>
						  </select>
                      </div>
                    </div>

				<input type="hidden" name="qid" value="<?php echo $OE_TEST_EDITQUES->id ?>" >
				 <div class="col-md-12">
				  <div class="form-group">
					<label class="label-control" for="crewcount"></label></br>
					<input  type="submit" class="btn btn-primary" value="Submit Now" />
				  </div>
				</div>
			     </div>
				</form>
			</div>
		<?php } ?>
        </div>
        <!-- Sticky Footer -->
        
		<?php 
			$this->load->view('admin/footer_sticky.php');    
		?>
    </div>
      <!-- /.content-wrapper -->
</div>
<script>
			$(document).ready(function() {
				$("#txtEditor").Editor();
			});
		</script>
    <!-- /#wrapper -->