<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Onlineexam extends My_Controller {

	
	
	
	public function __construct() {
        parent::__construct();
        $this->load->model("Onlineexam_model");
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
    }
	
	
	
	public function index()
	{
		$condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){   
			$data['userData'] = $this->my_model->getSingeleTable(USERS);
			$data['oe_categuty'] = $this->my_model->getSingeleTable(OE_CATEGORY);
			$data['oe_subjects'] = $this->my_model->getSingeleTable(OE_SUBJECT);
			$data['oe_questions'] = $this->my_model->getSingeleTable(OE_QUESTIONS);
			$this->load->view('users/header.php');
			$this->load->view('onlineexam/onlineexam.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
		
	}
/***************************************"category"**********************************/	
	public function category()
	{
		$condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){   
			$data['userData'] = $this->my_model->getSingeleTable(USERS);
			$this->load->view('users/header.php');
			$this->load->view('onlineexam/oe_category.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
		
	}
	
	public function categoryTemp()
	{  
			$data['oe_categuty'] = $this->my_model->getSingeleTable(OE_CATEGORY);
			$temp = $this->load->view('ajaxtemplate/oe_category.php',$data,true);
			echo $temp ;
	}
	
	public function selectcategory()
	{
		$catid = $this->my_model->checkpostinput('catid') ;
		$data = $this->my_model->getSingeleRow(OE_CATEGORY,'id',$catid);
		echo json_encode($data);
		
	}
	
	public function addcategory()
	{
		$catName = $this->my_model->checkpostinput('categoryName') ;
		$catStatus = $this->my_model->checkpostinput('categoryStatus');
		$data = array(
			    'name'  => $catName,
			    'status'  => $catStatus,
		);
		$this->db->insert(OE_CATEGORY,$data);
		//echo $this->db->insert_id() ; die;
		if($this->db->insert_id()){
			$data['oe_categuty'] = $this->my_model->getSingeleTable(OE_CATEGORY);
			$temp = $this->load->view('ajaxtemplate/oe_category.php',$data,true);
			echo $temp ;
		}else{
			echo false;
		}
		
	}
	public function updatecategory()
	{
		$catName = $this->my_model->checkpostinput('categoryName') ;
		$catStatus = $this->my_model->checkpostinput('categoryStatus');
		$categoryId = $this->my_model->checkpostinput('categoryId');
		$data = array(
			    'name'  => $catName,
			    'status'  => $catStatus,
		);
		$this->db->where('id',$categoryId);
		$q = $this->db->update(OE_CATEGORY,$data);
		if($q){
			$data['oe_categuty'] = $this->my_model->getSingeleTable(OE_CATEGORY);
			$temp = $this->load->view('ajaxtemplate/oe_category.php',$data,true);
			echo $temp ;
		}else{
			echo false;
		}
		
	}
	
	public function deletecategory()
	{
		$catid = $this->my_model->checkpostinput('catid') ;
		
		$this->db->where('id', $catid);
		$this->db->delete(OE_CATEGORY);
		//getCounteRows($table,$where='')
		$where = array(
				   'id'=>$catid
				);
		$exist = $this->my_model->getCounteRows(OE_CATEGORY,$where);
		if($exist){
			echo false;
		}else{
			$data['oe_categuty'] = $this->my_model->getSingeleTable(OE_CATEGORY);
			$temp = $this->load->view('ajaxtemplate/oe_category.php',$data,true);
			echo $temp ;
		}
		
	}

/***********************************"subjects"**************************************/	
	public function subjects()
	{
		$condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
			//getFilterTable($table,$selectcolumn='',$wherecolumn, $id);
			$data['userData'] = $this->my_model->getSingeleTable(USERS);
			$this->load->view('users/header.php');
			$this->load->view('onlineexam/oe_subject.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
		
	}
	public function subjectTemp()
	{  
			$data['data'] = $this->my_model->getSingeleTable(OE_SUBJECT);
			$temp = $this->load->view('ajaxtemplate/oe_subject.php',$data,true);
			echo $temp ;
	}
	
	public function selectsubject()
	{
		$catid = $this->my_model->checkpostinput('catid') ;
		$data = $this->my_model->getSingeleRow(OE_SUBJECT,'id',$catid);
		echo json_encode($data);
		
	}
	
	public function addsubject()
	{
		$catName = $this->my_model->checkpostinput('categoryName') ;
		$catStatus = $this->my_model->checkpostinput('categoryStatus');
		$data = array(
			    'name'  => $catName,
			    'status'  => $catStatus,
		);
		$this->db->insert(OE_SUBJECT,$data);
		//echo $this->db->insert_id() ; die;
		if($this->db->insert_id()){
			$data['data'] = $this->my_model->getSingeleTable(OE_SUBJECT);
			$temp = $this->load->view('ajaxtemplate/oe_subject.php',$data,true);
			echo $temp ;
		}else{
			echo false;
		}
		
	}
	public function updatesubject()
	{
		$catName = $this->my_model->checkpostinput('categoryName') ;
		$catStatus = $this->my_model->checkpostinput('categoryStatus');
		$categoryId = $this->my_model->checkpostinput('categoryId');
		$data = array(
			    'name'  => $catName,
			    'status'  => $catStatus,
		);
		$this->db->where('id',$categoryId);
		$q = $this->db->update(OE_SUBJECT,$data);
		if($q){
			$data['data'] = $this->my_model->getSingeleTable(OE_SUBJECT);
			$temp = $this->load->view('ajaxtemplate/oe_subject.php',$data,true);
			echo $temp ;
		}else{
			echo false;
		}
		
	}
	public function deletesubject()
	{
		$sub_id = $this->my_model->checkpostinput('catid') ;
		
		

		$data =  $this->my_model->getFilterTable(OE_QUESTIONS,'','sub_id',$sub_id );
		$totalQues = count($data);
		if($totalQues){
			/* $this->session->set_flashdata('oe_message','<div class="alert alert-danger alert-dismissible">'.$totalQues.' Questions are available in subject so it cant delete
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			</div>'); */
			$value['oe_message'] = '<div class="alert alert-danger alert-dismissible">'.$totalQues.' Questions are available in subject so it cant delete
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			</div>';
			$value['status'] = 'exist';
			
			echo json_encode($value);
			
		}else{
			$this->db->where('id', $sub_id);
			$this->db->delete(OE_SUBJECT);
			//getCounteRows($table,$where='')status
			$where = array(
					   'id'=>$sub_id
					);
			$exist = $this->my_model->getCounteRows(OE_SUBJECT,$where);
			if($exist){
				echo false;
			}else{
				$data['data'] = $this->my_model->getSingeleTable(OE_SUBJECT);
				$temp = $this->load->view('ajaxtemplate/oe_subject.php',$data,true);
					$value['oe_message'] = '<div class="alert alert-danger alert-dismissible">'.$totalQues.' Questions are available in subject so it cant delete
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					</div>';
					$value['status'] = 'delete';
					$value['body'] = $temp ;
				echo json_encode($value);
			}
		}
	}
	
/*************************************"questions"************************************/
	public function questions()
	{
		$condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
			$data['userData'] = $this->my_model->getSingeleTable(USERS);
			$this->load->view('users/header.php');
			$this->load->view('onlineexam/oe_questions.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
		
	}
	
	public function questionsTemp()
	{  
			//getGroupByTableGvnId($table,$where='',$groupByClm,$orderBy,$orderByClm)
			$data['oe_qus_groupby'] = $this->Onlineexam_model->questionGroupBy();
			$data['oe_categuty'] = $this->my_model->getGroupByTableGvnId(OE_QUESTIONS,'','sub_id','id','DESC');
			$temp = $this->load->view('ajaxtemplate/oe_questions.php',$data,true);
			echo $temp ;
	}
	
	public function allquestions($sub_id)
	{
		$condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
				/*($table,$selectcolumn='',$wherecolumn, $id)*/
			$data['userData'] = $this->my_model->getSingeleTable(USERS);
			$data['quesWithSub'] = $this->my_model->getFilterTable(OE_QUESTIONS,'','sub_id',base64_decode($sub_id));
			$this->load->view('users/header.php');
			$this->load->view('onlineexam/oe_allqus_sub.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
		
	}
	
	public function questionedit($ques_id)
	{
		$condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
				/* getSingeleRow($table,$wherecolumn,$id){*/
			$data['userData'] = $this->my_model->getSingeleTable(USERS);
			$data['sglQusData'] = $this->my_model->getSingeleRow(OE_QUESTIONS,'id',base64_decode($ques_id));
			$this->load->view('users/header.php');
			$this->load->view('onlineexam/oe_questionedit.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
		
	}
	
	public function updateQuestion()
	{
		$condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
				echo '<pre>';
		       print_r($this->input->post()) ;
			      echo base64_decode($this->input->post('qid')) ;
			   echo '</pre>';
			   $url = 'onlineexam/questionedit/'.$this->input->post('qid');
			   redirect($url);
			/* getSingeleRow($table,$wherecolumn,$id){*/
			/*$data['userData'] = $this->my_model->getSingeleTable(USERS);
			$data['sglQusData'] = $this->my_model->getSingeleRow(OE_QUESTIONS,'id',base64_decode($ques_id));
			$this->load->view('users/header.php');
			$this->load->view('onlineexam/oe_questionedit.php',$data);
			$this->load->view('users/footer.php');*/
		}else{
			redirect('admin/login');
		}
		
	}
	
	public function addques()
	{
		$condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
				/*getFilterTable($table,$selectcolumn='',$wherecolumn, $id)*/
			$data['userData'] = $this->my_model->getSingeleTable(USERS);
			$data['subjData'] = $this->my_model->getFilterTable(OE_SUBJECT ,'','status',1);
			$this->load->view('users/header.php');
			$this->load->view('onlineexam/oe_addqus.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
	}
	public function addNewQuestion()
	{
		
		/* print_r($this->input->post()) ;
		die(); */
		//$this->check_login();
		$this->form_validation->set_rules('subject','subject','trim|required');
		$this->form_validation->set_rules('quse','quse','trim|required');
		$this->form_validation->set_rules('qush','qush','trim|required');
		$this->form_validation->set_rules('opae','opae','trim|required');
		$this->form_validation->set_rules('opbe','opbe','trim|required');
		$this->form_validation->set_rules('opce','opce','trim|required');
		$this->form_validation->set_rules('opde','opde','trim|required');
		$this->form_validation->set_rules('opah','opah','trim|required');
		$this->form_validation->set_rules('opbh','opbh','trim|required');
		$this->form_validation->set_rules('opch','opch','trim|required');
		$this->form_validation->set_rules('opde','opdh','trim|required');
		$this->form_validation->set_rules('ans','ans','trim|required');
		if($this->input->post('passage')){
			$pessgae_id = $this->input->post('passage') ;
		}else{
			$pessgae_id = 0 ;
		}
		if($this->form_validation->run()== TRUE){
			$data=array(
			'sub_id'=>$this->input->post('subject'),
			'passage_id'=>$pessgae_id,
			'Q_en'=>base64_encode($this->input->post('quse')),
			'Q_hi'=>base64_encode($this->input->post('qush')),
			'A_e1'=>base64_encode($this->input->post('opae')),
			'A_e2'=>base64_encode($this->input->post('opbe')),
			'A_e3'=>base64_encode($this->input->post('opce')),
			'A_e4'=>base64_encode($this->input->post('opde')),
			'A_e5'=>base64_encode($this->input->post('opee')),
			'A_h1'=>base64_encode($this->input->post('opah')),
			'A_h2'=>base64_encode($this->input->post('opbh')),
			'A_h3'=>base64_encode($this->input->post('opch')),
			'A_h4'=>base64_encode($this->input->post('opdh')),
			'A_h5'=>base64_encode($this->input->post('opeh')),
			'Ans'=>$this->input->post('ans'),
			'minusmark'=>$this->input->post('minusmrk'),
			'marks'=>$this->input->post('mark'),
			'solution'=>base64_encode($this->input->post('solu')),
			'multiple_ans'=>$this->input->post('multich'),
			'Createdate'=>date("Y-m-d h:i:s")
			);
			$this->db->insert('OE_QUESTIONS',$data);
			$oid = $this->db->insert_id();
			if($oid>0)
			{
				$this->session->set_flashdata('show_message','<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Entry Added Successfully !</div>');
				redirect('onlineexam/addques');
				
			}else{
				$this->session->set_flashdata('show_message','<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Please Try Again !</div>');
				redirect('onlineexam/addques');
			}
		}else{
			$this->session->set_flashdata('show_message','<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Please Try Again !</div>');
				redirect('onlineexam/addques');
		}
	}


/*************************************"papers"************************************/
public function papers()
	{
		$condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
		    //getFilterTableOrderBy($table,$orderByclm, $id)
			//getFilterTable($table,$selectcolumn='',$wherecolumn, $id)
			$data['userData'] = $this->my_model->getSingeleTable(USERS);
			$data['OE_PAPERS'] = $this->my_model->getFilterTableOrderBy(OE_PAPERS,'id','DESC');
			$this->load->view('users/header.php');
			$this->load->view('onlineexam/oe_papers.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
}


public function newpaper()
	{
		$condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
			//getFilterTable($table,$selectcolumn='',$wherecolumn, $id)
			$data['userData'] = $this->my_model->getSingeleTable(USERS);
			$data['OE_SUBJECT'] = $this->my_model->getFilterTable(OE_SUBJECT,'','status',1);
			$data['OE_CATEGORY'] = $this->my_model->getFilterTable(OE_CATEGORY,'','status',1);
			$this->load->view('users/header.php');
			$this->load->view('onlineexam/oe_newpaper.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
}
	
public function addpapers()
	{
		$condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
		    
			$this->load->library('form_validation');
			$this->form_validation->set_rules('pprName', 'Paper Name', 'required');
			$this->form_validation->set_rules('pprSufx', 'Paper Sufix Name', 'required');
			$this->form_validation->set_rules('pprCat', 'Paper Cat Name', 'required');
			$this->form_validation->set_rules('ttlmarks', 'Paper Cat Name', 'required');
			$this->form_validation->set_rules('minMarks', 'Paper minus mark Name', 'required');
			$this->form_validation->set_rules('ttlTime', 'Paper Total time Name', 'required');
			if ($this->form_validation->run() == TRUE){
			    $data = $this->Onlineexam_model->addpapers();
				 // print_r($data);die;
				if($data['status']){
					$this->session->set_flashdata('show_message1','<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Paper Added</div>');
				}else{
				$this->session->set_flashdata('show_message1','<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Please Try Again !</div>');
				}
				redirect('onlineexam/addpapers');
			}
			else{
				redirect('onlineexam/papers');
			}
		}else{
			redirect('admin/login');
		}
	}
	
	public function editpaperlist(){
			$condition =(
				($this->session->userdata('logintype') == 'admin') && 
				($this->session->userdata('status') == 1) && 
				($this->session->userdata('logged_in') == 1 )
			);
			if($condition){ 
			    $id = $this->input->post('id');
				//getFilterTable($table,$selectcolumn='',$wherecolumn, $id)
				echo $id ;
				
			}else{
				redirect('admin/login');
			}
	}
			
	public function select_ppr_for_ques(){
		$condition =(
				($this->session->userdata('logintype') == 'admin') && 
				($this->session->userdata('status') == 1) && 
				($this->session->userdata('logged_in') == 1 )
			);
			if($condition){ 
				$OE_PAPERS = $this->my_model->getFilterTableOrderBy(OE_PAPERS,'id','DESC');
				$string = '<div class="form-group"><label for="sel1">Select Paper For Questions:</label><select id="selectSub" class="form-control" required>';
				$string .= '<option value="">Slect Subject</option>';
				  foreach($OE_PAPERS as $data){
					$string .= '<option value="'.$data->id .'" class="form-controll">'.$data->name .'_'.$data->sufix_name .'</option>';
							}
				$string .= '</select></div>';
				echo $string;
			}else{
				redirect('admin/login');
			}
	}
	
	public function createpaper($selectppr){
			$condition =(
				($this->session->userdata('logintype') == 'admin') && 
				($this->session->userdata('status') == 1) && 
				($this->session->userdata('logged_in') == 1 )
			);
			if($condition){ 
		//getFilterTableWithOrderBy($table,$filtercol,$whereArray,$OrderBy,$value = 'desc')
				//getSingeleRow2cond($table,$wherecolumn1,$id1,$wherecolumn2,$id2)
				$pprData = $this->my_model->getSingeleRow2cond(OE_PAPERS,'status',1,'id',$selectppr); 
				$array = json_decode($pprData->sub_id) ;
				//print_r($array);
				foreach($array as $key => $value){
					$subject[]= $this->my_model->getSingeleRow(OE_SUBJECT,'id',$value) ;
					$question["question_$value"]= $this->my_model->getFilterTable(OE_QUESTIONS,'','sub_id', $value);
				}
				$data['selectPprData'] = $pprData ;
				$data['selectListData'] = $subject ;
				$data['question'] = $question ;
				$this->load->view('users/header.php');
				$this->load->view('onlineexam/oe_createpaper.php',$data);
				$this->load->view('users/footer.php');
				
			}else{
				redirect('admin/login');
			}
	}
		
	public function paper_choose_question(){
			$condition =(
				($this->session->userdata('logintype') == 'admin') && 
				($this->session->userdata('status') == 1) && 
				($this->session->userdata('logged_in') == 1 )
			);
			if($condition){ 
				//print_r($this->input->post('selectQus'));
				$selectQus =  $this->input->post('selectQus') ;
				$subjectId =  $this->input->post('subjectId') ;
				$paperID =  $this->input->post('paperID') ;
				//print_r($paperID);die;
					foreach($selectQus as $key => $value){
						 $quesArrayData = explode('_',$value) ;
						 $quesArray[] = $quesArrayData[0];
					}
					$array = array(
							'ppr_id' => $paperID,
							'sub_id' => $subjectId,
							'questions' => json_encode($quesArray),
							'created_date' => date(DATEFORMATE),
					);
					$res = $this->my_model->insertData(OE_PPRQUES,$array) ;
					print_r($res['status']);
					if($res['status'] == 1){
						$this->session->set_flashdata('inserQus','Inserted Questions in Paper');
						redirect('onlineexam/select_ppr_for_ques') ;
					}
			}else{
				redirect('admin/login');
			}
	}
	/************************************"papers"************************************/
   public function testpapers(){
	   $condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
			$data['userData'] = $this->my_model->getSingeleTable(USERS);
			//$data['OE_TEST_PAPERS'] = $this->my_model->getFilterTableOrderBy('oe_testpapers','id','DESC');
			$data['OE_TEST_PAPERS'] =  $this->db->select('*')->from('oe_testpapers')->order_by('id','DESC')->get()->result();
			$data['ppr_category'] =  $this->db->select('*')->from('oe_category')->where('status',1)->order_by('id','DESC')->get()->result();

			$this->load->view('users/header.php');
			$this->load->view('onlineexam/oe_test_papers.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
   }
   public function testpapersedit($pprid){
	   $condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
			$data['userData'] = $this->my_model->getSingeleTable(USERS);
			$data['editpprdata'] = $this->my_model->getSingeleRow('oe_testpapers','id',$pprid);
			$data['ppr_category'] =  $this->db->select('*')->from('oe_category')->where('status',1)->order_by('id','DESC')->get()->result();
			$this->load->view('users/header.php');
			$this->load->view('onlineexam/oe_test_papers_edit.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
   }
   
    public function testpapersupdate(){
	   $condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
			$pprID = $this->input->post('pperID');
			$pprname = $this->input->post('pprname');
			$pprStatus =  $this->input->post('pprStatus');
			//$ppr_url =  $this->input->post('ppr_url');
			$ppr_url =  trim($this->my_model->checkpostinput('ppr_url'));
			$pprMode =  $this->input->post('pprMode');
			$pprCategory =  $this->input->post('pprCategory');
			  $updatearra = array(
						'ppr_name' =>$pprname ,
						'status' =>$pprStatus,
						'ppr_url' =>$ppr_url,
						'ppr_mode' =>$pprMode,
						'ppr_cat' =>$pprCategory,
			      ) ;
				  
				  print_r($updatearra);die;
				  echo $ppr_url ; die;
				$this->db->where('id',$pprID);
			   $this->db->update('oe_testpapers',$updatearra) ;
			   $this->session->set_flashdata('flashmessage','<p class="text-left text-success">Paper Updated</p>');

			    //echo $this->db->last_query();
			   redirect('onlineexam/testpapers');
		}else{
			redirect('admin/login');
		}
   }
   public function addtestpapers(){
	   $condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
			$data['userData'] = $this->my_model->getSingeleTable(USERS);
			$data['testpaperadd'] = 1;
			$data['ppr_category'] =  $this->db->select('*')->from('oe_category')->where('status',1)->order_by('id','DESC')->get()->result();
			$this->load->view('users/header.php');
			$this->load->view('onlineexam/oe_test_papers_edit.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
   }
    public function inserttestpapers(){
	   $condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
			$pprname = $this->input->post('pprname');
			$pprStatus =  $this->input->post('pprStatus');
			$pprMode =  $this->input->post('pprMode');
			$ppr_url =  $this->input->post('ppr_url');
			$pprCategory =  $this->input->post('pprCategory');
			$insertdata = array(
						'ppr_name' =>$pprname ,
						'status' =>$pprStatus,
						'ppr_url' =>$ppr_url,
						'ppr_date' =>date('d-m-Y'),
						'ppr_mode' =>$pprMode,
						'ppr_cat' =>$pprCategory,
			      ) ;
			   $this->db->insert('oe_testpapers',$insertdata) ;
			   $lastid = $this->db->insert_id();
			   if($lastid){
				   $this->session->set_flashdata('flashmessage','<p class="text-left text-success">Paper Created</p>');
			   }else{
				   $this->session->set_flashdata('flashmessage','<p class="text-left text-dager">Something Went Wrong</p>');
			   }
			    //echo $this->db->last_query();
			redirect('onlineexam/testpapers');
			$this->load->view('users/header.php');
			$this->load->view('onlineexam/oe_test_papers_edit.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
   }
   
   public function testqueslist($tstPprId){
	   $condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
			$data['userData'] = $this->my_model->getSingeleTable(USERS);
			$data['OE_TEST_QUESTIONS'] = $this->db->select('*')->from('oe_testquestions')->where(array('ppr_id'=>$tstPprId))->get()->result();
			// echo $this->db->last_query();die;
			$this->load->view('users/header.php');
			$this->load->view('onlineexam/oe_test_questions.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
   }
   
   public function testQuesEdit($quesEditId){
	   $condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
			$data['userData'] = $this->my_model->getSingeleTable(USERS);
			$data['OE_TEST_EDITQUES'] = $this->db->select('*')->from('oe_testquestions')->where(array('id'=>$quesEditId))->get()->row();
			$data['OE_TEST_PAPERS'] = $this->db->select('*')->from('oe_testpapers')->where(array('ppr_mode'=>2))->get()->result();

			// echo $this->db->last_query();die;
			$this->load->view('users/header.php');
			$this->load->view('onlineexam/oe_test_questionedit.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
   }
	public function updateTestQuestion(){
	   $condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
		
			$question = trim($this->input->post('question'));
			  //echo $question ; die;
			$opt1 =  trim($this->my_model->checkpostinput('opt1'));
			$opt2 =  trim($this->my_model->checkpostinput('opt2'));
			$opt3 =  trim($this->my_model->checkpostinput('opt3'));
			$opt4 =  trim($this->my_model->checkpostinput('opt4'));
			$answer =  $this->my_model->checkpostinput('answer');
			$qid =  $this->my_model->checkpostinput('qid');
			$updatedata = array(
						'question' =>$question ,
						'op_1' =>$opt1,
						'op_2' =>$opt2,
						'op_3' =>$opt3,
						'op_4' =>$opt4,
						'ans' =>$answer,
			      ) ;
		    $this->db->where('id',$qid);
			$this->db->update('oe_testquestions',$updatedata) ;
			
			  //echo $this->db->last_query() ;die;
			
			$data['userData'] = $this->my_model->getSingeleTable(USERS);
			$data['OE_TEST_EDITQUES'] = $this->db->select('*')->from('oe_testquestions')->where(array('id'=>$qid))->get()->row();
			$this->load->view('users/header.php');
			$this->load->view('onlineexam/oe_test_questionedit.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
   }
   
   public function addtestQuestion(){
	   $condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
			$data['userData'] = $this->my_model->getSingeleTable(USERS);
			$data['OE_TEST_PAPERS'] = $this->db->select('*')->from('oe_testpapers')->where(array('ppr_mode'=>2))->get()->result();
				//echo $this->db->last_query(); die;
			$data['testQuesAdd'] = 1;
			$this->load->view('users/header.php');
			$this->load->view('onlineexam/oe_test_questionedit.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
   }
   public function insertTestQuestion(){
	   $condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
		
			$question = trim($this->input->post('question'));
			  //echo $question ; die;
			$opt1 =  trim($this->my_model->checkpostinput('opt1'));
			$opt2 =  trim($this->my_model->checkpostinput('opt2'));
			$opt3 =  trim($this->my_model->checkpostinput('opt3'));
			$opt4 =  trim($this->my_model->checkpostinput('opt4'));
			$answer =  $this->my_model->checkpostinput('answer');
			$qusStatus =  $this->my_model->checkpostinput('qusStatus');
			$qusPaperID =  $this->my_model->checkpostinput('qusPaper');
			$updatedata = array(
						'question' =>$question ,
						'op_1' =>$opt1,
						'op_2' =>$opt2,
						'op_3' =>$opt3,
						'op_4' =>$opt4,
						'ans' =>$answer,
						'ques_status' =>$qusStatus,
						'ppr_id' =>$qusPaperID,
			      ) ;
			$this->db->insert('oe_testquestions',$updatedata) ;
			$lastid = $this->db->insert_id();
			   if($lastid){
				   $this->session->set_flashdata('flashmessage','<p class="text-left text-success">Question Added</p>');
			   }else{
				   $this->session->set_flashdata('flashmessage','<p class="text-left text-dager">Something Went Wrong</p>');
			   }
						
			$data['userData'] = $this->my_model->getSingeleTable(USERS);
			$data['OE_TEST_QUESTIONS'] = $this->db->select('*')->from('oe_testquestions')->where(array('ppr_id'=>$qusPaperID))->get()->result();
			// echo $this->db->last_query();die;
			$this->load->view('users/header.php');
			$this->load->view('onlineexam/oe_test_questions.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
   }


   /***************************************"category"**********************************/	
	public function testcategory()
	{
		$condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){   
			$data['userData'] = $this->my_model->getSingeleTable(USERS);
			$data['oe_category'] = $this->db->select('*')->from('oe_category')->where(array('status'=>1))->get()->result();
			$this->load->view('users/header.php');
			$this->load->view('onlineexam/oe_testcategory.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
		
	}
	


	
	
	
}
