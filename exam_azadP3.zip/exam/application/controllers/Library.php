<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Library extends My_Controller {

	
	
	
	public function __construct() {
        parent::__construct();
		$this->load->model('user_model');
		$this->load->model('my_model');
		$this ->load->library('form_validation');
		$this->load->library('session');
		date_default_timezone_set("Asia/Calcutta") ;
    }
	
}