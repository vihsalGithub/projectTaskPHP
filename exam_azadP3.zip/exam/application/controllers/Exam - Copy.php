<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Exam extends My_Controller {


	public function __construct() {
        parent::__construct();
		$this->load->model('user_model');
		$this->load->model('my_model');
		$this ->load->library('form_validation');
		$this->load->library('session');
		date_default_timezone_set("Asia/Calcutta") ;
    }
	
	public function userlogincheck($user_id){
		$userData = $this->db->select('*')->from('oe_users')->where(array('user_id'=>$user_id,'status'=>1))->get()->result();
		if(count($userData)){
		    return 1 ;
		}else{ 
		    redirect('exam/login') ;
		}
	}

	public function payment_status_check($user_id){
		$userData = $this->db->select('*')->from('oe_users')->where(array('user_id'=>$user_id,'status'=>1,'payment_status'=>1))->get()->result();
		if(count($userData)){
		    return 1 ;
		}else{ 
		    //redirect('exam/paymantrenue') ;
		    redirect('exam/login') ;
		}
	}

	public function logout(){
		 session_start();
	  	 session_destroy();
	 	 unset($_SESSION);
	 	 redirect('exam/login');
	}

	public function index(){
		$userid = $_SESSION['user_id'] ;
		//echo $userid ;die;
		$this->userlogincheck($userid) ;
		$this->load->view('examhome/header');
		$this->load->view('examhome/index.php');
		$this->load->view('examhome/footer');
	}

	

/*#######################"Forget Password function"#########################*/
	public function forgotpassword(){
		$this->load->library('form_validation');
		$this->load->view('beforelogin/forgotpassword');
	}

	public function forgotpasssubmit(){
        $this->form_validation->set_rules('contactNo', 'Contact No.', 'required|regex_match[/^[0-9]{10}$/]');
        if ($this->form_validation->run() == TRUE){
        	   $contactNo = $this->my_model->checkpostinput('contactNo') ;
        	   $dataExis =  $this->db->select('user_id')->from('oe_users')->where(array('contact_no' => $contactNo ,'payment_status' => 1 ))->get()->row() ;
        	   if(count($dataExis)){
        	   			$password = (rand(5, 1000000)) ;
        	   			$sms_message = 'ASHG%0AYour%20New%20Password%0A'.$password;
						$smsurl ="http://bulk.bulksmsguru.in/sendsms?uname=lakhanpatelhelp&pwd=lakhan2222&senderid=ASHGCT&to=".$contactNo."&msg=".$sms_message."&route=T" ;
					       file_get_contents($smsurl);
					       $encodePass = base64_encode($password);
					       $updateData =  array('userpassword' => $encodePass);
					       $this->db->where('user_id',$dataExis->user_id);
							$this->db->update('oe_users',$updateData) ;
						$this->session->set_flashdata('errermessage', '<p class="text-center text-danger">We Are send new password on your '.$contactNo.'  number</p>') ;
						$this->session->set_userdata($sessiondata);
            	   	    redirect('exam/login');

        	   }else{
        	   		$this->session->set_flashdata('errermessage', '<p class="text-center text-danger">'.$contactNo.' Contact No. not exist <br>OR<br> your Payment Status not activate</p>') ;
						$this->session->set_userdata($sessiondata);
        	   		redirect('exam/forgotpassword');
        	   }
        	}else{
        		redirect('exam/forgotpassword');
        	}
	}
/*#######################"Login Process"#########################*/
	public function login(){
		$userid = $this->session->userdata('user_id');
		if($_SESSION['user_id'] ){
			print_r($userid); die;
			redirect('exam') ;
		}else{

			$this->load->view('beforelogin/login');
		}
	}

	public function submitlogin(){
		$this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->form_validation->set_rules('useremail', 'Email', 'required');
        $this->form_validation->set_rules('userPassword', 'Password', 'required');
        if ($this->form_validation->run() == TRUE){
            	$useremail = $this->my_model->checkpostinput('useremail') ;
            	$userPassword = $this->my_model->checkpostinput('userPassword') ;
            	$password =base64_encode($userPassword);
        		$userExist = $this->db->select('*')->from('oe_users')->where(array('email'=>$useremail,'userpassword'=>$password,'payment_status'=>1))->get()->row();
        		 
	        	$sessiondata = array(
				        'user_id'     => $userExist->user_id,
				        'userFullName'     => $userExist->name,
				        'userEmal'     => $userExist->email,
				        'userConNo'     => $userExist->contact_no,
				        'userStatus'     => $userExist->status,
				        'userPayStatus'     => $userExist->payment_status,
				        'userStartDate'     => $userExist->start_date,
				        'userExpDate'     =>$userExist->exp_date,
				);
        		$this->session->set_userdata($sessiondata);
        	    if($this->userlogincheck($_SESSION['user_id'])){
        	    	        		//print_r($_SESSION);
        	    		redirect('exam');
        	    	        		//echo $_SESSION['user_id'] ;
        	    }else{
        	    	redirect('exam/login');
        	    }
        }else{
        	redirect('exam/login'); 
        }
        		/*$contactNo = $this->my_model->checkpostinput('contactNo') ;
            	$useremail = $this->my_model->checkpostinput('useremail1') ;
            	$userPassword = $this->my_model->checkpostinput('userPassword1') ;
        		$userExist = $this->db->select('*')->from('oe_users')->where(array('email'=>$useremail,'userpassword'=>$userPassword))->get()->row();
        		  //echo $this->db->last_query();
        		print_r($userExist);*/
		//$this->load->view('beforelogin/login');
	}
/*#######################"USer Registration"#########################*/
	public function registration(){
		$this->load->view('beforelogin/registration');
		//$userid = $this->session->userdata('user_id');
		/*if($_SESSION['user_id']){
			redirect('exam') ;
		}else{
		   $this->load->view('beforelogin/registration');
		}*/
	}

	public function submitform(){
		$this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->form_validation->set_rules('fullName', 'Username', 'required');
        $this->form_validation->set_rules('paymentType', 'Payment Type', 'required');
        $this->form_validation->set_rules('userPassword', 'Password', 'required',
                        array('required' => 'You must provide a %s.')
                );
        $this->form_validation->set_rules('cnfPassword', 'Password Not Match', 'required|matches[userPassword]');
        $this->form_validation->set_rules('useremail', 'Email', 'required');
        $this->form_validation->set_rules('contactNo', 'Contact No.', 'required|regex_match[/^[0-9]{10}$/]');
            if ($this->form_validation->run() == TRUE){

            	   $fullName = 	$this->my_model->checkpostinput('fullName') ;
            	   $contactNo = $this->my_model->checkpostinput('contactNo') ;
            	   $useremail = $this->my_model->checkpostinput('useremail') ;
            	   $userPassword = $this->my_model->checkpostinput('userPassword') ;
            	   $regpackageId = $this->my_model->checkpostinput('regpackage') ;
            	   $paymentType = $this->my_model->checkpostinput('paymentType') ;
            	   $reg_charge =  $this->db->select('cahrge_rupee')->from('registration_charge')->where(array('charge_id' => 1 ))->get()->row() ;
            	   //echo $paymentType ; die;
            	   $regpackage =  $this->db->select('*')->from('oe_package')->where(array('pack_id' => $regpackageId ))->get()->row() ;

            	   	$number  = $reg_charge->cahrge_rupee + $regpackage->charge_rupee ;
            	   	$amount= number_format((float)$number, 2, '.', '');

            	   	//$amount = 1.00;

            	   	if($regpackageId == 1){
            	    	$expiradate = date('d-m-Y', strtotime("+30 days")) ;
            	    	//$amount = '20.00';
            	    }elseif($regpackageId == 2){
            	    	$expiradate = date('d-m-Y', strtotime("+60 days")) ;
            	    	//$amount = '40.00';
            	    }elseif($regpackageId ==3){
            	    	$expiradate = date('d-m-Y', strtotime("+90 days")) ;
            	    	//$amount = '60.00';
            	    }elseif($regpackageId ==4){
            	    	$expiradate = date('d-m-Y', strtotime("+150 days")) ;
            	    	//$amount = '60.00';
            	    }
            	        $liveKey = 'ax1BQLLp';
            	        $liveSalt = 't21qaYDpoH';

            	   		$sessiondata = array(
						        'key'  => $liveKey,
						        'salt'  => $liveSalt,
						        'amount'  => $amount,
						        'fname'     => $fullName,
						        'email'     => $useremail,
						        'mobile'     => $contactNo,
						        'pinfo'     => $regpackageId,
						        'expireDate'     => $expiradate,
						        'paymentType'     => $paymentType,
						        'userpassword'     => base64_encode($userPassword), 
						);

					$userExist = $this->db->select('user_id')->from('oe_users')->where(array('email'=>$useremail,'contact_no'=>$contactNo))->get()->row();
					if($userExist->package_type != $regpackageId){
						$this->db->where('user_id',$userExist->user_id) ;
						$this->db->update('oe_users',array('package_type' => $regpackageId));
					}
					if($userExist->payment_type != $paymentType){
						$this->db->where('user_id',$userExist->user_id) ;
						$this->db->update('oe_users',array('payment_type' => $paymentType));
					}
				    if(count($userExist)){
				    	$this->session->set_userdata($sessiondata);
						if($paymentType == 1){
							$this->session->set_userdata('reg_user_id', $userExist->user_id);
            	   	    	redirect('exam/paymentstype'); 
            	      	}elseif($paymentType == 2){
            	      		$this->session->set_userdata('reg_user_id', $userExist->user_id);
            	      		$data['userData'] =$userExist ;
            	      		redirect('exam/paymentstype',$data);
            	      	}elseif($paymentType == 3){
            	      		$this->session->set_userdata($sessiondata);
            	      		redirect('exam/paymentprocess'); 
            	      	}elseif($paymentType == 4){
            	      		$this->session->set_userdata('reg_user_id', $userExist->user_id);
            	      		redirect('exam/paymentstype'); 
            	      	}elseif ($paymentType == 5) {
            	      		$this->session->set_userdata('reg_user_id', $userExist->user_id);
            	      		//$this->session->set_userdata($sessiondata);
            	      		redirect('paytm/index'); 
            	      	}
				    }

            	   $dbemail = $this->db->select('user_id')->from('oe_users')->where(array('email'=>$useremail))->get()->row();
            	   if($dbemail->package_type != $regpackageId){
						$this->db->where('user_id',$dbemail->user_id) ;
						$this->db->update('oe_users',array('package_type' => $regpackageId));
					}
					if($dbemail->payment_type != $paymentType){
						$this->db->where('user_id',$dbemail->user_id) ;
						$this->db->update('oe_users',array('payment_type' => $paymentType));
					}
            	   if(count($dbemail)){
            	   	     //echo "email";die;
            	   		$this->session->set_userdata($sessiondata);
            	   	    $this->session->set_flashdata('errermessage', '<p class="text-center">Email Id is already exist</p>') ;
            	   	    if($paymentType == 1){
							$this->session->set_userdata('reg_user_id', $dbemail->user_id);
            	   	    	redirect('exam/paymentstype'); 
            	      	}elseif($paymentType == 2){
							$this->session->set_userdata('reg_user_id', $dbemail->user_id);
            	      		redirect('exam/paymentstype'); 
            	      	}elseif($paymentType == 3){
            	      		$this->session->set_userdata($sessiondata);
            	      		redirect('exam/paymentprocess'); 
            	      	}elseif($paymentType == 4){
            	      		$this->session->set_userdata('reg_user_id', $dbemail->user_id);
            	      		redirect('exam/paymentstype'); 
            	      	}elseif ($paymentType == 5) {
            	      		$this->session->set_userdata('reg_user_id', $dbemail->user_id);
            	      		redirect('paytm/index'); 
            	      	}
            	   }
            	   /*$dbcontact = $this->db->select('contact_no')->from('oe_users')->where(array('contact_no'=>$contactNo))->get()->row();
            	   if(count($dbcontact)){
            	   		   $this->session->set_flashdata('errermessage', '<p class="text-center">Contact no is already exist</p>') ;
            	   	    redirect('exam/registration'); 
            	   }*/
            	   
            	   $insertArray = array(
            	   						'name' => $fullName ,
            	   						'contact_no' => $contactNo ,
            	   						'email' => $useremail ,
            	   						'login_type' => 1 ,
            	   						'reg_date' => date("d-m-Y") ,
            	   						'start_date' => date("d-m-Y") ,
            	   						'exp_date' => $expiradate ,
            	   						'package_type' => $regpackageId ,
            	   						'payment_type' => $paymentType ,
            	   						'userpassword'     => base64_encode($userPassword),
            	   						 );
            	   $this->db->insert('oe_users',$insertArray) ;
            	    $insert_id = $this->db->insert_id();
            	    if($insert_id){
            	    	$this->session->set_userdata($sessiondata);
            	    	$this->session->set_userdata('user_id', $insert_id);
						//$this->session->set_userdata($sessiondata);
						//redirect('exam/paymentprocess');
						 $userdata = $this->db->select('user_id')->from('oe_users')->where(array('user_id'=>$insert_id))->get()->row();
						if($paymentType == 1){
							$this->session->set_userdata('reg_user_id', $insert_id);
            	   	    	redirect('exam/paymentstype'); 
            	      	}elseif($paymentType == 2){
							$this->session->set_userdata('reg_user_id', $insert_id);
            	      		redirect('exam/paymentstype'); 
            	      	}elseif($paymentType == 3){
            	      		$this->session->set_userdata($sessiondata);
            	      		redirect('exam/paymentprocess'); 
            	      	}elseif($paymentType == 4){
            	      		// echo $this->my_model->checkpostinput('paymentType') ; die;
            	      		$this->session->set_userdata('reg_user_id', $insert_id);
            	      		redirect('exam/paymentstype'); 
            	      	}elseif ($paymentType == 5) {
            	      		$this->session->set_userdata('reg_user_id', $insert_id);
            	      		redirect('paytm/index'); 
            	      	}
            	    }else{
            	    	redirect('exam/registration'); 
            	    }
                

            }else{
                redirect('exam/registration');   
            }
	}

	public function userlogin(){
		$this->session->set_userdata('userloginStatus', '1');
		print_r($this->session->all_userdata());
	}

	public function paymantrenue(){
		$data['message']= 1 ;
		$data['userData'] = $this->db->select('*')->from('oe_users')->where(array('user_id'=>$_SESSION['user_id']))->get()->result();
		$this->load->view('examhome/paymantrenue',$data);
	}

	public function paymantRenuePackage(){
		//print_r($this->input->post());
    	   $regpackageId = $this->my_model->checkpostinput('regpackage') ;
    	   $paymentType = $this->my_model->checkpostinput('paymentType') ;
    	   $reg_charge =  $this->db->select('cahrge_rupee')->from('registration_charge')->where(array('charge_id' => 1 ))->get()->row() ;
    	   $regpackage =  $this->db->select('*')->from('oe_package')->where(array('pack_id' => $regpackageId ))->get()->row() ;
    	   	$number  = $reg_charge->cahrge_rupee + $regpackage->charge_rupee ;
    	   	$amount= number_format((float)$number, 2, '.', '');

    	   	if($regpackageId == 1){
    	    	$expiradate = date('d-m-Y', strtotime("+30 days")) ;
    	    	//$amount = '20.00';
    	    }elseif($regpackageId == 2){
    	    	$expiradate = date('d-m-Y', strtotime("+60 days")) ;
    	    	//$amount = '40.00';
    	    }elseif($regpackageId ==3){
    	    	$expiradate = date('d-m-Y', strtotime("+90 days")) ;
    	    	//$amount = '60.00';
    	    }elseif($regpackageId ==4){
    	    	$expiradate = date('d-m-Y', strtotime("+150 days")) ;
    	    	//$amount = '60.00';
    	    }


    	    $data['userData'] = $this->db->select('*')->from('oe_users')->where(array('user_id'=>$_SESSION['user_id']))->get()->result();

    	    $orderId = rand(10000,99999999).'_'.$this->my_model->checkpostinput('paymentType').'_'.$this->my_model->checkpostinput('userId').'_'.$this->my_model->checkpostinput('regpackage') ;

    	$data['message']= 2 ;
		$data['orderId'] = $orderId;
		$data['amount'] = $amount;
		$data['regpackage'] = $regpackage;
		$data['userId'] = $this->my_model->checkpostinput('userId');
		$this->load->view('examhome/paymantrenue',$data);
	}
/*#######################"onlineTestAns"#########################*/

	public function onlineTestAns($pprID){
		$userid = $_SESSION['user_id'] ;
		$this->userlogincheck($userid) ;
		$data['questions'] = $this->db->select('question,op_1,op_2,op_3,op_4,ans')->from('oe_testquestions')->where(array('ques_status'=>1,'ppr_id'=>$pprID))->get()->result() ;
		 $this->db->select('*')->from('blood_donation_user')->get()->result() ;
		$this->load->view('examhome/header');
		$this->load->view('examhome/oe_testquesans.php',$data);
		$this->load->view('examhome/footer');
	}
/*#######################"Gallery"#########################*/

		/*public function gallery($galleryId=0){
			$result = $this->db->select('*')->from('gallery')->where(array('image_status'=>1))->get()->result() ;

			$table = 	'<div class="row">' ;
							foreach ($result as $key => $value) {
							  $table .= '<div class="col-md-3">';
							  		$table .=  '<img width="100%" src="'.$value->img_src.'">';
							  $table .= '</div>';
							}
						$table .= '</div>';

			$data['htmldata'] = $table ;
			$this->load->view('examhome/header');
			$this->load->view('examhome/paper',$data);
			$this->load->view('examhome/footer');
			SELECT * FROM `oe_users` WHERE `exp_date` LIKE '18-11-2018'
			update `oe_users` set `payment_status` = 0 where `user_id`=1 AND `exp_date` = '18-11-2018' 
UPDATE `oe_users` SET `payment_status` = '1' WHERE `oe_users`.`user_id` = 1 AND `oe_users`.`exp_date` = '18-11-2018'
		}*/

		public function gallery($galleryId=0){
			$imagePath = 'https://ashgindia.org/wp-content/uploads/photo-gallery';
					if($galleryId == 0){
						$gal_cat_json = file_get_contents("http://ashgindia.org/galleryapi/gallery.php");
						$gal_cat_array = json_decode($gal_cat_json);
						$record = $gal_cat_array->records;
						$row = count($gal_cat_array->records);
						$table = 	'<div class="row">' ;
							foreach ($record as $key => $value) {
								$galleryUrl = 'exam/gallery/'.$value->id ;
							  $table .= '<div class="col-md-4">';
							  		$table .=  '<a href="'.base_url($galleryUrl).'"><img width="100%" height="250px" src="'.$imagePath.'/'.$value->imgurl.'">';
							  		$table .=  '<p>'.$value->name.'</p></a>';
							  $table .= '</div>';
							   
							}
						$table .= '</div>';
					}else{

						//echo $galleryId ;
						$jsonUrl = 'http://ashgindia.org/galleryapi/gallery_images.php?galId='.$galleryId ;
						$gal_cat_json = file_get_contents($jsonUrl);
						$gal_cat_array = json_decode($gal_cat_json);
						$record = $gal_cat_array->records;
						$row = count($gal_cat_array->records);
						//print_r($record[0]);
						$table = 	'<div class="row">' ;
							foreach ($record as $key => $value) {
							  $table .= '<div class="col-md-4">';
							  		$table .=  '<img width="100%" height="250px" src="'.$imagePath.'/'.$value->thumbUrl.'">';
							  $table .= '</div>';
							   
							}
						$table .= '</div>';
						//print_r($gal_cat_json);

					}
			$data['htmldata'] = $table ;
			$this->load->view('examhome/header');
			$this->load->view('examhome/paper',$data);
			$this->load->view('examhome/footer');
		}
/*#######################"Online Exam"#########################*/

	public function papers($pprCatId=0){
		$userid = $this->session->userdata('user_id');
		 // echo $userid ; die;
		$this->payment_status_check($_SESSION['user_id'] ) ;

		//color: #262626;
		$anStyle = "style='color: #fba306; padding: 5px 10px;border: 1px solid'";

		$segment =  $this->uri->segment(3) ;

		if($segment == 1){
			$anStyle0 = "style='color: #262626; padding: 5px 10px;border: 1px solid'";
		}else{
			$anStyle0 = "style='color: #fba306; padding: 5px 10px;border: 1px solid'";
		}

		if($segment == 10){
			$anStyle1 = "style='color: #262626; padding: 5px 10px;border: 1px solid'";
		}else{
			$anStyle1 = "style='color: #fba306; padding: 5px 10px;border: 1px solid'";
		}
		if($segment == 12){
			$anStyle2 = "style='color: #262626; padding: 5px 10px;border: 1px solid'";
		}else{
			$anStyle2 = "style='color: #fba306; padding: 5px 10px;border: 1px solid'";
		}
		if($segment == 40){
			$anStyle3 = "style='color: #262626; padding: 5px 10px;border: 1px solid'";
		}else{
			$anStyle3 = "style='color: #fba306; padding: 5px 10px;border: 1px solid'";
		}
		if($segment == 41){
			$anStyle4 = "style='color: #262626; padding: 5px 10px;border: 1px solid'";
		}else{
			$anStyle4 = "style='color: #fba306; padding: 5px 10px;border: 1px solid'";
		}
		

      	if($pprCatId){
      		if($pprCatId == 1){

      			$result = $this->db->select('*')->from('oe_testpapers')->where(array('ppr_mode'=>3))->where_in('status',array(2))->get()->result() ;
      		}else{
      			$result = $this->db->select('*')->from('oe_testpapers')->where(array('ppr_mode'=>3,'ppr_cat'=>$pprCatId,'status'=>1))->get()->result() ;
      		}
      	}else{
      		$result = $this->db->select('*')->from('oe_testpapers')->where('ppr_mode',3)->where_in('status',array(1))->order_by('id','DESC')->get()->result() ;
		}

			$papers=	base_url("exam/papers/") ;
			$current =	base_url("exam/papers/1") ;
			$GKUrl=	base_url("exam/papers/10") ;
			$mppscUrl=	base_url("exam/papers/12") ;
			$samvidhaPapers=	base_url("exam/papers/40") ;
			$siPapers=	base_url("exam/papers/41") ;
		$table = '
		<div class="col-md-12">
					<a '.$anStyle.' href="'.$papers.'"><b>All Papers</b></a> |
					<a '.$anStyle0.' href="'.$current.'"><b>Current Afairs</b></a> |
					<a '.$anStyle1.' href="'.$GKUrl.'"><b>GK PAPER</b></a> |
					<a '.$anStyle2.' href="'.$mppscUrl.'"><b>MPPSC PAPER</b></a> |
					<a '.$anStyle3.' href="'.$samvidhaPapers.'"><b>SAMVIDA</b></a> |
					<a '.$anStyle4.' href="'.$siPapers.'"><b>SI</b></a> |
		</div>
				<style>
				   .startbtn{
				   	padding: 7px 21px;
		    font-size: 16px;
		    font-weight: 500;
		    line-height: 1;
		    color: #fff;
		    text-decoration: navajowhite;
		    background: #262222;
				   }
				</style>
				<table class="table">
						  <thead>
							<tr>
							  <th scope="col">#</th>
							  <th scope="col">Paper Name</th>
							  <th scope="col">Date</th>
							  <th scope="col">Totoal Qus</th>
							  <th scope="col">Totoal No</th>
							  <th scope="col">Handle</th>
							</tr>
						  </thead>
				  <tbody>';
				foreach($result as $key =>$row){
				$result1 = $this->db->select('id')->from('oe_testquestions')->where(array('ppr_id'=>$row->id))->get()->result() ;
				$ttl_question = count($result1) ;
				$ttl_ques_no = $this->db->select_sum('ques_no')->from('oe_testquestions')->where(array('ppr_id'=>$row->id))->get()->row() ;
					$clickurl = base_url('exam/testquizstart/').$row->id.'_'.$result1[0]->id   ;
					$clickurl = base_url('exam/examtestquizstart/') ;
					$clickurl = base_url('exam/testquizstart/') ;
				$table .=	'<tr>
					  <th scope="row">'.($key+1).'</th>
					  <td>'.$row->ppr_name .'</td>
					  <td>'.$row->ppr_date .'</td>
					  <td>'.$ttl_ques_no->ques_no .'</td>
					  <td>'.$ttl_question .'</td>';
					  if($row->status == 1){

				$table .='<form method="post" action="'.$clickurl.'">
					  <input type="hidden" name="pprid" value="'.$row->id.'">
					  <input type="hidden" name="qusid" value="'.$result1[0]->id .'">
					  <td><input class="btn startbtn" type="submit" value="start">
					  <a class="btn" style="background-color:#8a0e0e;padding: 6px 15px;color:#fff;  target="_blank"  border: 2px solid #fff;" href="'.base_url('exam/onlineTestAns/').$row->id.'">Answer</a>
					  </td>
					  </form>';

					 }else{

			    $table .='
					  <td><a class="btn" style="background-color:#8a0e0e;padding: 6px 15px;color:#fff;  target="_blank"  border: 2px solid #fff;" href="'.$row->ppr_url.'">Download PDF</a></td>';
					 }
				
				}
				$table .= '</tbody>
				</table>';
			$data['htmldata'] = $table ;
		$this->load->view('examhome/header');
		$this->load->view('examhome/paper',$data);
		$this->load->view('examhome/footer');	
	}

	public function testquestion($id){
		$userid = $_SESSION['user_id'] ;
		$this->payment_status_check($_SESSION['user_id'] ) ;
		$result = $this->db->select('*')->from('oe_testquestions')->where(array('ppr_id'=>$id))->get()->result() ;
		$table = '<table class="table">
				  <thead>
					<tr>
					  <th scope="col">#</th>
					  <th scope="col">First</th>
					  <th scope="col">Last</th>
					  <th scope="col">Last</th>
					  <th scope="col">Last</th>
					  <th scope="col">Last</th>
					  <th scope="col">Last</th>
					</tr>
				  </thead>
				  <tbody>';
				foreach($result as $key =>$row){
				$table .=	'<tr>
					  <th scope="row">1</th>
					  <td>'.htmlspecialchars($row->question).'</td>
					  <td>'.htmlspecialchars($row->op_1) .'</td>
					  <td>'.htmlspecialchars($row->op_2) .'</td>
					  <td>'.htmlspecialchars($row->op_3) .'</td>
					  <td>'.htmlspecialchars($row->op_4) .'</td>
					  <td>'.htmlspecialchars($row->ans) .'</td>
					</tr>';
				}
				$table .= '</tbody>
				</table>';
			$data['htmldata'] = $table ;	
			//echo $table ;
		$this->load->view('examhome/header');
		$this->load->view('examhome/paper',$data);
		$this->load->view('examhome/footer');
	}

	public function examtestquizstart(){
		$pprid = $this->input->post('pprid') ;
		$question = $this->db->select('id')->from('oe_testquestions')->where(array('ppr_id'=>$pprid))->get()->result() ;
		$data['question'] = $question ;
		 $this->load->view('examhome/header');
		$this->load->view('examhome/exam_papers.php',$data);
		 $this->load->view('examhome/footer');
		//print_r($question);
	}
	
	public function testquizstart(){
		$userid = $_SESSION['user_id'] ;
		$this->payment_status_check($_SESSION['user_id'] ) ;
		date_default_timezone_set("Asia/Calcutta") ;
		if($this->input->post('pprid')){
			$pprid = $this->input->post('pprid');
			$qusid = $this->input->post('qusid');
			$_SESSION["ses_pprid"] = $pprid;
			$_SESSION["ses_ttlqs"] = count($this->db->select('id')->from('oe_testquestions')->where(array('ppr_id'=>$pprid))->get()->result()) ;
			$_SESSION["ses_usrid"] = time();
			$_SESSION["ses_ttlGetMarsks"] = 0;
			$_SESSION["questCounter"] = 1;
			$_SESSION["userid"] = $userid;
			$arrayName = array(
							   'user_id' =>$userid, 
							   'user_ses_id' => time(),
							   'ttl_marks' => 0 ,
							   'time' => date("h:i:sa") ,
							   'paper_id' =>$pprid ,
							   'last_ques' =>$qusid ,
							   'date' => date("d-m-Y") ,
								);
		  	$this->db->insert('oe_test_record',$arrayName);

		}else{
			if($_SESSION["ses_pprid"]){
				$pprid = $_SESSION["ses_pprid"] ;
				//$qusid = $this->input->post('qusid');
				$qusid = $_SESSION["question_id"];
				$_SESSION["questCounter"]++ ;
				$nextques = $this->db->select('id')->from('oe_testquestions')->where('`id` = (select min(id) from oe_testquestions where id >'.$qusid.' AND ppr_id = '.$pprid.' )')->get()->row();
			}else{
				$loca = base_url('exam/papers') ;
				header("Location: ".$loca);
			}
		}
		$nextQusUrl = base_url('online/testquizstart') ;
		$result = $this->db->select('id,question,op_1,op_2,op_3,op_4')->from('oe_testquestions')->where(array('ppr_id'=>$pprid,'id'=>$qusid))->get()->row();
		$nextques = $this->db->select('id')->from('oe_testquestions')->where('`id` = (select min(id) from oe_testquestions where id >'.$qusid.' AND ppr_id = '.$pprid.' )')->get()->row();
		//select * from foo where id = (select min(id) from foo where id > 4)
		if(!empty($nextques->id)){
			$disnone = '';
		}else{
			$disnone = 'style="display:none"';
		}
		$ques = '<style>#topdiv , .site-header{display:none} .home-page-icon-boxes{padding: 50px 0;}img{width: 100% !important;}</style><div class="container">
				<div class="cause-wrap d-flex flex-wrap justify-content-between" id="questContainer">
				<div style="width:100%"><span id="time2"></span></div>
				<p class="current">Marks '.$_SESSION["ses_ttlGetMarsks"].'</p>
				<p class="current">Question '.$_SESSION["questCounter"].' / '.$_SESSION["ses_ttlqs"] .'</p>
				 <label class="container1 question"><span>('.$_SESSION["questCounter"] .') <span>'.$result->question.'</label>
				<form style="width:100%"  method="post" action="'.base_url('exam/process/').'">
					<label class="container1">'.htmlspecialchars($result->op_1).'
					  <input type="radio" name="choice" value="1">
					  <span class="checkmark"></span>
					</label>
					<label class="container1">'.htmlspecialchars($result->op_2).'
					  <input type="radio" name="choice"  value="2">
					  <span class="checkmark"></span>
					</label>
					<label class="container1">'.htmlspecialchars($result->op_3).'
					  <input type="radio" name="choice"  value="3">
					  <span class="checkmark"></span>
					</label>
					<label class="container1">'.htmlspecialchars($result->op_4).'
					  <input type="radio" name="choice"   value="4">
					  <span class="checkmark"></span>
					</label>
					  	<input type="hidden" name="choiceQuesid" value="'.$result->id.'">
					  <input style="margin:20px 0px" class="btn gradient-bg mr-2" type="submit" value="submit">
				</form>
				</div></div>' ;
		$data['htmldata'] = $ques ;
	    $this->load->view('examhome/header');
		$this->load->view('examhome/paper',$data);
		$this->load->view('examhome/footer');
		//select * from foo where id = (select min(id) from foo where id > 4)
	}

	public function process(){
		$choiceQuesid = $this->input->post('choiceQuesid');
		$choice = $this->input->post('choice');
		$selectQusData = $this->db->select('ans,ques_no')->from('oe_testquestions')->where(array('id'=>$choiceQuesid))->get()->row() ;
		if($selectQusData->ans == $choice){
			$_SESSION["ses_ttlGetMarsks"] = $_SESSION["ses_ttlGetMarsks"] + $selectQusData->ques_no ; 
		}

		$nextques = $this->db->select('id')->from('oe_testquestions')->where('`id` = (select min(id) from oe_testquestions where id >'.$choiceQuesid.' AND ppr_id = '.$_SESSION["ses_pprid"].' )')->get()->row();
		 if(!empty($nextques->id)){
			$_SESSION["question_id"] = $nextques->id;
			 $loca = base_url('exam/testquizstart') ;
			  header("Location: ".$loca);
		}else{
			$arrayName = array(
						   'ttl_marks' =>$_SESSION["ses_ttlGetMarsks"],
							);
		  	$this->db->update('oe_test_record',$arrayName);
		  	$this->db->where(array('user_id'=>$_SESSION["userid"] ,'user_ses_id'=>$_SESSION["ses_usrid"] ));
			$loca = base_url('exam/test_success') ;
			header("Location: ".$loca);
		}
	}
	
	public function test_success(){

		$userid = $_SESSION['user_id'] ;
		$this->userlogincheck($userid) ;

		$testrecord = $this->db->select('*')->from('oe_test_record')->where(array('user_id'=>$_SESSION["userid"] ,'user_ses_id'=>$_SESSION["ses_usrid"] ))->get()->row();

		$totalQues = $this->db->select('*')->from('oe_testquestions')->where(array('ppr_id'=>$testrecord->paper_id))->get()->result();
		$totalmarks = count($totalQues);
		//print_r($testrecord->paper_id);
			//echo $this->db->last_query();
			//print_r($testrecord) ;
		  $htmlContent = '
		  	<style> .icon-box:hover, .icon-box.active {
				    background: #ecf2f5 !important;
						  		}
				.icon-box:hover .entry-content p, .icon-box.active .entry-content p {
				    color: #262626;
				}
				.icon-box:hover .entry-title, .icon-box.active .entry-title {
				    color: #262626;
				}
						  		</style>
						   <div class="home-page-icon-boxes">
				        <div class="container">
				            <div class="row">
				                <div class="col-12 col-md-12 col-lg-12 mt-4 mt-lg-0 " id="topdiv1">
				                    <div class="icon-box">
				                        <header class="entry-header">
				                            <h3 class="entry-title">Successfully Completed</h3>
				                        </header>

				                        <div class="entry-content">
				                            <p>
				                            	Your Score is
				                            </p>
				                            <p>
				                            	'.$testrecord->ttl_marks.'/'.$totalmarks.'
				                            </p>
				                            <a href="'.base_url("exam/completed").'" style="margin-top:20px"class="btn gradient-bg mr-2">Thanks You</a>
				                        </div>
				                    </div>
				                </div>
				                <div class="col-12 col-md-12 col-lg-12 mt-12 mt-lg-0">
				                </div>
				            </div><!-- .row -->
				        </div><!-- .container -->
				    </div><!-- .home-page-icon-boxes -->';

    	$data['htmldata'] = $htmlContent ;
	    $this->load->view('examhome/header');
		$this->load->view('examhome/paper',$data);
		$this->load->view('examhome/footer');

    	//echo $htmlContent ;
			//		print_r($testrecord) ;
	}

	public function completed(){
			unset($_SESSION["ses_ttlGetMarsks"]);
		  	unset($_SESSION["ses_pprid"]);
		  	unset($_SESSION["questCounter"]);
		  	unset($_SESSION["ses_ttlqs"]);
		  	unset($_SESSION["question_id"]);
			//echo "score id ".$_SESSION["ses_ttlGetMarsks"] ;
			$loca = base_url('exam') ;
			header("Location: ".$loca);
	}
/*#######################"Online Exam End"#########################*/
	
	
		
	public function paymentprocess(){
		$this->load->view('pay/index.php');
	}

	public function payuresponce(){
		$postdata =  $this->input->post() ;
		if(isset($postdata['key'])) {
			$key				=   $postdata['key'];
			$salt				=   $postdata['salt'];
			$txnid 				= 	$postdata['txnid'];
		    $amount      		= 	$postdata['amount'];
			$productInfo  		= 	$postdata['productinfo'];
			$firstname    		= 	$postdata['firstname'];
			$email        		=	$postdata['email'];
			$udf5				=   $postdata['udf5'];
			$mihpayid			=	$postdata['mihpayid'];
			$status				= 	$postdata['status'];
			$resphash				= 	$postdata['hash'];
			$keyString 	  		=  	$key.'|'.$txnid.'|'.$amount.'|'.$productInfo.'|'.$firstname.'|'.$email.'|||||'.$udf5.'|||||';
			$keyArray 	  		= 	explode("|",$keyString);
			$reverseKeyArray 	= 	array_reverse($keyArray);
			$reverseKeyString	=	implode("|",$reverseKeyArray);
			$CalcHashString 	= 	strtolower(hash('sha512', $salt.'|'.$status.'|'.$reverseKeyString));
			     if($resphash == $CalcHashString){
			     	$paymentdata['hash_verified'] = 1 ;
			     }else{
			     	$paymentdata['hash_verified'] = 0 ;
			     }
				if($status == 'success') {
					$paymentdata = array(
	  					'user_id' => $_SESSION['user_id'] ,
	  					'txnid' => $txnid ,
	  					'amount' => $amount,
	  					'productinfo' => $productInfo ,
	  					'firstname' => $firstname ,
	  					'email' => $email  ,
	  					'mihpayid' => $mihpayid ,
	  					'status' => $status ,
	  					'hash' => $resphash ,
	  					'signup_type' => 1 ,
	  					'package_type' => $productInfo,
	  					 'date' => date("d-m-Y") ,
	  					 'exp_date' => $_SESSION['expireDate'] ,
	  				);
					$this->db->insert('payments',$paymentdata);
					$lastid = $this->db->insert_id() ;
					if($lastid){
						 	$this->session->unset_userdata('key');
							$this->session->unset_userdata('salt');
						$userUpdate = array('status' => 1 ,'payment_status' => 1  );

						$this->db->where('user_id',$_SESSION['user_id']);
						$this->db->update('oe_users',$userUpdate) ;
						$contact_no = $_SESSION['mobile'] ;
						//$sms_message = 'ASHG%0AThankyou%20For%20Registration%0AYour%20Loginid:%20'.$_SESSION['fname'].'%0AYour%20Pass.:%20'.$_SESSION['userPassword'] ;
						$sms_message = 'ASHG%0AThankyou%20For%20Registration%0A';
						$smsurl ="http://bulk.bulksmsguru.in/sendsms?uname=lakhanpatelhelp&pwd=lakhan2222&senderid=ASHGCT&to=".$contact_no."&msg=".$sms_message."&route=T" ;
					       file_get_contents($smsurl);
					    /*$this->session->set_userdata('userloginStatus', '1');*/
					    	$userid = $_SESSION['user_id'] ;
					    	$userExist = $this->db->select('*')->from('oe_users')->where(array('user_id'=>$userid))->get()->row();
					    	/*session_start();
						  	 session_destroy();
						 	 unset($_SESSION);
						 	 session_start();*/

						 	 	

						  	$sessiondata = array(
						        'user_id'     => $userExist->user_id,
						        'userFullName'     => $userExist->name,
						        'userEmal'     => $userExist->email,
						        'userConNo'     => $userExist->contact_no,
						        'userStatus'     => $userExist->status,
						        'userPayStatus'     => $userExist->payment_status,
						        'userStartDate'     => $userExist->start_date,
						        'userExpDate'     =>$userExist->exp_date,
							);
					    redirect('exam');
					}
				}
				else {
					session_start();
			  	 	session_destroy();
			 		unset($_SESSION);
					$msg = "Payment failed for Hasn not verified...";
				} 
		}else{
			session_start();
	  	 	session_destroy();
	 		unset($_SESSION);
			redirect('exam/registration'); 
		}
	}

	public function fail(){
		$this->load->view('pay/fail.php');
	}
/*#######################"Profile Edit Function"#########################*/
	public function profile(){
		$userid = $_SESSION['user_id'] ;
		$this->userlogincheck($userid) ;
		$data['userdata'] = $this->db->select('*')->from('oe_users')->where('user_id',$userid)->get()->row() ;
		$this->load->view('examhome/header');
		$this->load->view('examhome/userprofile.php',$data);
		$this->load->view('examhome/footer');
	}

	public function  editprofile(){
		$userid = $_SESSION['user_id'] ;
		$this->userlogincheck($userid) ;
		$data['userdata'] = $this->db->select('*')->from('oe_users')->where('user_id',$userid)->get()->row() ;
		$this->load->view('examhome/header');
		$this->load->view('examhome/editprofile.php',$data);
		$this->load->view('examhome/footer');
	}

	public function  updateuserprofile(){
		$userName = $this->my_model->checkpostinput('userName') ;
		$contactNo = $this->my_model->checkpostinput('contactNo') ;
		$oldPassword = $this->my_model->checkpostinput('oldPassword') ;
		$newPassword = $this->my_model->checkpostinput('newPassword') ;
		$userDetail = $this->db->select('*')->from('oe_users')->where('user_id',$_SESSION['user_id'])->get()->row() ;
			$updateArray['name'] = $userName ;
			$updateArray['contact_no'] = $contactNo ;
			$oldPassEncripted = $oldPassword;
			$userDataBasePass = base64_decode($userDetail->userpassword) ;
			if($oldPassEncripted == $userDataBasePass){
				$updateArray['userpassword'] = base64_encode($newPassword) ;
			}else{
				$this->session->set_flashdata('updateuserprofile', '<b class="text-danger text-center">Your Password is not match</b>');	
				redirect('exam/editprofile');
			}
			$updateArray['ttl_updated'] = $userDetail->ttl_updated + 1 ;
            $this->db->where('user_id',$_SESSION['user_id']);
            $this->db->update('oe_users',$updateArray);
            $this->session->set_flashdata('updateuserprofile', '<b class="text-success text-center">Profile Updated</b>');	
            $contact_no = $contactNo ;
			$sms_message = 'ASHG%0AThankyou%20For%20Registration%0AYour%20Login%20Detail%0AUsername:'.$userDetail->email.'%0APassword:'.$newPassword.'%0ABy%0A<a href="ashgindia.org">ashgindia.org</a>';
			$smsurl ="http://bulk.bulksmsguru.in/sendsms?uname=lakhanpatelhelp&pwd=lakhan2222&senderid=ASHGCT&to=".$contact_no."&msg=".$sms_message."&route=T" ;
			//echo $smsurl ; die;
			file_get_contents($smsurl);

			redirect('exam/editprofile');
	}
/*#######################"User Paymant Section"#########################*/

	public function payments(){
		$userid = $_SESSION['user_id'] ;
		$this->userlogincheck($userid) ;
		$data['userdata'] = $this->db->select('*')->from('oe_users')->where('user_id',$userid)->get()->row() ;
		$data['payments'] = $this->db->select('*')->from('payments')->where('user_id',$userid)->get()->result() ;
		$this->load->view('examhome/header');
		$this->load->view('examhome/userpayments.php',$data);
		$this->load->view('examhome/footer');

	}
/*#######################"Blood Group Section"#########################*/

	public function bloodgroup(){
		$userid = $_SESSION['user_id'] ;
		$this->userlogincheck($userid) ;
		$data['bloodDonateUser'] = $this->db->select('*')->from('blood_donation_user')->get()->result() ;
		$this->load->view('examhome/header');
		$this->load->view('examhome/bloodgroup.php',$data);
		$this->load->view('examhome/footer');
	}


	public function bloodgroupapi(){
		$data = $this->db->select('*')->from('blood_donation_user')->get()->result() ;
		echo json_encode($data);
	}
/*#######################"Library Section"#########################*/

	public function library(){
		//redirect('exam');
		$userid = $_SESSION['user_id'] ;
		$this->userlogincheck($userid) ;
		  $widgets = $this->db->select('*')->from('library_page')->where(array('widgets_id'=>1))->get()->result() ;
		  $aboutSir = $this->db->select('*')->from('library_page')->where(array('widgets_id'=>2))->get()->result() ;

		  $table = 	'<div class="row">' ;
							foreach ($widgets as $key => $value) {
							  $table .= '<div class="col-md-3" style="border:1px solid #ccc ;padding:10px;margin-top:10px;">';
							  		$table .=  '<p style="text-align:center;font-size: 20px;"><b>'.$value->title.'</b></p>';
							  		$table .=  '<p style="text-align:center"><img  src="'.$value->icon_image.'"></p>';
							  		$table .=  '<p>'.$value->description.'<p>';
							  $table .= '</div>';
							}
							$table .=  '<br><div style="border:1px solid #ccc ;padding:10px;margin-top:10px;" >
							<p style="text-align:center;font-size: 40px;"><b>'.$aboutSir[0]->title.'</b></p>
							<p><img  src="'.$aboutSir[0]->icon_image.'" style="float:left;padding:10px;">'.$aboutSir[0]->description.'</p></div>';
						$table .= '</div>';

							//$table .=  '<p>'$aboutSir[0]->description'</p>';	
			$data['htmldata'] = $table ;
			$this->load->view('examhome/header');
			$this->load->view('examhome/paper',$data);
			$this->load->view('examhome/footer');
		  	//print_r($aboutSir[0]->description);
		//$this->load->view('examhome/header');
		//$this->load->view('examhome/index.php');
		//print_r($_SESSION);
		//$this->load->view('examhome/footer');
	}
/*#######################"Paymant Section"#########################*/

	public function paymentstype(){
		$dbemail = $this->db->select('*')->from('oe_users')->where(array('user_id'=>$_SESSION['reg_user_id']))->get()->row();
	    $payment_type =  $this->db->select('*')->from('payment_type')->where(array('status' =>1,'payment_type'=>$dbemail->payment_type ))->get()->row() ;
	    $package_data =  $this->db->select('*')->from('oe_package')->where(array('status' =>1,'pack_id'=>$dbemail->package_type ))->get()->row() ;
	    $registration_charge =  $this->db->select('*')->from('registration_charge')->where(array('charge_id' =>1))->get()->row() ;
		 $randomly = (rand(10,10000)); 
		 $tokaen_no = base64_encode($randomly.'_'.$dbemail->user_id) ;
		$data['userData'] =$dbemail ;
		$data['tokaen_no'] =$tokaen_no ;
		$data['payment_type'] =$payment_type ;
		$data['package_data'] =$package_data ;
		$data['registration_charge'] =$registration_charge ;
		$_SESSION['reg_contact_no'] =  $dbemail->contact_no ; 
		$this->load->view('beforelogin/cashonlibrary',$data);
	}

	public function approval(){
		$payment_type = $this->input->get('payment_type');
		$token_id = $this->input->get('token_id');
		
		$updateArray = array(
				'reg_token'=> $token_id
		) ;
		$this->db->where('user_id',$_SESSION['reg_user_id']) ;
		$this->db->update('oe_users',$updateArray);
		$contact_no = $_SESSION['reg_contact_no'];
		$sms_message = 'ASHG%0AThankyou%20For%20Registration%0AYour%20TokeID:%0A'.$token_id;
		$smsurl ="http://bulk.bulksmsguru.in/sendsms?uname=lakhanpatelhelp&pwd=lakhan2222&senderid=ASHGCT&to=".$contact_no."&msg=".$sms_message."&route=T" ;
        file_get_contents($smsurl);
        session_start();
  	 	session_destroy();
 		unset($_SESSION);

 		$this->session->set_flashdata('cashonlibrary', '<p><b class="text-success">Thanks You for Regisration Please Activate Your Account From Library</b></p>');
		redirect('exam/registration');
		//echo $token_id ;
	}
/*#######################"Current News Facts"#########################*/
	public function currentnews(){
		$this->payment_status_check($_SESSION['user_id'] ) ;
		$currentnews =  $this->db->select('*')->from('current_news')->where(array('status' =>1))->get()->result() ;
		//print_r($currentnews);
		$data['currentnews'] = $currentnews ;
		$this->load->view('examhome/header');
		$this->load->view('examhome/current_news.php',$data);
		$this->load->view('examhome/footer');
	}
	public function newsmore($id){
		$currentnews =  $this->db->select('*')->from('current_news')->where(array('id' =>$id))->get()->row() ;
		$data['currentnews'] = $currentnews ;
		$this->load->view('examhome/header');
		$this->load->view('examhome/morenews.php',$data);
		$this->load->view('examhome/footer');
	}
/*#######################"Paymant Vaify Function"#########################*/
	public function paymentvarify(){
		$this->load->view('beforelogin/paymentvarify') ;
	}

	public function  screenshotSubmitForm(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('fullName', 'FullName', 'required');
		$this->form_validation->set_rules('useremail', 'Email', 'required');
		$this->form_validation->set_rules('orderID', 'Password', 'required');
		$this->form_validation->set_rules('contactNo', 'Contact no', 'required');
		if ($this->form_validation->run() == FALSE)
		{
			redirect('exam/paymentvarify') ;
		}else{
		    $fullname  = $this->input->post('fullName') ;
		    $orderID  = $this->input->post('orderID') ;
		    $useremail  = $this->input->post('useremail') ;
		    $contactNo  = $this->input->post('contactNo') ;
		    $config['file_name'] = time();
		    $config['encrypt_name'] = TRUE;
			$config['upload_path'] =  './uploads/vrification/' ;
			$config['allowed_types']        = 'gif|jpg|png';
			$this->load->library('upload', $config);
			if ($this->upload->do_upload('invoiceScreenshot')){
				$this->session->set_flashdata('file_message', 'file is uploaded successfully');		 
				$data = array('upload_data' => $this->upload->data());
				$insertArray = array(
				     'fullname' => $fullname ,
				     'order_id' => $orderID ,
				     'useremail' => $useremail ,
				     'contact_no' => $contactNo ,
				     'image_path' => $data['upload_data']['file_name'] ,
				) ;
				$this->db->insert('oe_payment_varification',$insertArray);
				$error = array('error' => $this->upload->display_errors());
				$this->session->set_flashdata('file_message', '<b class="text-success">Thanks You for varification of your paymants documents</b>');		 
				redirect('exam/paymentvarify');
				//echo $data['upload_data']['file_name'] ;
			}else{
				$error = array('error' => $this->upload->display_errors());
				$this->session->set_flashdata('file_message', '<b class="text-danger">Something  went Wrong</b>');		 
				redirect('exam/paymentvarify');
			}
		}
	}
/*#######################"Contact Us Function"#########################*/
	public function contactus(){
		$userName = $_SESSION["userFullName"] ;
		$userEmaluserEmal = $_SESSION["userEmal"] ;
		$userConNo = $_SESSION["userConNo"] ;
		$feedBack = 'feedback' ;
		   $table = '<div class="row"><div class="col-md-6"><form role="form"  action="'.base_url('exam/enquirySubmit').'" method="post">
	        <br style="clear:both">
	                    <h3 style="margin-bottom: 25px; text-align: center;">Contact Form</h3>
	    				<div class="form-group">
							<input type="text" readonly class="form-control" id="name" name="name" placeholder="Name" required value="'.$userName.'">
						</div>
						<div class="form-group">
							<input type="text" readonly class="form-control" id="email" name="email" placeholder="Email" required value="'.$userEmaluserEmal.'">
						</div>
						<div class="form-group">
							<input type="text" readonly class="form-control" id="mobile" name="mobile" placeholder="Mobile Number" required  value="'.$userConNo.'">
						</div>
						<div class="form-group">
							<input type="text" class="form-control" id="subject" name="subject" placeholder="Subject" required  value="'.$feedBack.'">
						</div>
	                    <div class="form-group">
	                    <textarea class="form-control" type="textarea" id="message"  name="textarea" placeholder="Message" maxlength="140" rows="7" required></textarea>
	                        <span class="help-block"><p id="characterLeft" class="help-block ">You have reached the limit</p></span>                    
	                    </div>
	            
	        <button type="submit" id="submit" name="submit" class="btn btn-primary pull-left">Send</button>
	        </form></div>
	        <div class="col-md-6">
	        	<h3 style="margin-bottom: 25px; text-align: center;margin-top: 25px;">Contact us</h3>
	          <p style="border: 1px solid #ccc; padding: 10px;">आप हमसे WhatsApp  और कॉल पर भी संपर्क  कर सकते हो <br><b>88710-36186/75666-60264(Only WhatsApp)</b>
	          	<br>आप बिना किसी झिझक के हमारी टीम से संपर्क कर सकते हो 
	          <p>
	        </div></div>';
        $data['htmldata'] = $table ;
			$this->load->view('examhome/header');
			$this->load->view('examhome/paper',$data);
			$this->load->view('examhome/footer');
	} 


	public function enquirySubmit(){

		$name =  $this->input->post('name');
		$email =  $this->input->post('email');
		$mobile =  $this->input->post('mobile');
		$subject =  $this->input->post('subject');
		$textarea =  $this->input->post('textarea');


		$insertFeedBack = array(
				'name'=>$name,
				'email'=>$email,
				'contact'=>$mobile,
				'subject'=>$subject,
				'message'=>$textarea,
				'created_at'=> date("d-m-Y") ,
				'user_id'=>$_SESSION["user_id"],
		);

		$this->db->insert('enquiry',$insertFeedBack);
		$insert_id = $this->db->insert_id();
		if($insert_id){
			$this->session->set_flashdata('feedback_msg', '<p class="text-center text-success">Thanks You For feedback</p>') ;
			$this->session->set_userdata($sessiondata);
            redirect('exam/contactus');
		}else{
			$this->session->set_flashdata('feedback_msg', '<p class="text-center text-danger">Something Went Wrong</p>') ;
			$this->session->set_userdata($sessiondata);
            redirect('exam/contactus');
		}
	}



/*end of controller*/
}



