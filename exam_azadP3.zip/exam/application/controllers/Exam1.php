<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Exam extends My_Controller {

	
	
	
	public function __construct() {
        parent::__construct();
		$this->load->model('user_model');
		$this->load->model('my_model');
		$this ->load->library('form_validation');
		$this->load->library('session');
		date_default_timezone_set("Asia/Calcutta") ;
    }
	
	
	
	public function userlogincheck($user_id){
		$userData = $this->db->select('*')->from('oe_users')->where(array('user_id'=>$user_id,'status'=>1,'payment_status'=>1))->get()->result();
		if(count($userData)){
		    return 1 ;
		}else{ 
		    redirect('exam/login') ;
		}
	}

	public function logout(){
		 session_start();
	  	 session_destroy();
	 	 unset($_SESSION);
	 	 redirect('exam/login');
	}

	public function index(){
		$userid = $_SESSION['user_id'] ;
		$this->userlogincheck($userid) ;
		$this->load->view('examhome/header');
		$this->load->view('examhome/index.php');
		$this->load->view('examhome/footer');
	}

	public function registration(){
		$userid = $this->session->userdata('user_id');
		if($_SESSION['user_id'] ){
			redirect('exam') ;
		}else{
		   $this->load->view('beforelogin/registration');
		}
	}

	public function login(){
		$userid = $this->session->userdata('user_id');
		if($_SESSION['user_id'] ){
			redirect('exam') ;
		}else{
			$this->load->view('beforelogin/login');
		}
	}

	public function submitlogin(){
		$this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->form_validation->set_rules('useremail', 'Email', 'required');
        $this->form_validation->set_rules('userPassword', 'Password', 'required');
        if ($this->form_validation->run() == TRUE){
            	$useremail = $this->my_model->checkpostinput('useremail') ;
            	$userPassword = $this->my_model->checkpostinput('userPassword') ;
            	$password =base64_encode($userPassword);
        		$userExist = $this->db->select('*')->from('oe_users')->where(array('email'=>$useremail,'userpassword'=>$password))->get()->row();
        		 
	        	$sessiondata = array(
				        'user_id'     => $userExist->user_id,
				        'userFullName'     => $userExist->name,
				        'userEmal'     => $userExist->email,
				        'userConNo'     => $userExist->contact_no,
				        'userStatus'     => $userExist->status,
				        'userPayStatus'     => $userExist->payment_status,
				        'userStartDate'     => $userExist->start_date,
				        'userExpDate'     =>$userExist->exp_date,
				);
        		$this->session->set_userdata($sessiondata);
        	    if($this->userlogincheck($_SESSION['user_id'])){
        	    	        		//print_r($_SESSION);
        	    		redirect('exam');
        	    	        		//echo $_SESSION['user_id'] ;
        	    }else{
        	    	redirect('exam/login');
        	    }
        }else{
        	redirect('exam/login'); 
        }
        		/*$contactNo = $this->my_model->checkpostinput('contactNo') ;
            	$useremail = $this->my_model->checkpostinput('useremail1') ;
            	$userPassword = $this->my_model->checkpostinput('userPassword1') ;
        		$userExist = $this->db->select('*')->from('oe_users')->where(array('email'=>$useremail,'userpassword'=>$userPassword))->get()->row();
        		  //echo $this->db->last_query();
        		print_r($userExist);*/
		//$this->load->view('beforelogin/login');
	}
	
	public function submitform(){
		$this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');

        $this->form_validation->set_rules('fullName', 'Username', 'required');
        $this->form_validation->set_rules('userPassword', 'Password', 'required',
                        array('required' => 'You must provide a %s.')
                );
        $this->form_validation->set_rules('cnfPassword', 'Password Not Match', 'required|matches[userPassword]');
        $this->form_validation->set_rules('useremail', 'Email', 'required');
        $this->form_validation->set_rules('contactNo', 'Contact No.', 'required|regex_match[/^[0-9]{10}$/]');
            if ($this->form_validation->run() == TRUE){

            	   $fullName = 	$this->my_model->checkpostinput('fullName') ;
            	   $contactNo = $this->my_model->checkpostinput('contactNo') ;
            	   $useremail = $this->my_model->checkpostinput('useremail') ;
            	   $userPassword = $this->my_model->checkpostinput('userPassword') ;
            	   $regpackageId = $this->my_model->checkpostinput('regpackage') ;
            	   $reg_charge =  $this->db->select('cahrge_rupee')->from('registration_charge')->where(array('charge_id' => 1 ))->get()->row() ;

            	  // echo $regpackageId ; die;

            	   $regpackage =  $this->db->select('*')->from('oe_package')->where(array('pack_id' => $regpackageId ))->get()->row() ;

            	   	$number  = $reg_charge->cahrge_rupee + $regpackage->charge_rupee ;
            	   	$amount= number_format((float)$number, 2, '.', '');


            	   	 //echo $amount ; die;
            	   	

            	   	if($regpackageId == 1){
            	    	$expiradate = date('d-m-Y', strtotime("+30 days")) ;
            	    	//$amount = '20.00';
            	    }elseif($regpackageId == 2){
            	    	$expiradate = date('d-m-Y', strtotime("+60 days")) ;
            	    	//$amount = '40.00';
            	    }elseif($regpackageId ==3){
            	    	$expiradate = date('d-m-Y', strtotime("+90 days")) ;
            	    	//$amount = '60.00';
            	    }

            	   		$sessiondata = array(
						        'key'  => 'ax1BQLLp',
						        'salt'  => 't21qaYDpoH',
						        'amount'  => $amount,
						        'fname'     => $fullName,
						        'email'     => $useremail,
						        'mobile'     => $contactNo,
						        'pinfo'     => $regpackageId,
						        'userpassword'     => base64_encode($userPassword), 
						);

					$userExist = $this->db->select('user_id')->from('oe_users')->where(array('email'=>$useremail,'contact_no'=>$contactNo))->get()->row();
				    if(count($userExist)){
				    	
						$this->session->set_flashdata('errermessage', '<p class="text-center text-danger">Email or Contact already exist</p>') ;
            	   	    redirect('exam/registration'); 
				    }

            	   $dbemail = $this->db->select('email')->from('oe_users')->where(array('email'=>$useremail))->get()->row();
            	   if(count($dbemail)){
            	   	    $this->session->set_flashdata('errermessage', '<p class="text-center">Email Id is already exist</p>') ;
            	   	    redirect('exam/registration'); 
            	   }
            	   $dbcontact = $this->db->select('contact_no')->from('oe_users')->where(array('contact_no'=>$contactNo))->get()->row();
            	   if(count($dbcontact)){
            	   		   $this->session->set_flashdata('errermessage', '<p class="text-center">Contact no is already exist</p>') ;
            	   	    redirect('exam/registration'); 
            	   }
            	   
            	   $insertArray = array(
            	   						'name' => $fullName ,
            	   						'contact_no' => $contactNo ,
            	   						'email' => $useremail ,
            	   						'login_type' => 1 ,
            	   						'reg_date' => date("d-m-Y") ,
            	   						'start_date' => date("d-m-Y") ,
            	   						'exp_date' => $expiradate ,
            	   						'package_type' => $regpackageId ,
            	   						'user_type' => 1 ,
            	   						'userpassword'     => base64_encode($userPassword),
            	   						 );
            	   $this->db->insert('oe_users',$insertArray) ;
            	    $insert_id = $this->db->insert_id();
            	    if($insert_id){
            	    	$this->session->set_userdata('user_id', $insert_id);
						$this->session->set_userdata($sessiondata);
						redirect('exam/paymentprocess');
            	    }else{
            	    	redirect('exam/registration'); 
            	    }
                

            }else{
                redirect('exam/registration');   
            }
	}

	public function userlogin(){
		$this->session->set_userdata('userloginStatus', '1');
		print_r($this->session->all_userdata());
	}
	
	public function papers(){
		$userid = $this->session->userdata('user_id');
		 // echo $userid ; die;
		$this->userlogincheck($_SESSION['user_id'] ) ;

		$result = $this->db->select('*')->from('oe_testpapers')->where('ppr_mode',3)->where_in('status',array(1,2))->get()->result() ;
		$table = '
				<style>
				   .startbtn{
				   	padding: 7px 21px;
		    font-size: 16px;
		    font-weight: 500;
		    line-height: 1;
		    color: #fff;
		    text-decoration: navajowhite;
		    background: #262222;
				   }
				</style>
				<table class="table">
						  <thead>
							<tr>
							  <th scope="col">#</th>
							  <th scope="col">Paper Name</th>
							  <th scope="col">Date</th>
							  <th scope="col">Totoal Qus</th>
							  <th scope="col">Totoal No</th>
							  <th scope="col">Handle</th>
							</tr>
						  </thead>
				  <tbody>';
				foreach($result as $key =>$row){
				$result1 = $this->db->select('id')->from('oe_testquestions')->where(array('ppr_id'=>$row->id))->get()->result() ;
				   //print_r($result1[0]->id); die;
				$ttl_question = count($result1) ;
				$ttl_ques_no = $this->db->select_sum('ques_no')->from('oe_testquestions')->where(array('ppr_id'=>$row->id))->get()->row() ;
					$clickurl = base_url('exam/testquizstart/').$row->id.'_'.$result1[0]->id   ;
					$clickurl = base_url('exam/testquizstart/') ;
					//$clickurl = base_url('exam/testquizstart/1_1')   ;
				$table .=	'<tr>
					  <th scope="row">'.($key+1).'</th>
					  <td>'.$row->ppr_name .'</td>
					  <td>'.$row->ppr_date .'</td>
					  <td>'.$ttl_ques_no->ques_no .'</td>
					  <td>'.$ttl_question .'</td>';
					  if($row->status == 1){

				$table .='<form method="post" action="'.$clickurl.'">
					  <input type="hidden" name="pprid" value="'.$row->id.'">
					  <input type="hidden" name="qusid" value="'.$result1[0]->id .'">
					  <td><input class="btn startbtn" type="submit" value="start"></td>
					  </form>
					</tr>';

					 }else{

			    $table .='
					  <td><a class="btn" style="background-color:#8a0e0e;padding: 6px 15px;color:#fff;    border: 2px solid #fff;" href="'.$result[0]->ppr_url.'">Download PDF</a></td>
					</tr>';

					 }
				}
				$table .= '</tbody>
				</table>';
			$data['htmldata'] = $table ;
		$this->load->view('examhome/header');
		$this->load->view('examhome/paper',$data);
		$this->load->view('examhome/footer');	
		
		///echo $table ;
		//print_r($table);
	}
	
	public function testquestion($id){
		$userid = $_SESSION['user_id'] ;
		$this->userlogincheck($userid) ;
		$result = $this->db->select('*')->from('oe_testquestions')->where(array('ppr_id'=>$id))->get()->result() ;
		$table = '<table class="table">
				  <thead>
					<tr>
					  <th scope="col">#</th>
					  <th scope="col">First</th>
					  <th scope="col">Last</th>
					  <th scope="col">Last</th>
					  <th scope="col">Last</th>
					  <th scope="col">Last</th>
					  <th scope="col">Last</th>
					</tr>
				  </thead>
				  <tbody>';
				foreach($result as $key =>$row){
				$table .=	'<tr>
					  <th scope="row">1</th>
					  <td>'.htmlspecialchars($row->question).'</td>
					  <td>'.htmlspecialchars($row->op_1) .'</td>
					  <td>'.htmlspecialchars($row->op_2) .'</td>
					  <td>'.htmlspecialchars($row->op_3) .'</td>
					  <td>'.htmlspecialchars($row->op_4) .'</td>
					  <td>'.htmlspecialchars($row->ans) .'</td>
					</tr>';
				}
				$table .= '</tbody>
				</table>';
			$data['htmldata'] = $table ;	
			//echo $table ;
		$this->load->view('examhome/header');
		$this->load->view('examhome/paper',$data);
		$this->load->view('examhome/footer');
	}
	
	public function testquizstart(){
		
		$userid = $_SESSION['user_id'] ;
		$this->userlogincheck($userid) ;
		date_default_timezone_set("Asia/Calcutta") ;
		if($this->input->post('pprid')){
			$pprid = $this->input->post('pprid');
			$qusid = $this->input->post('qusid');
			$_SESSION["ses_pprid"] = $pprid;
			$_SESSION["ses_ttlqs"] = count($this->db->select('id')->from('oe_testquestions')->where(array('ppr_id'=>$pprid))->get()->result()) ;
			$_SESSION["ses_usrid"] = time();
			$_SESSION["ses_ttlGetMarsks"] = 0;
			$_SESSION["questCounter"] = 1;
			$_SESSION["userid"] = $userid;
			$arrayName = array(
							   'user_id' =>$userid, 
							   'user_ses_id' => time(),
							   'ttl_marks' => 0 ,
							   'time' => date("h:i:sa") ,
							   'paper_id' =>$pprid ,
							   'last_ques' =>$qusid ,
							   'date' => date("d-m-Y") ,
								);
		  	$this->db->insert('oe_test_record',$arrayName);

		}else{
			if($_SESSION["ses_pprid"]){
				$pprid = $_SESSION["ses_pprid"] ;
				//$qusid = $this->input->post('qusid');
				$qusid = $_SESSION["question_id"];
				$_SESSION["questCounter"]++ ;
				$nextques = $this->db->select('id')->from('oe_testquestions')->where('`id` = (select min(id) from oe_testquestions where id >'.$qusid.' AND ppr_id = '.$pprid.' )')->get()->row();
			}else{
				$loca = base_url('exam/papers') ;
				header("Location: ".$loca);
			}
		}
		$nextQusUrl = base_url('online/testquizstart') ;
		$result = $this->db->select('id,question,op_1,op_2,op_3,op_4')->from('oe_testquestions')->where(array('ppr_id'=>$pprid,'id'=>$qusid))->get()->row();
		$nextques = $this->db->select('id')->from('oe_testquestions')->where('`id` = (select min(id) from oe_testquestions where id >'.$qusid.' AND ppr_id = '.$pprid.' )')->get()->row();
		//select * from foo where id = (select min(id) from foo where id > 4)
		if(!empty($nextques->id)){
			$disnone = '';
		}else{
			$disnone = 'style="display:none"';
		}
		$ques = '<style>#topdiv , .site-header{display:none} .home-page-icon-boxes{padding: 50px 0;}</style><div class="container">
				<div class="cause-wrap d-flex flex-wrap justify-content-between" id="questContainer">
				<div style="width:100%"><span id="time2"></span></div>
				<p class="current">Marks '.$_SESSION["ses_ttlGetMarsks"].'</p>
				<p class="current">Question '.$_SESSION["questCounter"].' / '.$_SESSION["ses_ttlqs"] .'</p>
				 <label class="container1 question"><span>('.$_SESSION["questCounter"] .') <span>'.htmlspecialchars($result->question).'</label>
				<form style="width:100%"  method="post" action="'.base_url('exam/process/').'">
					<label class="container1">'.htmlspecialchars($result->op_1).'
					  <input type="radio" name="choice" value="1">
					  <span class="checkmark"></span>
					</label>
					<label class="container1">'.htmlspecialchars($result->op_2).'
					  <input type="radio" name="choice"  value="2">
					  <span class="checkmark"></span>
					</label>
					<label class="container1">'.htmlspecialchars($result->op_3).'
					  <input type="radio" name="choice"  value="3">
					  <span class="checkmark"></span>
					</label>
					<label class="container1">'.htmlspecialchars($result->op_4).'
					  <input type="radio" name="choice"   value="4">
					  <span class="checkmark"></span>
					</label>
					  	<input type="hidden" name="choiceQuesid" value="'.$result->id.'">
					  <input style="margin:20px 0px" class="btn gradient-bg mr-2" type="submit" value="submit">
				</form>
				</div></div>' ;
		$data['htmldata'] = $ques ;
	    $this->load->view('examhome/header');
		$this->load->view('examhome/paper',$data);
		$this->load->view('examhome/footer');
		//select * from foo where id = (select min(id) from foo where id > 4)
	}
	
	
	public function process(){
		$choiceQuesid = $this->input->post('choiceQuesid');
		$choice = $this->input->post('choice');
		//$selectQusData = $this->db->select('ans,ques_no')->from('oe_test_record')->where(array('user_id'=>$choiceQuesid , 'user_ses_id'=>$choiceQuesid))->get()->row() ;
		  //echo $choice ; die;
		$selectQusData = $this->db->select('ans,ques_no')->from('oe_testquestions')->where(array('id'=>$choiceQuesid))->get()->row() ;
		//print_r($selectQusData->ans);
		if($selectQusData->ans == $choice){
			$_SESSION["ses_ttlGetMarsks"] = $_SESSION["ses_ttlGetMarsks"] + $selectQusData->ques_no ; 
		}

		$nextques = $this->db->select('id')->from('oe_testquestions')->where('`id` = (select min(id) from oe_testquestions where id >'.$choiceQuesid.' AND ppr_id = '.$_SESSION["ses_pprid"].' )')->get()->row();
		 if(!empty($nextques->id)){
			//$disnone = '';
			$_SESSION["question_id"] = $nextques->id;
			 $loca = base_url('exam/testquizstart') ;
			  header("Location: ".$loca);
		}else{
			$arrayName = array(
						   'ttl_marks' =>$_SESSION["ses_ttlGetMarsks"],
							);
		  	$this->db->update('oe_test_record',$arrayName);
		  	$this->db->where(array('user_id'=>$_SESSION["userid"] ,'user_ses_id'=>$_SESSION["ses_usrid"] ));
		  	//session_unset()
		  /*	unset($_SESSION["ses_ttlGetMarsks"]);
		  	unset($_SESSION["ses_pprid"]);
		  	unset($_SESSION["questCounter"]);
		  	unset($_SESSION["ses_ttlqs"]);
		  	unset($_SESSION["question_id"]);*/
			//echo "score id ".$_SESSION["ses_ttlGetMarsks"] ;
			$loca = base_url('exam/test_success') ;
			header("Location: ".$loca);
		}
	}
	


	public function test_success(){

		$userid = $_SESSION['user_id'] ;
		$this->userlogincheck($userid) ;

		$testrecord = $this->db->select('*')->from('oe_test_record')->where(array('user_id'=>$_SESSION["userid"] ,'user_ses_id'=>$_SESSION["ses_usrid"] ))->get()->row();

		$totalQues = $this->db->select('*')->from('oe_testquestions')->where(array('ppr_id'=>$testrecord->paper_id))->get()->result();
		$totalmarks = count($totalQues);
		//print_r($testrecord->paper_id);
			//echo $this->db->last_query();
			//print_r($testrecord) ;
		  $htmlContent = '
		  	<style> .icon-box:hover, .icon-box.active {
				    background: #ecf2f5 !important;
						  		}
				.icon-box:hover .entry-content p, .icon-box.active .entry-content p {
				    color: #262626;
				}
				.icon-box:hover .entry-title, .icon-box.active .entry-title {
				    color: #262626;
				}
						  		</style>
						   <div class="home-page-icon-boxes">
				        <div class="container">
				            <div class="row">
				                <div class="col-12 col-md-12 col-lg-12 mt-4 mt-lg-0 " id="topdiv1">
				                    <div class="icon-box">
				                        <header class="entry-header">
				                            <h3 class="entry-title">Successfully Completed</h3>
				                        </header>

				                        <div class="entry-content">
				                            <p>
				                            	Your Score is
				                            </p>
				                            <p>
				                            	'.$testrecord->ttl_marks.'/'.$totalmarks.'
				                            </p>
				                            <a href="'.base_url("exam/completed").'" style="margin-top:20px"class="btn gradient-bg mr-2">Thanks You</a>
				                        </div>
				                    </div>
				                </div>
				                <div class="col-12 col-md-12 col-lg-12 mt-12 mt-lg-0">
				                </div>
				            </div><!-- .row -->
				        </div><!-- .container -->
				    </div><!-- .home-page-icon-boxes -->';

    	$data['htmldata'] = $htmlContent ;
	    $this->load->view('examhome/header');
		$this->load->view('examhome/paper',$data);
		$this->load->view('examhome/footer');

    	//echo $htmlContent ;
			//		print_r($testrecord) ;
	}
	
	
	
	public function completed(){
			unset($_SESSION["ses_ttlGetMarsks"]);
		  	unset($_SESSION["ses_pprid"]);
		  	unset($_SESSION["questCounter"]);
		  	unset($_SESSION["ses_ttlqs"]);
		  	unset($_SESSION["question_id"]);
			//echo "score id ".$_SESSION["ses_ttlGetMarsks"] ;
			$loca = base_url('exam') ;
			header("Location: ".$loca);
	}
		
	
	public function paymentprocess(){
			$this->load->view('pay/index.php');
	}

	public function payuresponce(){
		$postdata =  $this->input->post() ;
		if(isset($postdata['key'])) {
			$key				=   $postdata['key'];
			$salt				=   $postdata['salt'];
			$txnid 				= 	$postdata['txnid'];
		    $amount      		= 	$postdata['amount'];
			$productInfo  		= 	$postdata['productinfo'];
			$firstname    		= 	$postdata['firstname'];
			$email        		=	$postdata['email'];
			$udf5				=   $postdata['udf5'];
			$mihpayid			=	$postdata['mihpayid'];
			$status				= 	$postdata['status'];
			$resphash				= 	$postdata['hash'];
			$keyString 	  		=  	$key.'|'.$txnid.'|'.$amount.'|'.$productInfo.'|'.$firstname.'|'.$email.'|||||'.$udf5.'|||||';
			$keyArray 	  		= 	explode("|",$keyString);
			$reverseKeyArray 	= 	array_reverse($keyArray);
			$reverseKeyString	=	implode("|",$reverseKeyArray);
			$CalcHashString 	= 	strtolower(hash('sha512', $salt.'|'.$status.'|'.$reverseKeyString));
			     if($resphash == $CalcHashString){
			     	$paymentdata['hash_verified'] = 1 ;
			     }else{
			     	$paymentdata['hash_verified'] = 0 ;
			     }
				if($status == 'success') {
					$paymentdata = array(
	  					'user_id' => $_SESSION['user_id'] ,
	  					'txnid' => $txnid ,
	  					'amount' => $amount,
	  					'productinfo' => $productInfo ,
	  					'firstname' => $firstname ,
	  					'email' => $email  ,
	  					'mihpayid' => $mihpayid ,
	  					'status' => $status ,
	  					'hash' => $resphash ,
	  					'signup_type' => 1 ,
	  					'package_type' => $productInfo,
	  					 'date' => date("d-m-Y") ,
	  				);
					$this->db->insert('payments',$paymentdata);
					$lastid = $this->db->insert_id() ;
					if($lastid){
						 	$this->session->unset_userdata('key');
							$this->session->unset_userdata('salt');
						$userUpdate = array('status' => 1 ,'payment_status' => 1  );

						$this->db->where('user_id',$_SESSION['user_id']);
						$this->db->update('oe_users',$userUpdate) ;
						$contact_no = $_SESSION['mobile'] ;
						//$sms_message = 'ASHG%0AThankyou%20For%20Registration%0AYour%20Loginid:%20'.$_SESSION['fname'].'%0AYour%20Pass.:%20'.$_SESSION['userPassword'] ;
						$sms_message = 'ASHG%0AThankyou%20For%20Registration%0A';
						$smsurl ="http://bulk.bulksmsguru.in/sendsms?uname=lakhanpatelhelp&pwd=lakhan2222&senderid=ASHGCT&to=".$contact_no."&msg=".$sms_message."&route=T" ;
					       file_get_contents($smsurl);
					    /*$this->session->set_userdata('userloginStatus', '1');*/
					    	$userid = $_SESSION['user_id'] ;
					    	$userExist = $this->db->select('*')->from('oe_users')->where(array('user_id'=>$userid))->get()->row();
					    	/*session_start();
						  	 session_destroy();
						 	 unset($_SESSION);
						 	 session_start();*/
						  	$sessiondata = array(
						        'user_id'     => $userExist->user_id,
						        'userFullName'     => $userExist->name,
						        'userEmal'     => $userExist->email,
						        'userConNo'     => $userExist->contact_no,
						        'userStatus'     => $userExist->status,
						        'userPayStatus'     => $userExist->payment_status,
						        'userStartDate'     => $userExist->start_date,
						        'userExpDate'     =>$userExist->exp_date,
							);
					    redirect('exam');
					}
				}
				else {
					$msg = "Payment failed for Hasn not verified...";
				} 
		}else{
			redirect('exam/registration'); 
		}
	}

	public function fail(){
		$this->load->view('pay/fail.php');
	}

	public function profile(){
		$userid = $_SESSION['user_id'] ;
		$this->userlogincheck($userid) ;
		$data['userdata'] = $this->db->select('*')->from('oe_users')->where('user_id',$userid)->get()->row() ;
		$this->load->view('examhome/header');
		$this->load->view('examhome/userprofile.php',$data);
		$this->load->view('examhome/footer');
	}


	public function payments(){
		$userid = $_SESSION['user_id'] ;
		$this->userlogincheck($userid) ;
		$data['userdata'] = $this->db->select('*')->from('oe_users')->where('user_id',$userid)->get()->row() ;
		$data['payments'] = $this->db->select('*')->from('payments')->where('user_id',$userid)->get()->result() ;
		$this->load->view('examhome/header');
		$this->load->view('examhome/userpayments.php',$data);
		$this->load->view('examhome/footer');

	}



	public function bloodgroup(){
		$userid = $_SESSION['user_id'] ;
		$this->userlogincheck($userid) ;
		$data['bloodDonateUser'] = $this->db->select('*')->from('blood_donation_user')->get()->result() ;
		$this->load->view('examhome/header');
		$this->load->view('examhome/bloodgroup.php',$data);
		$this->load->view('examhome/footer');
	}
	public function library(){

		redirect('exam');
		/*$userid = $_SESSION['user_id'] ;
		$this->userlogincheck($userid) ;
		$this->load->view('examhome/header');
		//$this->load->view('examhome/index.php');
		print_r($_SESSION);
		$this->load->view('examhome/footer');*/
	}
	
}
