<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends My_Controller {	
	
	public function __construct() {
        parent::__construct();
        $this->load->model("admin_model");
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
    }
	
	
	
	public function index()
	{
		redirect('admin/login');
	}

	public function login()
	{
		if (!$this->admin_model->admin_checkloggedin()){ 
			$this->load->view('admin/login');
		}else{
			redirect('admin/dashboard');
		}
	}
	
	public function logincheck()
	{
		
		
		$this->form_validation->set_rules('adminUserName', 'User Name is Required', 'required');
		$this->form_validation->set_rules('adminUserPass', 'Password is Required','required');
		$adminUserName = $this->my_model->checkpostinput('adminUserName') ;
		$adminUserPass =  $this->my_model->checkpostinput('adminUserPass') ;
		if ($this->form_validation->run() == TRUE)
		{
		   //echo "login code";
		   $pass = sha1($adminUserPass) ;
		   $where = array('email'=>$adminUserName ,'password'=>$pass )  ;
		   $data = $this->db->select('*')->from(ADMIN)->where($where)->get()->row();
		
		   if(count($data)){
			  	$this->admin_model->admin_session_create($data->id);
				redirect('admin/dashboard');
		   }else{
			   redirect('admin/dashboard');
		   }
		}
		else
		{
			redirect('admin/dashboard');
		}
		
	
	}
	
	public function dashboard(){
		if ($this->admin_model->admin_checkloggedin()){ 
			   $data['userData'] = $this->my_model->getSingeleTable(USERS);

			   $data['page_title'] = 'Activated Users';

			    $data['paymantsData'] =  $this->db->select('*')->from('oe_users')->join('payments', 'oe_users.user_id = payments.user_id', 'inner')->order_by("id", "desc")->get()->result();

			   $totalActiveUser =  $this->db->select('user_id')->from('oe_users')->where('status','1')->get()->result();
			  $totalDeactiveUser =  $this->db->select('user_id')->from('oe_users')->where('status','0')->get()->result();
			   $totalUser =  $this->db->select('user_id')->from('oe_users')->get()->result();
			   $data['totalAmount'] =  $this->db->select_sum('amount')->from('payments')->get()->result();

			   //echo count($totalUser);die();
			     $data['totalActiveUser'] = count($totalActiveUser);
			     $data['totalDeactiveUser'] = count($totalDeactiveUser);
			     $data['totalUser'] = count($totalUser);
			   $this->load->view('users/header.php');
			   $this->load->view('admin/index.php',$data);
			   $this->load->view('users/footer.php');
		}else{
			$this->session->set_flashdata('adUSerPassFlachCheck','<div class="alert alert-danger alert-dismissible">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>User name or password is wrong
			</div>');
			redirect('admin/login');
		}
	}
	
	public function userdetails($user_id){
		if ($this->admin_model->admin_checkloggedin()){ 
			  //echo $user_id ;
			  $data['userData']= $this->my_model->getSingeleRow('users','user_id',base64_decode($user_id)) ;
			  // print_r($data['userData']);
			   $this->load->view('users/header.php');
			   $this->load->view('admin/userdetails.php',$data);
			   $this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}    
	}
	
	public function useractivate(){
		if ($this->admin_model->admin_checkloggedin()){

			  $userStatus = $this->input->post('userStatus');
			  $userId = base64_decode($this->input->post('userID'));
			  /*updateRow($table,$id,$wherecolumn,$arrayData)*/
			     $arraydata = array(
							'status' => $userStatus,
							'updated_at' => date("Y-m-d h:i:s"),
							'renew_at' => date("Y-m-d h:i:s", strtotime("+30 days")),
					);
			    $result = $this->my_model->updateRow('users',$userId,'user_id',$arraydata);
				
				if($result){
					 if($userStatus){
						 $message = 'actvate';
						 $class = 'success';
					 }else{
						 $message = 'deactivate';
						 $class = 'success';
					 }
					$this->session->set_flashdata('adUSerPassFlachCheck','<div class="alert alert-'.$class.' alert-dismissible">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>User Profile is '.$message.'
					</div>');
					$url = 'admin/userdetails/'.$this->input->post('userID');
					redirect($url);
				}else{
					$this->session->set_flashdata('adUSerPassFlachCheck','<div class="alert alert-danger alert-dismissible">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>User Profile is not activate
					</div>');
					$url = 'admin/userdetails/'.$this->input->post('userID');
					redirect($url);
				}
			  	 
		}else{
			redirect('admin/login');
		}
	}
	
	
	/**********************"students"********************/
	public function students(){
		if ($this->admin_model->admin_checkloggedin()){ 
			   $data['userData'] = $this->my_model->getSingeleTable(USERS);
			   $this->load->view('users/header.php');
			   $this->load->view('admin/students.php',$data);
			   $this->load->view('users/footer.php');
		}else{
			$this->session->set_flashdata('adUSerPassFlachCheck','<div class="alert alert-danger alert-dismissible">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>User name or password is wrong
			</div>');
			redirect('admin/login');
		}
	}
	/**********************"library"********************/
	/*rb*/
	
	public function library(){
		if ($this->admin_model->admin_checkloggedin()){ 
			   $data['userData'] = $this->my_model->getSingeleTable(USERS);
			    // $data['users'] = $this->db->select('*')->from('users')->order_by('user_id','ASCE')->get()->result() ;
	  // print_r($data['users']); die;
			   $this->load->view('users/header.php');
			   $this->load->view('admin/library.php',$data);
			   $this->load->view('users/footer.php');
		}else{
			$this->session->set_flashdata('adUSerPassFlachCheck','<div class="alert alert-danger alert-dismissible">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>User name or password is wrong
			</div>');
			redirect('admin/login');
		}
	}
public function user_fees($userid){
	if ($this->admin_model->admin_checkloggedin($userid)){ 
		$data['userData'] =  $this->db->select('*')->from('library_fees')->where('user_id',$userid)->get()->result();
		$this->load->view('admin/header');
		$this->load->view('admin/libraryuser_fees',$data);
		$this->load->view('admin/footer');
	}else{
		$this->session->set_flashdata('adUSerPassFlachCheck','<div class="alert alert-danger alert-dismissible">
		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>User name or password is wrong
		</div>');
		redirect('admin/login');
	}
}
public function addfees($userid){
	if ($this->admin_model->admin_checkloggedin($userid)){ 
		  $data['userId'] = $userid ; 
		  $data['userData'] = $this->db->select('*')->from('users')->where('user_id',$userid)->get()->row();
		  $data['libPackage'] = $this->db->select('*')->from('lib_package')->get()->result();
		$this->load->view('users/header.php');
			$this->load->view('admin/addlib_fees.php',$data);
			$this->load->view('users/footer.php');
	}else{
		redirect('admin/login');
	}
}

public function addlibraryfee($userId){
	if ($this->admin_model->admin_checkloggedin($userid)){ 
		if($userId){
			$data = $this->input->post();
			$this->db->insert('library_fees',$data);
			$lastId = $this->db->insert_id();
			$rediectUrl = 'admin/user_fees/'.$userId ;
			if($lastId){
				$this->session->set_flashdata('adUSerPassFlachCheck','<div class="alert alert-success alert-dismissible">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Add Fees Successfully
				</div>');
				redirect($rediectUrl);
			}else{
				$this->session->set_flashdata('adUSerPassFlachCheck','<div class="alert alert-danger alert-dismissible">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Not Added
				</div>');
								redirect($rediectUrl);

			}
		}
	}else{
		redirect('admin/login');
	}
}





public function addusers(){
   if($this->form_validation->run('users_validation'))
	      {
	      	//$data['userType'] = $this->db->select('blood_group')->from('blood_group')->get()->result() ;
	      	// $data['userData'] = $this->my_model->getSingeleTable(blood_group);
		    $this->load->view('users/header.php');
	          $this->load->view('admin/add_users.php');
	          $this->load->view('users/footer.php');

	         $data = $this->input->post();
	      // print_r($data);
	      //   exit();
	        
	        $target_dir = './uploads/';
                $filename=time().'_'.$_FILES["image"]["name"];
                $target_file = $target_dir.$filename;

                if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                   $image_path=base_url('uploads/'.$filename);
	                $data['image']=$image_path;
                }
	        	        
	        $this->load->model('admin_model');  
	        if($this->admin_model->add_users( $data))
	        return redirect($this->load->view('admin/add_users.php'));
	        
	        }else{
	        $this->load->view('users/header.php');
	          $this->load->view('admin/add_users.php');
	          $this->load->view('users/footer.php');
	        }  	
	
	}

public function updateusers()
	{             
	
	 $id = $this->uri->segment(3);
           // echo"$id";
           
           $this->load->model('admin_model');  
	   $data['usersdata']=$this->admin_model->selectusersbyid($id);
                    
            $this->load->view('users/header.php');        
	    return $this->load->view('admin/update_users',$data);
	    $this->load->view('users/footer.php');
	}




public function updateusersbyid($userid){             
	 //echo"$userid";// exit();
	/* if($this->form_validation->run('users_validation')){ */
		$data = $this->input->post();
		$target_dir = './uploads/';
		$filename=time().'_'.$_FILES["image"]["name"];
		$target_file = $target_dir.$filename;
		if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
		   $image_path=base_url('uploads/'.$filename);
		   $data['image']=$image_path;
		}
		/* nahi chale to comment hata dena pahle dekh lena data aa rah ahain ya nahi*/
		 //print_r($data); die; 
		
		$this->db->where('user_id',$userid) ;
		$responce = $this->db->update('users',$data);
		  //echo $this->db->last_query() ;die;
		/*$this->load->model('admin_model');  */
		if($responce){
			$this->session->set_flashdata('success','Update Successfull');
			return redirect('admin/updateusers/1');
		}else{
			$this->session->set_flashdata('failure','Not Updated');
			return redirect('admin/updateusers/1');
		}   
	/* }else{
		$this->load->view('users/header.php');        
		$this->load->view('admin/update_users/1',$data);
		$this->load->view('users/footer.php');
	}   */
}
public function deleteusers($userid){
		//echo $userid ;
		$this->db->where('user_id',$userid) ;
		$this->db->update('users',array('delete_status' =>0));
		$this->session->set_flashdata('resMessage','user deleted');
		// $this->session->set_flashdata('addusersSession', '<p><b class="text-danger">Deleted</b></p>');
		redirect('admin/library');
		// $json = array('status'=>1 ) ;
		// echo json_encode($json);
}


// 	public function updateusersbyid($userid)
// 	{             
// 	 // echo"$userid";
// 	 // exit();
// 	if($this->form_validation->run('users_validation'))
// 	 {
// 	 $data = $this->input->post();
// 	 //echo"$data";
// 	 //exit();
// 	        $target_dir = './uploads/';
//                 $filename=time().'_'.$_FILES["image"]["name"];
//                 $target_file = $target_dir.$filename;

//                 if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
//                    $image_path=base_url('uploads/'.$filename);
// 	               $data['image']=$image_path;
//                 } 
// 	 $this->load->model('admin_model');  
// 	  if($this->admin_model->update_usersbyid($userid,$data)){
// 	  $this->session->set_flashdata('success','Update Successfull');
// 	  return redirect('Admin/library');
// 	  }else{
// 	  $this->session->set_flashdata('failure','Not Updated');
// 	  return redirect('Admin/library');
// 	  }   
// 	  }else{
// 	        $this->load->view('users/header.php');        
// 	        $this->load->view('admin/update_users');
// 	        $this->load->view('users/footer.php');
// 	        }  
// 	}

// public function deleteusers($userid)
// 	{
	  
//     	//echo $userid ;
//     	$this->db->where('user_id',$userid) ;
// 		$this->db->update('users',array('delete_status' =>0));
// 		// $this->session->set_flashdata('addusersSession', '<p><b class="text-danger">Deleted</b></p>');
// 	            redirect('admin/library');
// 		// $json = array('status'=>1 ) ;
// 		// echo json_encode($json);


//	}


	/*rb*/ 
	/*********************"members"*********************/
	
	public function members(){
		if ($this->admin_model->admin_checkloggedin()){ 
			   $data['userData'] = $this->my_model->getSingeleTable(USERS);
			   $this->load->view('users/header.php');
			   $this->load->view('admin/members.php',$data);
			   $this->load->view('users/footer.php');
		}else{
			$this->session->set_flashdata('adUSerPassFlachCheck','<div class="alert alert-danger alert-dismissible">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>User name or password is wrong
			</div>');
			redirect('admin/login');
		}
	}
	
	/**********************"payments"********************/
	public function payments(){
		if ($this->admin_model->admin_checkloggedin()){ 
			   $data['userData'] = $this->my_model->getSingeleTable(USERS);
			   $data['paymantsData'] =  $this->db->select('*')->from('oe_users')->join('payments', 'oe_users.user_id = payments.user_id', 'inner')->order_by("id", "desc")->get()->result();
			   $data['totalAmount'] =  $this->db->select_sum('amount')->from('payments')->get()->result();
			   $totalActiveUser =  $this->db->select('user_id')->from('oe_users')->where('status','1')->get()->result();
			  $totalDeactiveUser =  $this->db->select('user_id')->from('oe_users')->where('status','0')->get()->result();
			   $totalUser =  $this->db->select('user_id')->from('oe_users')->get()->result();

			   //echo count($totalUser);die();
			     $data['totalActiveUser'] = count($totalActiveUser);
			     $data['totalDeactiveUser'] = count($totalDeactiveUser);
			     $data['totalUser'] = count($totalUser);
			   $this->load->view('users/header.php');
			   $this->load->view('admin/userpaymants.php',$data);
			   $this->load->view('admin/footer.php');
		}else{
			$this->session->set_flashdata('adUSerPassFlachCheck','<div class="alert alert-danger alert-dismissible">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>User name or password is wrong
			</div>');
			redirect('admin/login');
		}
	}
	/*********************"birthday"*********************/
	
	public function birthday(){
		if ($this->admin_model->admin_checkloggedin()){ 
			   $data['userData'] = $this->my_model->getSingeleTable(USERS);
			   $this->load->view('users/header.php');
			   $this->load->view('admin/birthday.php',$data);
			   $this->load->view('users/footer.php');
		}else{
			$this->session->set_flashdata('adUSerPassFlachCheck','<div class="alert alert-danger alert-dismissible">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>User name or password is wrong
			</div>');
			redirect('admin/login');
		}
	}
	
	
	/*********************"bloodgroup"*********************/
	
	public function bloodgroup(){
		if ($this->admin_model->admin_checkloggedin()){ 
			   $data['userData'] = $this->my_model->getSingeleTable(USERS);
			   $data['bloodDonateUser'] = $this->db->select('*')->from('blood_donation_user')->get()->result() ;

			  // print_r($data['bloodDonateUser']); die;
			   $this->load->view('users/header.php');
			   $this->load->view('admin/bloodgroup.php',$data);
			   $this->load->view('admin/footer.php');
		}else{
			$this->session->set_flashdata('adUSerPassFlachCheck','<div class="alert alert-danger alert-dismissible">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>User name or password is wrong
			</div>');
			redirect('admin/login');
		}
	}

	/*********************"exam user Enquiry"*********************/
		
		public function enquiry(){
			if ($this->admin_model->admin_checkloggedin()){ 
				   $data['userData'] = $this->my_model->getSingeleTable(USERS);
				   $data['enquiry'] = $this->db->select('*')->from('enquiry')->order_by('enquiry_id','DESC')->get()->result() ;
				   $this->load->view('users/header.php');
				   $this->load->view('admin/enquiry.php',$data);
				   $this->load->view('users/footer.php');
			}else{
				$this->session->set_flashdata('adUSerPassFlachCheck','<div class="alert alert-danger alert-dismissible">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>User name or password is wrong
				</div>');
				redirect('admin/login');
			}
		}


	/*************************************"examsusers"************************************/
public function examsusers($status = ''){
		$condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
			if($status == 1){ 
				$data['messageTitle'] = 'All Acitvated Students Information' ;
				$data['userData'] = $this->db->select('*')->from('oe_users')->where('status',1)->order_by('user_id','desc')->get()->result() ;

			 
			}elseif($status == 2){
				$data['messageTitle'] = 'Deacivated Students Information' ;
				$data['userData'] = $this->db->select('*')->from('oe_users')->where('status',0)->order_by('user_id','desc')->get()->result() ;
			}else{
				$data['messageTitle'] = 'Students Information' ;
				$data['userData'] = $this->db->select('*')->from('oe_users')->order_by('user_id','desc')->get()->result() ;
			}
			 $data['userData'] =  $this->db->select('*')->from('oe_users')->join('payments', 'oe_users.user_id = payments.user_id', 'inner')->order_by("id", "desc")->get()->result();
			 
			$this->load->view('users/header.php');
			$this->load->view('admin/oe_users.php',$data);
			$this->load->view('admin/footer.php');
		}else{
			redirect('admin/login');
		}
}

public function activate_exam_user(){
		$condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
			$data['userData'] = $this->db->select('*')->from('oe_users')->where('status',1)->order_by('user_id','desc')->get()->result() ;
			$data['page_title'] = 'Activate Users';
			$this->load->view('users/header.php');
			$this->load->view('admin/activate_exam_user.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
}
public function deactivate_exam_user(){
		$condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
			$data['userData'] = $this->db->select('*')->from('oe_users')->where('status',0)->order_by('user_id','desc')->get()->result() ;
			$data['page_title'] = 'Deactivate Users';
 			$this->load->view('users/header.php');
			$this->load->view('admin/activate_exam_user.php',$data);
			$this->load->view('users/footer.php');
		}else{
			redirect('admin/login');
		}
}


public function examuseractivate($userid){
		$condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
			$user_id = base64_decode($userid) ;
			$userData = $this->db->select('*')->from('oe_users')->where('user_id',$user_id)->get()->row();
			if(count($userData)){
					 $userUpdate = array('status'=>1,'payment_status'=>1 );
              		$this->db->where('user_id',$user_id) ;
              		$this->db->update('oe_users',$userUpdate) ;
              		$message = 'Updated '.$userData->name.' account';
              	$this->session->set_flashdata('messageRes',$message);
              	$userPass = base64_decode($userData->userpassword);
              	$contact_no = $userData->contact_no;
				$sms_message = 'ASHG%0AThankyou%20For%20Registration%0AYour%20Login%20Detail%0AUsername:'.$userData->email.'%0APassword:'.$userPass;
					$smsurl ="http://bulk.bulksmsguru.in/sendsms?uname=lakhanpatelhelp&pwd=lakhan2222&senderid=ASHGCT&to=".$contact_no."&msg=".$sms_message."&route=T" ;
		        	file_get_contents($smsurl);
		        	if($userData->package_type == 1){
            	    	$expiradate = date('d-m-Y', strtotime("+30 days")) ;
            	    }elseif($userData->package_type == 2){
            	    	$expiradate = date('d-m-Y', strtotime("+60 days")) ;
            	    }elseif($userData->package_type ==3){
            	    	$expiradate = date('d-m-Y', strtotime("+90 days")) ;
            	    }

            	    $reg_charge =  $this->db->select('cahrge_rupee')->from('registration_charge')->where(array('charge_id' => 1 ))->get()->row() ;
            	  // echo $regpackageId ; die;
            	   $regpackage =  $this->db->select('*')->from('oe_package')->where(array('pack_id' => $userData->package_type ))->get()->row() ;

            	   	$number  = $reg_charge->cahrge_rupee + $regpackage->charge_rupee ;
            	   	$amount= number_format((float)$number, 2, '.', '');

		         $paymentArray = array(
		         		'user_id'=>  $user_id ,
		         		'txnid'=>  time() ,
		         		'amount'=>  $amount ,
		         		'productinfo'=>  $userData->package_type ,
		         		'firstname'=> $userData->name ,
		         		'email'=>  $userData->email ,
		         		'status'=>  'success' ,
		         		'signup_type'=>  1 ,
		         		'package_type'=> $userData->package_type ,
		         		'date'=> date("d-m-Y")  ,
		         		'exp_date'=>  $expiradate ,
		         ) ;
		        $this->db->insert('payments',$paymentArray);
                redirect('admin/examsusers');
			}else{
				redirect('admin/examsusers');
			}
			//print_r($userData);
			/*$this->load->view('users/header.php');
			$this->load->view('admin/oe_users.php',$data);
			$this->load->view('users/footer.php');*/
		}else{
			redirect('admin/login');
		}
}



/*************************************"examsusers-varifiaction"************************************/
public function user_varifiaction(){
		$condition =(
			($this->session->userdata('logintype') == 'admin') && 
			($this->session->userdata('status') == 1) && 
			($this->session->userdata('logged_in') == 1 )
		);
		if($condition){ 
			$data['userData'] = $this->db->select('*')->from('oe_payment_varification')->order_by('id','desc')->get()->result() ;
			$this->load->view('users/header.php');
			$this->load->view('admin/oe_testuser_varifiaction.php',$data);
			$this->load->view('users/footer.php');
			//echo "sdnasd";
		}else{
			redirect('admin/login');
		}
}

	
	/*********************"events"*********************/
	
	public function addevents()
	{             
	      
	      if($this->form_validation->run('events_validation'))
	      {
		  $this->load->view('users/header.php');
	          $this->load->view('admin/add_events.php');
	          $this->load->view('users/footer.php');
		
	        $post = $this->input->post();
	        //print_r($post);
	        //exit();
	        
	        $target_dir = './uploads/';
                $filename=time().'_'.$_FILES["userfile"]["name"];
                $target_file = $target_dir.$filename;

                if (move_uploaded_file($_FILES["userfile"]["tmp_name"], $target_file)) {
                   $image_path=base_url('uploads/'.$filename);
	               $post['image_path']=$image_path;
                }
	        
	        
	         $this->load->model('admin_model');  
	        if($this->admin_model->add_events($post))
	        return redirect($this->load->view('admin/add_events.php'));
	        
	        }else{
	        $this->load->view('users/header.php');
	          $this->load->view('admin/add_events.php');
	          $this->load->view('users/footer.php');
	        }  
	       
	}

	public function events()
	{             
	      $this->load->model('admin_model');  
	       $data['eventsdata']=$this->admin_model->selectevents();  
	       
		           $this->load->view('users/header.php');
			   $this->load->view('admin/events.php',$data);
			   $this->load->view('users/footer.php');
	}

	public function updateevents()
	{             
	
	 $id = $this->uri->segment(3);
           // echo"$id";
           
           $this->load->model('admin_model');  
	   $data['eventsdata']=$this->admin_model->selecteventsbyid($id);
                    
            $this->load->view('users/header.php');        
	    return $this->load->view('admin/update_events',$data);
	    $this->load->view('users/footer.php');
	}


	public function updateeventsbyid($eventid)
	{             
	
	//echo"$eventid";
	//exit();
	
	if($this->form_validation->run('events_validation'))
	 {
	 $post = $this->input->post();
	 //echo"$post";
	 //exit();
	 
	        $target_dir = './uploads/';
                $filename=time().'_'.$_FILES["userfile"]["name"];
                $target_file = $target_dir.$filename;

                if (move_uploaded_file($_FILES["userfile"]["tmp_name"], $target_file)) {
                   $image_path=base_url('uploads/'.$filename);
	               $post['image_path']=$image_path;
                } 
	 

	 $this->load->model('admin_model');  
	  if($this->admin_model->update_eventsbyid($eventid,$post)){
	  
	  $this->session->set_flashdata('success','Update Successfull');
	  return redirect('Admin/events');
	  
	  }else{
	  $this->session->set_flashdata('failure','Not Updated');
	  return redirect('Admin/events');
	  }   
	  
	  }else{
	        $this->load->view('users/header.php');        
	        $this->load->view('admin/events');
	        $this->load->view('users/footer.php');
	        }  

	}

 	
	public function deleteevents($eventid)
	{
	
	 //$id=$this->input->post('id');
	 $this->load->model('admin_model');
	 
	  if($this->admin_model->delevents($eventid)){
	  $this->session->set_flashdata('success','Delete Successfull');
	  return redirect('Admin/events');
	  
	  }else{
	  $this->session->set_flashdata('failure','Not Deleted');
	  return redirect('Admin/events');
	  }

	}

	/***************************************"Currnt Facts"*******************************************/
	public function currentFacts(){
			$data['currentFacts2'] = $this->db->select('*')->from('current_news')->where('status',1)->order_by('id','desc')->get()->result() ;
			//print_r($data['currentFacts']); die;
			$data['page_title'] = 'Current facts';
			$this->load->view('users/header.php');
			$this->load->view('admin/current_news.php',$data);
			$this->load->view('users/footer.php');
	}
	public function addCurrentFacts($message){
			if($message ==1){
				$data['page_title'] = 'Current facts';
				$data['message'] = $message;/*1*/
				$this->load->view('users/header.php');
				$this->load->view('admin/addEditCurrentNews.php',$data);
				$this->load->view('users/footer.php');
			}else{
				$data['page_title'] = 'Edit Current facts';
				$data['message'] = $message;/*2*/
				$this->load->view('users/header.php');
				$this->load->view('admin/addEditCurrentNews.php',$data);
				$this->load->view('users/footer.php');
			}
			
	}

}
