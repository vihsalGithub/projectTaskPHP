<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends My_Controller {

   function __construct(){
		parent::__construct();
		$this->load->model('home_model');
	} 

   /* public function index()
	{
		// $this->load->model('ome_model');
		if (!$this->my_model->user_session_check()){ 
			$this->load->view('front/index.php');
		}else{
			redirect('user');
		}
	}  */
	 public function mailcontact()
	{
		echo $this->home_model->mailcontact();
	} 
	
	public function index()
	{
		// $this->load->model('ome_model');
		if (!$this->my_model->user_session_check()){ 
			$this->load->view('login');
		}else{
			redirect('user');
		}
	}
	public function login()
	{
		if ( ! $this->my_model->user_session_check()){ 
			$this->load->view('login');
		}else{
			redirect('user');
		}
	}
	
	/* view of registration form*/
	public function registration()
	{
		if ( ! $this->my_model->user_session_check()){ 
			$this->load->library('form_validation');
			$this->load->view('register');
		}else{
			redirect('user');
		}
	}
	
	/* register value of user */
	public function registration_form(){
		  echo $this->home_model->registration_form();
	}
	
	/* login of user in panel*/
	public function logincheck(){
		$userName = $this->test_input($this->input->post('userName'));
		$userPass = $this->test_input($this->input->post('userPass'));
		$pass = sha1($userPass) ;
		$condition = array('email'=> $userName , 'password' => $pass ) ;

		$data = $this->db->select('*')->from(USERS)->where($condition)->get()->row() ;

		
		//die;
		if($data){
			$this->home_model->user_session_create($data->user_id) ;
			echo base_url('home/login') ;
		}else{

			//echo 'asdnasjnsd';die;
			$this->session->set_flashdata('loginfailed','<div class="alert alert-danger alert-dismissible">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>User name or password is wrong
			</div>');
			echo base_url('home/login') ;
		} 
	}
	

	function referral($token){
		$data =  $this->my_model->loggedInUser();
		if(!empty($data->status)){
			
			$token = base64_decode($token);
			$tokenArray     = explode('_', $token);
			$reffrelUserId = $tokenArray[0];
			$token  = $tokenArray[1];
              $_SESSION['reffrelUserId'] =   $tokenArray[0];
              $_SESSION['reffrelToken'] =   $tokenArray[1];

		}else{
	        
         	redirect('home/registration') ;
		}
		
	}
	
	/*
	public function registration_form_funbackub(){
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->form_validation->set_rules('firstName', 'First Name', 'required');
		$this->form_validation->set_rules('lastName', 'Last Name', 'required');
		$this->form_validation->set_rules('inputPassword', 'Password', 'required');
		$this->form_validation->set_rules('confirmPassword', 'Password Confirmation', 'required');
		$this->form_validation->set_rules('inputEmail', 'Email', 'required');
		if ($this->form_validation->run() == TRUE)
		{
		  $data =	$this->home_model->registration_form();
		  //echo $data ;
		}
		else
		{
			$this->load->view('register');
		}
	}*/
	
	
	
}
