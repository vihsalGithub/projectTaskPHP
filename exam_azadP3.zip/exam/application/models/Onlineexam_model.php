<?php
class Onlineexam_model extends My_Model {
      

	public function examsdashboard(){
		//	getFilterTable($table,$selectcolumn='',$wherecolumn, $id)
	 $data['oe_categuty'] = $this->my_model->getSingeleTable(OE_CATEGORY);
	 $data['oe_subjects'] = $this->my_model->getSingeleTable(OE_SUBJECT);
	 $data['oe_questions'] = $this->my_model->getSingeleTable(OE_QUESTIONS);
	 
	    return $data ;
	} 
	
	public function questionGroupBy(){
		$this->db->select('oe_subjects.id ,oe_subjects.name,count(oe_questions.sub_id) as total_ques');
		$this->db->from('oe_questions');
		$this->db->join('oe_subjects' , 'oe_subjects.id = oe_questions.sub_id');
		$this->db->group_by('oe_questions.sub_id') ;
		$this->db->where(array('oe_subjects.status'=>1));
		$query = $this->db->get();
		$resultDetails = $query->result();
		return $resultDetails ;
	}
	public function addpapers(){
		// print_r($this->input->post()); die ;
		 //$chackSub = json_encode($this->input->post('chackSub'));
		// echo $chackSub;die;
		 //die;
		 $pprName = $this->my_model->checkpostinput('pprName');
		 $pprSufx = $this->my_model->checkpostinput('pprSufx');
		 $pprCat = $this->my_model->checkpostinput('pprCat');
		 $ttlmarks = $this->my_model->checkpostinput('ttlmarks');
		 $minMarks = $this->my_model->checkpostinput('minMarks');
		 $ttlTime = $this->my_model->checkpostinput('ttlTime');
		 $chackSub = json_encode($this->input->post('chackSub'));
		 $insertdata = array(
					'cat_id'=> $pprCat ,
					'sub_id'=> $chackSub ,
					'name'=> $pprName ,
					'sufix_name'=> $pprSufx ,
					'total_marks'=> $ttlmarks ,
					'minmum_marks'=> $minMarks ,
					'exam_time_period'=> $ttlTime ,
					'total_time'=> $pprCat ,
					'created_date'=> date("Y-m-d H:i:s") ,
		 );
		 $insertUserData = $this->db->insert(OE_PAPERS,$insertdata);
		 $count = $this->db->insert_id();
		 if($count >0 ){
				$userId = $this->db->insert_id() ;
				$data['status'] = TRUE;
				$data['last_id'] = $userId;
				$data['message'] = "paper added.";
				return $data ;
		}else{
				$data['status'] = false;
				$data['message'] = "Something went wrong for registration.";
				return $data ;
		}
	}



}
?>