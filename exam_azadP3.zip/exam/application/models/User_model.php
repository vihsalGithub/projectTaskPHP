<?php
class User_model extends My_Model {
	
	
	public function profileform()
	{
		$fatherUP = $this->my_model->checkpostinput('fatherUP') ;
		$addressUP = $this->my_model->checkpostinput('addressUP') ;
		$stateUP = $this->my_model->checkpostinput('stateUP');
		$cityUP = $this->my_model->checkpostinput('cityUP');
		$pincodeUP = $this->my_model->checkpostinput('pincodeUP') ;
		$bloodgroupUP = $this->my_model->checkpostinput('bloodgroupUP') ;
        $userID = $this->my_model->checkpostinput('userID') ;
		$qualificationUP = $this->my_model->checkpostinput('qualificationUP') ;
		$userID  = base64_decode($userID);

				$config['file_name']          = time();
				$config['upload_path']          = './uploads/users/';
                $config['allowed_types']        = 'gif|jpg|png';
                 $this->load->library('upload', $config);
         		if ($this->upload->do_upload('imageUP'))
                {
                	$upload_data = $this->upload->data(); 
					$file_name = $upload_data['file_name'];
                	$image = '/uploads/users/'.$file_name ;
                        
                }else{
                	$image = '' ;
                }

                $data = array(
                		'image' =>$image   ,
                		'father_name' => $fatherUP ,
                		'address' => $addressUP ,
                		'blood_group' => $bloodgroupUP ,
                		'state' => $stateUP ,
                		'city' => $cityUP ,
                        'pincode' => $pincodeUP ,
                		'qualifiaction' => $qualificationUP ,
                		'country' => "india" ,
                		'updated_at' => date("Y-m-d H:i:s") ,
                		'reffrence_by' => '1' ,
                		 );
                	$this->db->where('user_id', $userID);
					$this->db->update('users', $data);
                
	}
	
	
}