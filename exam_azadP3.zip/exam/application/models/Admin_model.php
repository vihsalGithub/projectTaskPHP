<?php
class Admin_model extends My_Model {
      


 public function admin_session_create($userId)
	{
		$adminData = $this->db->select('*')->from(ADMIN)->where('id',$userId)->get()->row();
		  	$admin_id = base64_encode($adminData->id);
            $first_name = $adminData->first_name;
            $last_name = $adminData->last_name;
            $email = $adminData->email;
            $type = $adminData->type;
            $status = $adminData->status;
            $image = $adminData->image;
			$session = array(
                    'admin_id' => $admin_id,
                    'token' => $admin_id ,
                    'status' => $status ,
                    'user_name' => $first_name . " " . $last_name,
                    'email' => $email,
                    'image' => $image,
                    'logintype' => "admin",
                    'logged_in' => true,

            );
         	$this->session->set_userdata($session);
	}
    public function admin_checkloggedin() {
        if ($this->session->userdata('token') && $this->session->userdata('user_name') && $this->session->userdata('email') && $this->session->userdata('logintype')) {
            $token = $this->session->userdata('token');
            $user_name = $this->session->userdata('user_name');
            $logintype = $this->session->userdata('logintype');
            $email = $this->session->userdata('email');
            if (trim($logintype) == "admin" && trim($user_name) != "" && trim($token) != "" && trim($email) != "") {
                return 1;
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    }


    public function add_events($post)
    {

     if($this->db->insert('add_events',$post)){
     $this->session->set_flashdata('success','Events Added Successfully');
     return redirect('Admin/addevents');
     }else{
     $this->session->set_flashdata('failure','Events Not Added');
     return redirect('Admin/addevents');
     }
       
    }

    public function selectevents()
    {
      $query = $this->db->get('add_events');  
         return $query->result(); 
    }

   public function selecteventsbyid($id)
    {
      $query = $this->db->where('id',$id)->get('add_events');  
         return $query->result(); 
    }
    
    
    public function update_eventsbyid($eventid,array $product)
    {
    return $this->db->where('id',$eventid)
              ->update('add_events',$product);
          
    }
    
    public function delevents($eventid)
    {
    return $this->db->delete('add_events',['id'=>$eventid]);
        
    }
    
/*  rb  */
  public function add_users($data)
    {

     if($this->db->insert('users',$data)){
     $this->session->set_flashdata('success','User Added Successfully');
     return redirect('Admin/addusers');
     }else{
     $this->session->set_flashdata('failure','User Not Added');
     return redirect('Admin/addusers');
     }
       
    }
     public function selectusersbyid($user_id)
    {
      $query = $this->db->where('user_id',$user_id)->get('users');  
         return $query->result(); 
    }

public function update_usersbyid($userid,array $product)
    {
    return $this->db->where('user_id',$userid)
              ->update('users',$product);
          
    }

    public function delusers($userid)
    {
    return $this->db->delete('users',['user_id'=>$userid]);
        
    }
     /* rb */


}
?>