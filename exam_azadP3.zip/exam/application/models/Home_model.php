<?php
class Home_model extends My_Model {
	
	public function user_session_check(){
		if($this->session->userdata('logged_in') AND ($this->session->userdata('logintype') == 'user')){
			return true;
		}else{
			return false;
		}
	}



    public function user_session_create($userId)
	{
		$userData = $this->db->select('*')->from(USERS)->where('user_id',$userId)->get()->row();
		  	$user_id = base64_encode($userData->user_id);
            $first_name = $userData->first_name;
            $last_name = $userData->last_name;
            $email = $userData->email;
            $type = $userData->type;
            $status = $userData->status;
			$session = array(
                    'user_id' => $user_id,
                    'token' => $user_id ,
                    'status' => $status ,
                    'user_name' => $first_name . " " . $last_name,
                    'email' => $email,
                    'logintype' => "user",
                    'logged_in' => true,

            );
         	$this->session->set_userdata($session);
	}
	
	public function mailcontact(){
		$contactname = $this->input->post('contactname');
		$contactemail = $this->input->post('contactemail');
		$contactsubject = $this->input->post('contactsubject');
		$contactmessage = $this->input->post('contactmessage');
		$contactnumber = $this->input->post('contactnumber');
		if(empty($contactname) || empty($contactemail) || empty($contactsubject) || empty($contactmessage)|| empty($contactnumber)){
			$data['status'] = FALSE;
			$data['message'] = "<p class='alert alert-danger mt10' >Please fill all text field</p>";
			return json_encode($data);
		}
		if(!$this->my_model->valid_email($contactemail)){
		 	$data['status'] = FALSE;
			$data['message'] = "<p class='alert alert-danger mt10'>Invalid email. Please try again.</p>";
			return json_encode($data);
		} 
		if(!$this->my_model->valid_mobile($contactnumber)){
				 	$data['status'] = FALSE;
					$data['message'] = "<p class='alert alert-danger mt10'>Invalid Contact. Please try again.</p>";
					return json_encode($data);
		} 

		
		$arrayEnquiry = array(
					'name' => $contactname,
					'email' => $contactemail,
					'subject' => $contactsubject,
					'message' => $contactmessage,
					'contact' => $contactnumber,
                	'created_at' => date("Y-m-d H:i:s") ,
				);
		$insertEnquiryData = $this->db->insert(ENQUIRY,$arrayEnquiry);
			if($this->db->insert_id()){
				$data['status'] = TRUE;
				$data['message'] = "<p class='alert alert-success mt10'>Thank You! We will contact with you soon.</p>";
				return json_encode($data);
			}else{
				$data['status'] = FALSE;
				$data['message'] = "<p class='text-danger mt10'>Something went wrong</p>";
				return json_encode($data);
			}


	}
	public function registration_form(){
		
		$firstName = $this->my_model->checkpostinput('firstName') ;
		$lastName = $this->my_model->checkpostinput('lastName') ;
		$inputEmail = $this->my_model->checkpostinput('inputEmail') ;
		$contactNo = $this->my_model->checkpostinput('contactNo') ;
		$inputPassword = $this->my_model->checkpostinput('inputPassword');
		$userAddress = $this->my_model->checkpostinput('userAddress') ;
		 
		$where = "email='$inputEmail' OR contact_no ='$contactNo' ";	
		$returnData = $this->user_data($inputEmail,$contactNo,$inputEmail,$where);
		$num = count($returnData);
		/* echo $num;		print_r($returnData); */
		if($num > 0){
			$data['status'] = false;
			$data['message'] = "This user name is already exist.";
			return json_encode($data);
		}else{

			  if(!empty($_SESSION['reffrelUserId'])){
			  	  $reffrelId = $_SESSION['reffrelUserId'] ;
			  }else{
			  	  $reffrelId = '' ;
			  }
			$arrayUser = array(
					'first_name' => $firstName,
					'last_name' => $lastName,
					'user_name' => $inputEmail,
					'email' => $inputEmail,
					'contact_no' => $contactNo,
					'password' => sha1($inputPassword),
					'address' => $userAddress,
					'reffrence_by' =>$reffrelId,
                	'created_at' => date("Y-m-d H:i:s") ,
				);
			$insertUserData = $this->db->insert(USERS,$arrayUser);
			$count = $this->db->insert_id();
			   if(!empty($_SESSION['reffrelToken'])){
				   	$arrayReffrence = array(
						'user_id_reg' => $this->db->insert_id(),
						'reffrel_by' => $_SESSION['reffrelToken'],
						'reffrel_token' =>$_SESSION['reffrelUserId'],
					);
				 	$this->db->insert(REFFRENCE_TBL,$arrayReffrence);
			   }
			if($count >0 ){
				$userId = $this->db->insert_id() ;
				$this->user_session_create($userId) ;
				$data['status'] = TRUE;
				$data['url'] = base_url('user');
				$data['message'] = "Rggistered Successfully.";
				return json_encode($data);
			}else{
				$data['status'] = false;
				$data['message'] = "Something went wrong for registration.";
				return json_encode($data);
			}
		}
		
		 
	}
	
	
	
}