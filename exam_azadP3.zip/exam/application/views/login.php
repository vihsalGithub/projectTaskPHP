<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo SITETITLE ?></title>
      <link rel="icon" href="<?php echo base_url('uploads/ashg/logo.jpg') ; ?>" type="image/gif" sizes="16x16">


    <!-- Bootstrap core CSS-->
	
    <link href="<?php echo base_url() ; ?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="<?php echo base_url() ; ?>/assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template-->
    <link href="<?php echo base_url() ; ?>/assets/css/sb-admin.css" rel="stylesheet">
    <link href="<?php echo base_url() ; ?>/assets/css/custom.css" rel="stylesheet">
	
	
    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url() ; ?>/assets/vendor/jquery/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="<?php echo base_url() ; ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url() ; ?>/assets/js/custom.js"></script>

  <body class="bg-dark">

    <div class="container">
      <div class="card card-login mx-auto mt-5">
        <div class="card-header">Login</div>
        <div class="card-body">
          <div class="col-sm-12">          
                        <img class=" imgcenter " width="100px"  src="<?php echo base_url() ?>/<?php  
                         
                            echo 'uploads/ashg/logo.jpg';
                       
                         ?>">
          </div>
          <div><?php echo $this->session->flashdata('loginfailed'); ?></div>
          <form id="login_form" method="post" action="">
            <div class="form-group">
              <div class="form-label-group">
                <input type="text" id="userName" name="userName" class="form-control" placeholder="Email address" required="required" autofocus="autofocus">
                <label for="userName">User Name</label>
              </div>
            </div>
            <div class="form-group">
              <div class="form-label-group">
                <input type="Password" id="userPass" name="userPass" class="form-control" placeholder="Password" required="required hell">
                <label for="userPass">Password</label>
              </div>
            </div>
            <div class="form-group">
              <div class="checkbox">
                <label>
                  <input type="checkbox" value="remember-me">
                  Remember Password
                </label>
              </div>
            </div>
			         <input class="btn btn-primary btn-block"  type="submit" value="Login" />
          </form>
          <div class="text-center">
            <a class="d-block small mt-3" href="<?php echo base_url('home/registration') ; ?>">Register an Account</a>
            <a class="d-block small display-none" href="<?php echo base_url('home/forgetpassword') ; ?>">Forgot Password?</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url() ; ?>/assets/vendor/jquery-easing/jquery.easing.min.js"></script>

  </body>

</html>
