<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo SITETITLE ?></title>
    <link rel="icon" href="<?php echo base_url('uploads/ashg/logo.jpg') ; ?>" type="image/gif" sizes="16x16">


    <!-- Bootstrap core CSS-->
    <link href="<?php echo base_url() ; ?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="<?php echo base_url() ; ?>/assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template-->
    <link href="<?php echo base_url() ; ?>/assets/css/sb-admin.css" rel="stylesheet">
    <link href="<?php echo base_url() ; ?>/assets/css/custom.css" rel="stylesheet">

	 
    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url() ; ?>/assets/vendor/jquery/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="<?php echo base_url() ; ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url() ; ?>/assets/js/custom.js"></script>

  </head>

  <body class="bg-dark">

    <div class="container">
      <div class="card card-register mx-auto mt-5">
        <div class="card-header">Register an Account</div>
		<?php echo validation_errors(); ?>
        <div class="card-body">
            <div class="col-sm-12">          
                        <img class=" imgcenter " width="100px"  src="<?php echo base_url() ?>/<?php  
                         
                            echo 'uploads/ashg/logo.jpg';
                       
                         ?>">
          </div>
		<?php //echo base_url('home/registration_form') ?>
		  <div id="messageBoxDiv"></div>
          <form id="registration_form" enctype="multipart/form-data">
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="firstName" name="firstName" class="form-control" placeholder="First name"  autofocus="autofocus">
                    <label for="firstName">First name</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="lastName" name="lastName"  class="form-control" placeholder="Last name" >
                    <label for="lastName">Last name</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="form-label-group">
                <input type="email" id="inputEmail" name="inputEmail" class="form-control" placeholder="Email address" >
                <label for="inputEmail">Email address</label>
              </div>
            </div>
			 <div class="form-group">
              <div class="form-label-group">
                <input type="text" id="contactNo" name="contactNo" minimum="10" class="form-control" placeholder="Contact Number" >
                <label for="contactNo">Contact Number</label>
              </div>
            </div>
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="password" id="inputPassword" name="inputPassword" class="form-control" placeholder="Password" >
                    <label for="inputPassword">Password</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="password" id="confirmPassword" name="confirmPassword" class="form-control" placeholder="Confirm password" >
                    <label for="confirmPassword">Confirm password</label>
                  </div>
                </div>
              </div>
            </div>
			       <div class="form-group">
              <div class="form-label-group">
                <input type="text" id="userAddress" name="userAddress" class="form-control" placeholder="userAddress" >
                <label for="userAddress">User Address</label>
              </div>
            </div>
			<!-- <div class="form-group">
              <div class="form-label-group">
                <input type="file" id="userImage" name="userImage" class="form-control" placeholder="userimage" >
                <label for="inputEmail">User Profile Image</label>
              </div>
            </div> -->
			<input type="submit" id="frmregistration" name="frmregistration" class="btn btn-primary btn-block" value="Register">
		  </form>
          <div class="text-center">
           <a class="d-block small mt-3" href="<?php echo base_url('home/login') ; ?>">Login</a>
            <a class="d-block small display-none" href="<?php echo base_url('home/forgetpassword') ; ?>">Forgot Password?</a>          </div>
        </div>
      </div>
    </div>

   

    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url() ; ?>/assets/vendor/jquery-easing/jquery.easing.min.js"></script>


  </body>

</html>
