<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title><?php echo SITETITLE ?></title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Facebook Opengraph integration: -->
  <meta property="og:title" content="">
  <meta property="og:image" content="">
  <meta property="og:url" content="">
  <meta property="og:site_name" content="">
  <meta property="og:description" content="">

  <!-- Twitter Cards integration: -->
  <meta name="twitter:card" content="summary">
  <meta name="twitter:site" content="">
  <meta name="twitter:title" content="">
  <meta name="twitter:description" content="">
  <meta name="twitter:image" content="">

  <!-- Place your favicon.ico and apple-touch-icon.png in the template root directory -->
  <link href="<?php echo base_url().LOGOURL ?>" rel="shortcut icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="<?php echo base_url() ?>assets/front/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="<?php echo base_url() ?>assets/front/lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/front/lib/animate-css/animate.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="<?php echo base_url() ?>assets/front/css/style.css" rel="stylesheet">
  <script href="<?php echo base_url() ?>assets/front/lib/jquery/jquery.min.js"></script>
  


  <style>
     .display-none{
		 display:none;
	 }
	 #hero .hero-container {
    background: rgba(0, 0, 0, 0.45);
	 }
	 #team .member .pic {
    margin-bottom: 15px;
    overflow: hidden;
    height: 100%;
}

.mt10{
	margin-top:10px
}
  </style>

</head>

<body>
  <!--<div id="preloader"></div>-->

  <!--==========================
  Hero Section
  ============================-->
  <section id="hero" style="background: url(<?php echo base_url() ?>uploads/ashg/slider.jpg);background-repeat: no-repeat;
    background-size: 100% 100%;">
    <div class="hero-container">
      <div class="wow fadeIn">
        <div class="hero-logo">
          <img class="" src="<?php echo base_url().LOGOTRANS ?>" alt="Imperial">
        </div>

        <h1><?php echo SITETITLE ?></h1>
        <h2><span class="rotating"><?php echo SITESUBTITLE ?></span></h2>
        <div class="actions">
          <a href="#services" class="btn-services">Visit</a>
        </div>
      </div>
    </div>
  </section>

  <!--==========================
  Header Section
  ============================-->
  <header id="header">
    <div class="container">

      <div id="logo" class="pull-left">
        <a href="#hero"><img src="<?php echo base_url().LOGOHORIZONTAL ?>" alt="" title="" /></img></a>
        <!-- Uncomment below if you prefer to use a text image -->
        <!--<h1><a href="#hero">Header 1</a></h1>-->
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="#hero">Home</a></li>
          <li><a href="#about">About Us</a></li>
          <li class="display-none" ><a href="#services" >Services</a></li>
          <li><a href="#portfolio">Portfolio</a></li>
          <li class="display-none"><a href="#testimonials">Testimonials</a></li>
          <li><a href="#team">Team</a></li>
          <li><a href="#contact">Contact Us</a></li>
          <li><a href="<?php echo base_url().LOGIN  ?>">Login</a></li>
          <li><a href="<?php echo base_url().REGISTRATION  ?>">Registration</a></li>
        </ul>
      </nav>
      <!-- #nav-menu-container -->
    </div>
  </header>
  <!-- #header -->

  <!--==========================
  About Section
  ============================-->
  <section id="about">
    <div class="container wow fadeInUp">
      <div class="row">
        <div class="col-md-12">
          <h3 class="section-title">हमारे बारे में</h3>
          <div class="section-title-divider"></div>
        </div>
      </div>
    </div>
    <div class="container about-container wow fadeInUp">
      <div class="row">

        <div class="col-lg-6 about-img">
          <img src="<?php echo base_url() ?>uploads/ashg/bannerimage.jpg" alt="">
        </div>

        <div class="col-md-6 about-content">
          <h2 class="about-title">We provide great services and ideass</h2>
          <p class="about-text">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
            in reprehenderit in voluptate
          </p>
          <p class="about-text">
            Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim
            id est laborum
          </p>
          <p class="about-text">
            Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt molli.
          </p>
        </div>
      </div>
    </div>
  </section>

  <!--==========================
  Services Section
  ============================-->
  <section id="services" class="display-none">
    <div class="container wow fadeInUp">
      <div class="row">
        <div class="col-md-12">
          <h3 class="section-title">Our Services</h3>
          <div class="section-title-divider"></div>
          <p class="section-description">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium</p>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-desktop"></i></div>
          <h4 class="service-title"><a href="<?php echo base_url() ?>assets/front/">Lorem Ipsum</a></h4>
          <p class="service-description">Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident</p>
        </div>
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-bar-chart"></i></div>
          <h4 class="service-title"><a href="<?php echo base_url() ?>assets/front/">Dolor Sitema</a></h4>
          <p class="service-description">Minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat tarad limino ata</p>
        </div>
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-paper-plane"></i></div>
          <h4 class="service-title"><a href="<?php echo base_url() ?>assets/front/">Sed ut perspiciatis</a></h4>
          <p class="service-description">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur</p>
        </div>
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-photo"></i></div>
          <h4 class="service-title"><a href="<?php echo base_url() ?>assets/front/">Magni Dolores</a></h4>
          <p class="service-description">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</p>
        </div>
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-road"></i></div>
          <h4 class="service-title"><a href="<?php echo base_url() ?>assets/front/">Nemo Enim</a></h4>
          <p class="service-description">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque</p>
        </div>
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-shopping-bag"></i></div>
          <h4 class="service-title"><a href="<?php echo base_url() ?>assets/front/">Eiusmod Tempor</a></h4>
          <p class="service-description">Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi</p>
        </div>
      </div>
    </div>
  </section>

  <!--==========================
  Subscrbe Section
  ============================-->
  <section id="subscribe">
    <div class="container wow fadeInUp">
      <div class="row">
        <div class="col-md-8">
          <h3 class="subscribe-title">Subscribe For Updates</h3>
          <p class="subscribe-text">Join our 1000+ subscribers and get access to the latest tools, freebies, product announcements and much more!</p>
        </div>
        <div class="col-md-4 subscribe-btn-container">
          <a class="subscribe-btn" href="#">Subscribe Now</a>
        </div>
      </div>
    </div>
  </section>

  <!--==========================
  Porfolio Section
  ============================-->
  <section id="portfolio">
    <div class="container wow fadeInUp">
      <div class="row">
        <div class="col-md-12">
          <h3 class="section-title">पोर्टफोलियो</h3>
          <div class="section-title-divider"></div>
          <p class="section-description">Si stante, hoc natura videlicet vult, salvam esse se, quod concedimus ses haec dicturum fuisse</p>
        </div>
      </div>

      <div class="row">
	   <?php for($i=0 ;$i<=7 ;$i++){ ?>
        <div class="col-md-3">
          <a class="portfolio-item" style="background-image: url(<?php echo base_url()?>uploads/users/portfolio/slider<?php echo $i+1 ?>.jpg);" href="<?php echo base_url() ?>assets/front/">
            <div class="details">
              <h4><?php echo SITETITLE ?> </h4>
              <span><?php echo SITESUBTITLE ?></span>
            </div>
          </a>
        </div>
	   <?php } ?>

       

      </div>
    </div>
  </section>

  
  <!--==========================
  Team Section
  ============================-->
  <section id="team">
    <div class="container wow fadeInUp">
      <div class="row">
        <div class="col-md-12">
          <h3 class="section-title">हमारी टीम</h3>
          <div class="section-title-divider"></div>
          <p class="section-description">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque</p>
        </div>
      </div>

      <div class="row">
		 <?php for($i=0 ;$i<=3 ;$i++){ ?>
        <div class="col-md-3">
          <div class="member">
            <div class="pic"><img src="<?php echo base_url().LOGOURL ?>" alt=""></div>
            <h4><?php echo 'Suneel Kewat' ?></h4>
            <span>IT Officer</span>
          </div>
        </div>
	   <?php } ?>
      

      </div>
    </div>
  </section>

  <!--==========================
  Contact Section
  ============================-->
  <section id="contact">
    <div class="container wow fadeInUp">
      <div class="row">
        <div class="col-md-12">
          <h3 class="section-title">Contact Us</h3>
          <div class="section-title-divider"></div>
          <p class="section-description">आप हमारी संस्था से संपर्क भी कर सकते हो </p>
        </div>
      </div>

      <div class="row">
	   
        <div class="col-md-3 col-md-push-2">
          <div class="info">
            <div>
              <i class="fa fa-map-marker"></i>
              <p>Navlakha, Indore, Madhya Pradesh</p>
            </div>

            <div>
              <i class="fa fa-envelope"></i>
              <p>info@lakhanpatel.com</p>
            </div>

            <div>
              <i class="fa fa-phone"></i>
              <p>75666-60264 <br> 0731-4993366</p>
            </div>

          </div>
        </div>

        <div class="col-md-5 col-md-push-2">
          <div class="form">
            <div id="sendmessage">Your message has been sent. Thank you!</div>
            <form  role="form" id="contact_Form" class="contactForm">
              <div class="form-group">
                <input type="text" name="contactname" required class="form-control" id="contactname" placeholder="Your Name"  />
              </div>
              <div class="form-group">
                <input type="email" class="form-control" required name="contactemail" id="contactemail" placeholder="Your Email"  />
              </div>
			  <div class="form-group">
                <input type="text" class="form-control" required name="contactnumber" id="contactnumber" placeholder="Your Contact"  />
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="contactsubject" id="contactsubject" placeholder="Subject"  />
              </div>
              <div class="form-group">
                <textarea class="form-control"  required name="contactmessage" id="contactmessage" rows="5" placeholder="Message"></textarea>
              </div>
              <div class="text-center"><span id="waitingSpin"></span>
			  <button class="btn btn-primary" onclick="validationsuccess()" id="contactFormBtn1" type="button">Send Message</button>
			  </div>

			  <div id="enquiryAlert"></div>

		   </form>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!--==========================
  Footer
============================-->
  <footer id="footer">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="copyright">
            <?php echo COPYRITE ?>
          </div>
          <div class="credits">
            <!--
              All the links in the footer should remain intact.
              You can delete the links only if you purchased the pro version.
              Licensing information: https://bootstrapmade.com/license/
              Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Imperial
            -->
           <a href="#"><?php echo AUTHER ?></a>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!-- #footer -->


  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <!-- Required JavaScript Libraries -->
  <script href="<?php echo base_url() ?>assets/front/lib/bootstrap/js/bootstrap.min.js"></script>

  <!-- Template Specisifc Custom Javascript File -->

<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>

   <script>
		$(document).ready(function(){
			$("#contactFormBtn").click(function(){
				   alert();
					$('form[id="contact_Form"]').validate({
						rules: {
							contactname: 'required',
							contactemail: 'required',
							contactsubject: 'required',
							contactmessage: 'required',
							contactnumber: 'required'
						},
						errorPlacement: function(){
								return false;  
						},
						submitHandler: function(form) {
							  validationsuccess();
						}
					});
			});
		});
		function validationsuccess(){
			$("#contactFormBtn").hide();
			var  base_url = '<?php echo base_url() ?>';
			var contactname = $("#contactname").val();
			var contactemail = $("#contactemail").val();
			var contactsubject = $("#contactsubject").val();
			var contactmessage = $("#contactmessage").val();
			var contactnumber = $("#contactnumber").val();
			var  waitimg = '<?php echo base_url('uploads/ashg/loader.gif') ?>' ;
			$('#waitingSpin').append('<img src="'+waitimg+'" width="40px" height="40px" class="mb20" >') ;
				$.ajax({
				   type: "POST",
				   url: base_url+"home/mailcontact",
				   data: {'contactname':contactname,'contactemail':contactemail,'contactnumber':contactnumber,'contactsubject':contactsubject,'contactmessage':contactmessage},
				   success: function(data){ 
						$("#enquiryAlert").text('');
						var obj = jQuery.parseJSON(data);
						if(obj.status){
							$("#waitingSpin").hide();
							$("#enquiryAlert").append(obj.message);
						}else{
							$("#contactFormBtn").show();
							$("#waitingSpin").hide();
							$("#enquiryAlert").append(obj.message);
						}
					}
				}); 
		}
		
  </script>
 


</body>

</html>
