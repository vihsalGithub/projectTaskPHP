<table class="table table-bordered" id="dataTable"  cellspacing="0">
  <thead>
	<tr>
	  <th>SN</th>
	  <th>Name</th>
	  <th>Questions</th>
	  <th>Action</th>
	</tr>
  </thead>
  <tfoot>
	<tr>
	  <th>SN</th>
	  <th>Name</th>
	  <th>Questions</th>
	  <th>Action</th>
	</tr>
  </tfoot>
  <tbody>
  <?php foreach ($oe_qus_groupby as $key => $value) { ?>
	<tr>
		<td><?php echo $key+1 ; ?></td>
		<td><?php echo $value->name ?></td>
		<td><?php echo  $value->total_ques ?></td>
		<td>
			<a href='<?php echo base_url('onlineexam/allquestions/').base64_encode($value->id) ?>'>Click For all Questions</a>
		</td>
	</tr>
  <?php } ?>
 <?php //echo '<pre>'; print_r($oe_categuty) ?>
  </tbody>
</table>