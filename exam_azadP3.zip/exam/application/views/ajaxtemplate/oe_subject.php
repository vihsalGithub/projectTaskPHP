<table class="table table-bordered" id="dataTable"  cellspacing="0">
  <thead>
	<tr>
	  <th>SN</th>
	  <th>Name</th>
	  <th>Status</th>
	  <th>Action</th>
	</tr>
  </thead>
  <tfoot>
	<tr>
	  <th>SN</th>
	  <th>Name</th>
	  <th>Status</th>
	  <th>Action</th>
	</tr>
  </tfoot>
  <tbody>
  <?php foreach ($data as $key => $value) { ?>
	  <?php
	   if($value->status){
		   $message = "Active";
		   $class = 'bg-success text-white ';
	   }else{
		   $message = "Deactive";
		   $class = 'bg-danger text-white';
	   }
	 ?>
	<tr>
		<td><?php echo $key+1 ; ?></td>
		<td><?php echo $value->name ?></td>
		<td><span class='<?php echo $class ; ?>'><?php echo  $message ; ?></td>
		<td>
		<span onclick="subjectFun(<?php echo $value->id ?>,'edit')"><i class="<?php echo EDIT_ICON ?>" aria-hidden="true"></i></span>
		<span onclick="subjectFun(<?php echo $value->id ?>,'delete')"><i class="<?php echo DELETE_ICON ?>" aria-hidden="true"></i></span>					
		</td>
	</tr>
  <?php } ?>
 <?php //echo '<pre>'; print_r($oe_categuty) ?>
  </tbody>
</table>