<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>SN.</th>
                      <th>Image</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Contact</th>
                      <th>Qualification</th>
                      <th>Status</th>
                      <th>Details</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>SN</th>
                      <th>Image</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Contact</th>
                      <th>Qualification</th>
					  <th>Status</th>
                      <th>Details</th>
                    </tr>
                  </tfoot>
                  <tbody>
				  <?php foreach ($userData as $key => $value) { ?>
                    <tr>
					  <td><?php echo $key + 1 ?></td>
					  <td><img width="30px" height="30px" src="<?php 
							if($value->image){
								echo base_url().'/'.$value->image ;
							}else{
								echo base_url().'/'.LOGOURL ;
							}
							?>"/></td>
                      <td><?php echo $value->first_name .' '.$value->first_name  ?></td>
                      <td><?php echo $value->email  ?></td>
					  <td><?php echo $value->contact_no  ?></td>
					  <td><?php echo $value->qualifiaction  ?></td>
					  <td><?php  if($value->status){
						      echo '<label>Activat</label>';
								}else{
								 echo '<label>Deactive</label>';	
								}  ?></td>
					   <td><a href="<?php echo base_url('admin/userdetails').'/'.base64_encode($value->user_id) ?>">View Details</a></td>
                    </tr>
				  <?php } ?>
                 
                  </tbody>
                </table>