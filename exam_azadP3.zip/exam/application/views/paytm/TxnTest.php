<?php
	header("Pragma: no-cache");
	header("Cache-Control: no-cache");  
	header("Expires: 0");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!DOCTYPE html>
<html lang="en">
<head>
    <title>आज़ाद सेल्फ हेल्प ग्रुप -मानव सेवा ही ईश्वर सेवा</title>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="icon" href="https://ashgindia.org/wp-content/uploads/2018/09/ashglogo.jpg" type="image/gif" sizes="16x16">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/bootstrap.min.css">

    <!-- FontAwesome CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/font-awesome.min.css">

    <!-- ElegantFonts CSS --> 
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/elegant-fonts.css">

    <!-- themify-icons CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/themify-icons.css">

    <!-- Swiper CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/swiper.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>style.css">
</head>
   

<style type="text/css">
    .icon-box:hover, .icon-box.active {
    background: #ecf2f5 !important;
}
.icon-box:hover .entry-title, .icon-box.active .entry-title {
    color: #262626 !important;
}
.icon-box:hover .entry-content p, .icon-box.active .entry-content p {
    color: #262626;
}

 
#questContainer {
    padding: 40px 24px;
    min-height: 600px;
    width: 500px;
    margin: 0px auto;
    background-color: #fff;
    box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
    color: black;
}
.field-error{
    color: red;
}
#brandImg{
    width: 100%;
}
</style>
<body>

    <div class="home-page-icon-boxes">
        <div class="container">
        		<div class="row" id="questContainer">
                	<div class="col-xl-12 col-md-12 col-xs-12 col-sm-12">
                		<h3>Confimation(भुगतान कन्फर्मेशन)</h3>
                		<?php
                			$productInfo = $this->db->select('*')->from('oe_package')->where(array('pack_id'=>$_SESSION['pinfo']))->get()->row();
                		  // print_r($productInfo);
                		  ?>
                		  <div class="form-group">
							    <label for="email">Name:</label>
							    <input type="text" readonly class="form-control"  value="<?php echo $_SESSION['fname']?>">
							</div>
							<div class="form-group">
							    <label for="email">Contact No:</label>
							    <input type="text" readonly class="form-control"  value="<?php echo $_SESSION['mobile']?>">
							</div>
							<div class="form-group">
							    <label for="email">Your Email:</label>
							    <input type="text" readonly class="form-control"  value="<?php echo $_SESSION['email']?>">
							</div>
							<div class="form-group">
							    <label for="email">Contact No:</label>
							    <input type="text" readonly class="form-control"  value="<?php echo $_SESSION['mobile']?>">
							</div>
							<div class="form-group">
							    <label for="email">Contact No:</label>
							    <input type="text" readonly class="form-control"  value="<?php echo $_SESSION['mobile']?>">
							</div>
							<div class="form-group">
							    <label for="email">Package Charge(Rs):</label>
							    <input type="text" readonly class="form-control"  value="<?php echo $productInfo->description ?>">
							</div>
							<div class="form-group">
							    <label for="email">Registration Charge(Rs):</label>
							    <input type="text" readonly class="form-control"  value="25">
							</div>
						<form method="post" action="<?php echo base_url('paytm/paymantRedirect') ?>">
							 <div class="form-group">
							    <label for="TXN_AMOUNT">Package Amount(Rs):</label>
							    <input type="text" class="form-control" id="TXN_AMOUNT" name="TXN_AMOUNT"  value="1">
							 </div>
							<div class="form-group">
							     <input type="text" class="form-control" id="ORDER_ID" name="ORDER_ID" value="<?php echo  "ORDS" . rand(10000,99999999)?>">
							 </div>
							 <div class="form-group">
							    <input type="text" class="form-control" id="CUST_ID" name="CUST_ID"   value="1">
							 </div>
							 <div class="form-group">
							    <input type="text"  id="INDUSTRY_TYPE_ID" tabindex="4" maxlength="12" size="12" name="INDUSTRY_TYPE_ID" autocomplete="off" value="Retail109">
							 </div>
							 <div class="form-group">
								<input type="text"  id="CHANNEL_ID" tabindex="4" maxlength="12" size="12" name="CHANNEL_ID" autocomplete="off" value="WEB">							 
							</div>
							 <div class="form-group">
							       <input class="btn" value="CheckOut" type="submit"	onclick="">
							 </div>
						</form> 
						 <!-- <form method="post" action="<?php echo base_url('paytm/paymantRedirect') ?>">
							<table border="1">
								<tbody>
									<tr>
										<th>S.No</th>
										<th>Label</th>
										<th>Value</th>
									</tr>
									<tr>
										<td>1</td>
										<td><label>ORDER_ID::*</label></td>
										<td><input id="ORDER_ID" tabindex="1" maxlength="20" size="20"
											name="ORDER_ID" autocomplete="off"
											value="<?php echo  "ORDS" . rand(10000,99999999)?>">
										</td>
									</tr>
									<tr>
										<td>2</td>
										<td><label>CUSTID ::*</label></td>
										<td><input id="CUST_ID" tabindex="2" maxlength="12" size="12" name="CUST_ID" autocomplete="off" value="CUST001"></td>
									</tr>
									<tr>
										<td>3</td>
										<td><label>INDUSTRY_TYPE_ID ::*</label></td>
										<td><input id="INDUSTRY_TYPE_ID" tabindex="4" maxlength="12" size="12" name="INDUSTRY_TYPE_ID" autocomplete="off" value="Retail109"></td>
									</tr>
									<tr>
										<td>4</td>
										<td><label>Channel ::*</label></td>
										<td><input id="CHANNEL_ID" tabindex="4" maxlength="12"
											size="12" name="CHANNEL_ID" autocomplete="off" value="WEB">
										</td>
									</tr>
									<tr>
										<td>5</td>
										<td><label>txnAmount*</label></td>
										<td><input title="TXN_AMOUNT" tabindex="10"
											type="text" name="TXN_AMOUNT"
											value="1">
										</td>
									</tr>
									<tr>
										<td></td>
										<td></td>
										<td><input  value="CheckOut" type="submit"	onclick=""></td>
									</tr>
								</tbody>
							</table>
							* - Mandatory Fields
						</form>-->
					</div>
				</div>
			</div>
		</div>

    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.collapsible.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/swiper.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.countdown.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/circle-progress.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.countTo.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.barfiller.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/custom.js'></script>

</body>
</html>