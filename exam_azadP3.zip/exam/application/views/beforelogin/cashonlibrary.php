<!DOCTYPE html>
<html lang="en">
<head>
    <title>आज़ाद सेल्फ हेल्प ग्रुप -मानव सेवा ही ईश्वर सेवा</title>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="icon" href="https://ashgindia.org/wp-content/uploads/2018/09/ashglogo.jpg" type="image/gif" sizes="16x16">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/bootstrap.min.css">

    <!-- FontAwesome CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/font-awesome.min.css">

    <!-- ElegantFonts CSS --> 
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/elegant-fonts.css">

    <!-- themify-icons CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/themify-icons.css">

    <!-- Swiper CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/swiper.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>style.css">
</head>
   
<style type="text/css">
    .icon-box:hover, .icon-box.active {
    background: #ecf2f5 !important;
}
.icon-box:hover .entry-title, .icon-box.active .entry-title {
    color: #262626 !important;
}
.icon-box:hover .entry-content p, .icon-box.active .entry-content p {
    color: #262626;
}

 #cashOnLibrary{
    padding: 40px 24px;
    margin: 0px auto;
    background-color: #fff;
    box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
    color: black;
    }
.field-error{
    color: red;
}
</style>
<body>

    <div class="home-page-icon-boxes">
        <div class="container">
            <div class="row">
               
                
                <div class="col-12 col-md-8 col-lg-8 mt-8 mt-lg-0 " id="cashOnLibrary">

                     <?php 
                    /*print_r($userData);
                    print_r($tokaen_no);*/
                ?>
                        <header class="entry-header">
                            <h3 class="text-center"><img  width="150px" height="75px" src="https://ashgindia.org/wp-content/uploads/2018/09/logo_white.png"></h3>
                        </header>
                        <div class="col-xs-12 col-sm-12">
                            <h3 class="text-center">Thanks you For Registration</h3>
                            <p class="text-center">Your Registration details is</p>
                                 <table class="table text-center">
                                    <tbody>
                                    <tr>
                                        <td><b>Token ID</b></td>
                                        <td><b><?php echo $tokaen_no ?></b></td>
                                      </tr>
                                      <tr>
                                        <td><b>Name</b></td>
                                        <td><?php echo $userData->name ?></td>
                                      </tr>
                                      <tr>
                                        <td><b>Contact No</b></td>
                                        <td><?php echo $userData->contact_no ?></td>
                                      </tr>
                                      <tr>
                                        <td><b>Email</b></td>
                                        <td><?php echo $userData->email ?></td>
                                      </tr>
                                      <tr>
                                        <td><b>Registration Date</b></td>
                                        <td><?php echo $userData->reg_date ?></td>
                                      </tr>
                                       <tr>
                                        <td><b>Payment Type</b></td>
                                        <td><?php echo $payment_type->name ?></td>
                                      </tr>
                                       <tr>
                                        <td><b>Package Type</b></td>
                                        <td><?php echo $package_data->name.'('.$package_data->description.')' ?></td>
                                      </tr>
                                     
                                       <tr>
                                        <td><b>Registration Fee</b></td>
                                        <td>Rs.<?php echo $registration_charge->cahrge_rupee ?></td>
                                      </tr>
                                      <tr>
                                        <td><b>Total Fee</b></td>
                                        <td>Rs.<?php echo ($registration_charge->cahrge_rupee +$package_data->charge_rupee ) ?></td>
                                      </tr>


                                      <?php 
                                        $parameter = 'payment_type=1&token_id='.$tokaen_no;
                                        if($userData->payment_type ==2){ 
                                        $parameter = 'payment_type=2&token_id='.$tokaen_no;
                                        $bankDetail =  $this->db->select('*')->from('important_docs')->where(array('status' =>1,'type'=>1))->get()->result() ;
                                        foreach ($bankDetail as $key => $bandValue) {
                                        ?>
                                        <tr>
                                            <td><b><?php echo  $bandValue->name ?></b></td>
                                            <td><?php echo  $bandValue->value ?></td>
                                        </tr>
                                      <?php } } ?>

                                    </tbody>
                                  </table>
                                        <?php
                                         
                                            if($userData->payment_type == 4){

                                                if($userData->package_type == 1){

                                                     echo '<p class="text-center" >
                                                        <a class="btn gradient-bg mr-2" target="_blank" href="https://imjo.in/aVJyCB">Continue</a>
                                                    </p>';

                                                }elseif($userData->package_type == 2){
                                                    echo '<p class="text-center" >
                                                        <a class="btn gradient-bg mr-2" target="_blank" href="https://imjo.in/v3vNRZ">Continue</a>
                                                    </p>';

                                                }elseif($userData->package_type == 3){
                                                    echo '<p class="text-center" >
                                                        <a class="btn gradient-bg mr-2" target="_blank" href="https://imjo.in/U2sByB">Continue</a>
                                                    </p>';

                                                }elseif($userData->package_type == 4){
                                                    //https://imjo.in/ykcQA8
                                                    echo '<p class="text-center" >
                                                        <a class="btn gradient-bg mr-2" target="_blank" href="https://imjo.in/ykcQA8">Continue</a>
                                                    </p>';
                                                }

                                            }else{


                                           echo '<p class="text-center" >
                                            <a class="btn gradient-bg mr-2"  href="'.base_url('exam/approval?').$parameter.'">Continue</a>
                                                </p>';


                                           

                                            }
                                        ?>
                                    
                        </div>
                </div>

                <?php

                    //print_r($package_data->charge_rupee);
                ?>
                
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .home-page-icon-boxes -->
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.collapsible.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/swiper.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.countdown.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/circle-progress.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.countTo.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.barfiller.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/custom.js'></script>
</body>
</html>
