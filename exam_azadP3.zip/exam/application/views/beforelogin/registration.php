<!DOCTYPE html>
<html lang="en">
<head>
    <title>आज़ाद सेल्फ हेल्प ग्रुप -मानव सेवा ही ईश्वर सेवा</title>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="icon" href="https://ashgindia.org/wp-content/uploads/2018/09/ashglogo.jpg" type="image/gif" sizes="16x16">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/bootstrap.min.css">

    <!-- FontAwesome CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/font-awesome.min.css">

    <!-- ElegantFonts CSS --> 
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/elegant-fonts.css">

    <!-- themify-icons CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/themify-icons.css">

    <!-- Swiper CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/swiper.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>style.css">
</head>
   

<style type="text/css">
    .icon-box:hover, .icon-box.active {
    background: #ecf2f5 !important;
}
.icon-box:hover .entry-title, .icon-box.active .entry-title {
    color: #262626 !important;
}
.icon-box:hover .entry-content p, .icon-box.active .entry-content p {
    color: #262626;
}

 #questContainer{
    padding: 40px 24px;
    margin: 0px auto;
    background-color: #fff;
    box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
    color: black;
    }
.field-error{
    color: red;
}
#brandImg{
    width: 100%;
}
</style>
<body>

    <div class="home-page-icon-boxes">
        <div class="container">
            <div class="row"  id="questContainer">
                <div class="col-xl-12 col-md-12 col-xs-12 col-sm-12">
                 <header class="entry-header">
                            <h3 class="text-center"><img  width="150px" height="75px" src="https://ashgindia.org/wp-content/uploads/2018/09/logo_white.png"></h3>
                </header>
                <?php session_start(); echo $this->session->flashdata('cashonlibrary') ?>
               </div>
               <div class="col-xl-4 col-md-4  col-lg-12 mt-12 mt-lg-0 " style="border: 1px solid #ccc;padding: 10px;margin: 10px 0px;">
                        <div class="col-xs-12 col-sm-12" >
                            <!-- <a href="#" class="">
                                <img  width="100%" height="50px" src="<?php echo base_url('assets/home/images/social/gologin.png') ?>">
                            </a> -->
                            <!-- <a href="#" class="">
                                <img style="padding: 0px 5px;" width="100%" height="50px" src="<?php echo base_url('assets/home/images/social/fblogin.png') ?>">
                            </a> -->
                            <form method="post" action="<?php echo base_url('exam/submitform') ?>">
                              <div class="form-group">
                                <?php echo $this->session->flashdata('errermessage') ?>
                            </div>
                              <div class="form-group">
                                <input type="text" class="form-control" placeholder="Full Name"  name ="fullName" id="fullName" value="<?php echo set_value('fullName') ?>" >
                                <span><?php echo form_error('fullName','<p class="field-error">','</p>'); ?></span>
                              </div>
                              <div class="form-group">
                                <input type="email" class="form-control"  placeholder="Email address"  name="useremail" id="useremail" value="<?php echo set_value('useremail') ?>"  >
                                <span><?php echo form_error('useremail','<p class="field-error">','</p>'); ?></span>
                              </div>
                              <div class="form-group">
                                <input type="text" min="10" max="10" class="form-control" placeholder="Contact No" required="" name="contactNo" id="contactNo"  value="<?php echo set_value('contactNo') ?>"  >
                                <span><?php echo form_error('contactNo','<p class="field-error">','</p>'); ?></span>
                              </div>
                                <!-- <span><img src="<?php echo base_url('assets/pay/rupee16.png') ?>"></span> -->
                              <div class="form-group">
                                  <select  onchange="changevalue1()" class="form-control" id="regpackage" name="regpackage">
                                      <?php
                                       $package =  $this->db->select('pack_id,charge_rupee,description')->from('oe_package')->where('status',1)->get()->result() ;
                                        //print_r($package);
                                      ?>
                                        <option value="1">Select Package</option>
                                        <?php foreach ($package as $key => $value) {
                                            ?>
                                            <option  value="<?php echo $value->pack_id ?>"><?php echo $value->description ?>(+25 Rs Registration)</option>
                                        <?php
                                        } ?>
                                        
                                  </select>
                              </div>

                                <?php
                                    $payment_type =  $this->db->select('*')->from('payment_type')->where('status',1)->get()->result() ;
                                    //print_r($payment_type);
                                    ?>

                              <div class="form-group"  id="paymentTypeDiv">
                                  <select required="" class="form-control" id="paymentType" name="paymentType">
                                        <option value="1">Select Payment Pay With</option>
                                        <?php foreach ($payment_type as $key => $value) {
                                            ?>
                                            <option  value="<?php echo $value->payment_type ?>">
                                                <?php echo $value->name ?>
                                            </option>
                                        <?php
                                        } ?>
                                  </select>
                              </div>

                              <div class="form-group">
                                <input type="password" class="form-control" placeholder="Password"  required="" name="userPassword" id="userPassword"   value="<?php echo set_value('userPassword') ?>"  >
                                <span><?php echo form_error('userPassword','<p class="field-error">','</p>'); ?></span>
                              </div>

                               <div class="form-group">
                                <input type="password" class="form-control" placeholder="Confirm Password"  required="" name="cnfPassword" id="cnfPassword"   value="<?php echo set_value('cnfPassword') ?>"  >
                                <span><?php echo form_error('cnfPassword','<p class="field-error">','</p>'); ?></span>
                              </div>
                              <div class="checkbox">
                                <label><input type="checkbox" checked> Remember me</label>
                              </div>
                              <input type="hidden" name="loginType" id="loginType" value="1">
                              <button type="submit" class="btn gradient-bg mr-2">Submit</button>
                              <br>
                              <p class="text-center"><a href="<?php echo base_url('exam/login') ?>">Login</a></p>
                            </form>
                        </div>
                </div>
                <div class="col-xl-4 col-md-4 col-xs-12 col-sm-12" style="border: 1px solid #ccc;padding: 10px;margin: 10px 0px;">
                    <h3>ASHG के उद्देश्य </h3>
                    <h5><?php  session_start();  echo $this->session->flashdata('paymantStatus') ;?></h5>
                    <p><img src="https://ashgindia.org/wp-content/uploads/2018/10/lakhan-sir-1-1024x813.jpg"  height="150px" id="brandImg"></p>
                    <p>1. हमारे द्वारा आपको प्रत्येक महीने 1000 प्रश्न (ऑनलाइन टेस्ट सीरीज,जी के टेस्ट )मिलेंगे ।</p>
                    <p>2. साप्ताहिक एवं  मासिक करंट अफेयर्स उपलब्ध करायेंगे ।</p>
                    <p>3. असहाय एवं जरूरतमंद व्यक्तियों को निशुल्क  वस्त्र उपलब्ध कराना।</p>
                    <p>4. निशुल्क  योग प्रशिक्षण कक्षाएं।</p>
                    <p>5. विद्यार्थियों के लिए सभी उपयोगी पुस्तके उपलब्ध कराना।</p>
                    <p>6. जरूरतमंद व्यक्तियों को निशुल्क  रक्तदान की व्यवस्था करना।</p>
                    <p>7. शहीद सैनिकों की बालिकाओं को निशुल्क  प्रतियोगी परीक्षाओं की तैयारी करवाना।</p> 
                    <p>8. हमारा लक्ष्य भविष्य में 20 रुपये में प्रत्येक जिले में लाइब्रेरी उपलब्ध कराना है।           
                    </p>
                    <p>9. इसमे आपका सहयोग सबसे बड़ी ताकत है इसे ज्यादा से ज्यादा शेयर करें</p>
                </div>
                <div class="col-xl-4 col-md-4 col-xs-12 col-sm-12" style="border: 1px solid #ccc;padding: 10px;margin: 10px 0px;">
                    <h3>आवेदन प्रक्रिया </h3>
					           <p><img src="<?php echo base_url('uploads/ashg/cd.jpg');?>"   id="brandImg"></p>
                    <p>1. आप आवेदन में अलग अलग पेमेंट मोड और पैकेज टाइप का चयन कर सकते है</p>
                   <p>2. आवेदक की फीस 20 रुपये प्रति माह है और 5 रुपये एक बार रजिस्ट्रेशन शुल्क रखा गया है </p>
                    <!-- <p>3.<b>Cash On Library :</b> इस चयन में आप रजिस्ट्रेशन करके पेमेंट को पुस्तकालय में टोकन ID की हेल्प जमा करके अकाउंट एक्टिवेट  करवा सकते हो </p> -->
                   
                    <!-- <p>2.<b> By Bank Manually : </b>इस चयन में आप रजिस्ट्रेशन करके आप पेमेंट ट्रस्ट के बैंक अकाउंट ( NEFT/RTGS/UPI(BHIM/TEZ)) पेमेंट वेरिफाई होने के बाद आपका आकउंट एक्टिवेट कर दिया जायेगा </p>
                                        <p>3.<b >बैंक अकाउंट डिटेल्स </b ></br >
                                            (a) <b >Name  -</b > Azad  Self help Group  Charitable Trust <br >
                                            (b) <b >Bank A/c -</b >275011100001307 <br >
                                            (c) <b >IFSC -</b >ANDB0002750 <br >
                                            (d) <b >You Can Pay Via  -</b >NEFT/RTGS/UPI(BHIM/TEZ)<br ></p>
                    <p>6.<b> Send Payment Details To Activate : </b>रजिस्ट्रेशन करने के पश्चात आपको <b>88710-36186/75666-60264(Only WhatsApp)</b> पर पेमेंट आईडी/स्क्रीनशॉट Whatsapp करना होगा इसके बाद आपका अकाउंट Activate कर दिया जाएगा  </p>

                    <p>6.<b> Note :: </b> Account Will be Activate As Soon As Possible Keep Patience Contact Us For Any Query/Suggestion  </p> -->
                </div>
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .home-page-icon-boxes -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        function changevalue(){
           // alert();
           var regpackage = $("#regpackage").val();
           //alert(regpackage); 

           if(regpackage ==1)
           {
            $('#paymentTypeDiv').text('');
            $('#paymentTypeDiv').append('<select required="" class="form-control" id="paymentType" name="paymentType"><option value="1">Select Payment Pay With</option><option value="1">Cash On Library </option><option value="2">By Bank Manualy</option><option value="4">Payment Gateway</option></select>');
            }else{
                $('#paymentTypeDiv').text('');
            $('#paymentTypeDiv').append('<select required="" class="form-control" id="paymentType" name="paymentType"><option value="1">Select Payment Pay With</option><option value="1">Cash On Library </option><option value="2">By Bank Manualy</option></select>');
            }


           //
        }

    </script>


    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.collapsible.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/swiper.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.countdown.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/circle-progress.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.countTo.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.barfiller.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/custom.js'></script>

</body>
</html>



