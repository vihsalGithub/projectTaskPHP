<!DOCTYPE html>
<html lang="en">
<head>
    <title>आज़ाद सेल्फ हेल्प ग्रुप -मानव सेवा ही ईश्वर सेवा</title>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="icon" href="https://ashgindia.org/wp-content/uploads/2018/09/ashglogo.jpg" type="image/gif" sizes="16x16">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/bootstrap.min.css">

    <!-- FontAwesome CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/font-awesome.min.css">

    <!-- ElegantFonts CSS --> 
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/elegant-fonts.css">

    <!-- themify-icons CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/themify-icons.css">

    <!-- Swiper CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/swiper.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>style.css">
</head>
   
<style type="text/css">
    .icon-box:hover, .icon-box.active {
    background: #ecf2f5 !important;
}
.icon-box:hover .entry-title, .icon-box.active .entry-title {
    color: #262626 !important;
}
.icon-box:hover .entry-content p, .icon-box.active .entry-content p {
    color: #262626;
}

 #questContainer{
    padding: 40px 24px;
    margin: 0px auto;
    background-color: #fff;
    box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
    color: black;
    }
.field-error{
    color: red;
}
</style>
<body>

    <div class="home-page-icon-boxes">
        <div class="container">
            <div class="row">
                
                <div class="col-12 col-md-4 col-lg-4 mt-4 mt-lg-0 " id="questContainer">
                        <header class="entry-header">
                            <h3 class="text-center"><img  width="150px" height="75px" src="https://ashgindia.org/wp-content/uploads/2018/09/logo_white.png"></h3>
                        </header>
                        <div class="col-xs-12 col-sm-12">
                            <!-- <a href="#" class="">
                                <img  width="100%" height="50px" src="<?php echo base_url('assets/home/images/social/gologin.png') ?>">
                            </a> -->
                            <!-- <a href="#" class="">
                                <img style="padding: 0px 5px;" width="100%" height="50px" src="<?php echo base_url('assets/home/images/social/fblogin.png') ?>">
                            </a> -->
                            <form method="post" action="<?php echo base_url('exam/submitlogin') ?>">
                              <div class="form-group">
                                <?php echo $this->session->flashdata('errermessage') ?>
                              </div>
                              <div class="form-group">
                                <input type="email" class="form-control"  placeholder="Email address"  name="useremail" id="useremail" value="<?php echo set_value('useremail') ?>"  >
                                 <span><?php echo form_error('useremail','<p class="field-error">','</p>'); ?></span>
                              </div>
                              <div class="form-group">
                                <input type="password" class="form-control" placeholder="Password"  required1="" name="userPassword" id="userPassword"   value="<?php echo set_value('userPassword') ?>"  >
                                <span><?php echo form_error('userPassword','<p class="field-error">','</p>'); ?></span>
                              </div>

                              <div class="checkbox">
                                <label><input type="checkbox" checked> Remember me</label>
                              </div>
                              <input type="hidden" name="loginType" id="loginType" value="1">
                              <button type="submit" class="btn gradient-bg mr-2">Login</button></form>
                              <br>
                              <p class="text-center"><a href="<?php echo base_url('exam/registration') ?>">Registration</a>  ||  <a href="<?php echo base_url('exam/forgotpassword') ?>">Forget Password</a></p>
                            
                        </div>
                </div>
                
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .home-page-icon-boxes -->



    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.collapsible.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/swiper.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.countdown.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/circle-progress.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.countTo.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.barfiller.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/custom.js'></script>

</body>
</html>
