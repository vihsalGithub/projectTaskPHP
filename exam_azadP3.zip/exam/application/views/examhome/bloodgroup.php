  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<style type="text/css">
    .icon-box:hover, .icon-box.active {
    background: #ecf2f5 !important;
}
.icon-box:hover .entry-title, .icon-box.active .entry-title {
    color: #262626 !important;
}
.icon-box:hover .entry-content p, .icon-box.active .entry-content p {
    color: #262626;
}
</style>





 <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css"> -->


    <div class="home-page-icon-boxes" style="min-height: 500px;">
        <div class="container">

            <div class="row">
              
                  
                  <?php 
                     // print_r($_SESSION);
                     // print_r($bloodGroupType);
                 // $url = base_url('exam/boloodgroupAdd/').'/test';
                      //echo $url ;
                  ?>
  <div class="col-md-12" >
     <button class="btn gradient-bg mr-2" style="color: #fff;margin-bottom: 10px;" onclick="addBloodGroup()">Add Your Blood Group</button>
  </div>

  <div class="col-md-4">
  </div>
  <div class="col-md-4" >
      <div class="model"  id="addBloodGroupModel" style="color: #fff;margin-bottom: 10px;border: 1px solid #ccc;padding: 2px;padding-bottom: 10px; display: none">
          <header class="entry-header">
              <h3 class="text-center">Add Blood Group</h3>
          </header>
          <div class="col-xs-12 col-sm-12">
            <h3 class="text-center">Add Blood Group</h3>
              <form method="post" action="<?php echo base_url('exam/addBloodGroup') ?>">
                <div class="form-group">
                  <input type="text" required="" readonly=""  class="form-control" placeholder="user name" name="userName" id="userName" value=" <?php echo $this->session->userdata('userFullName')?>">
                   <span></span>
                </div>
                <div class="form-group">
                  <input type="text"  required=""  readonly="" class="form-control" placeholder="user contact" name="userContact" id="userContact" value=" <?php echo $this->session->userdata('userConNo')?>">
                   <span></span>
                </div>

                <div class="form-group">
                  <input type="text"  required=""  readonly="" class="form-control" placeholder="user email" name="userEmail" id="userEmail" value="<?php echo $this->session->userdata('userEmal')?>">
                   <span></span>
                </div>
                <div class="form-group">
                  <input type="text"  required=""  class="form-control" placeholder="user city" name="userCityName" id="userCityName" value="">
                   <span></span>
                </div>
                <div class="form-group">
                    <select class="form-control"    required="" >
                      <option value="1">Active</option>
                      <option value="0">Deactive</option>
                    </select>
                </div>
                <div class="form-group">
                    <select class="form-control"  required="" >
                      <option value="1">Select Blood Group</option>
                       <?php foreach($bloodGroupType as $key =>$value){
                          echo '<option value="'.$value->blood_group.'">'.$value->blood_group.'</option>';
                        }
                       ?>
                    </select>
                </div>
                <div class="form-group"  required="" >
                  <input type="hidden" class="form-control" placeholder="userId" required="" name="userId" id="userId" value="<?php echo $this->session->userdata('user_id')?>">
                  <span></span>
                </div>
                <button type="submit" class="btn gradient-bg mr-2">Login</button></form>
          </div>
    </div>
  </div>
  <div class="col-md-4">
  </div>


                </div>
                      <div class="table-responsive">          
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                          <thead>
                            <tr>
                              <th>Sn</th>
                              <th>Name</th>
                              <th>Contact No.</th>
                              <th>City</th>
                              <th>Blood Group</th>
                            </tr>
                          </thead>
                          <tfoot>
                            <tr>
                              <th>Sn</th>
                              <th>Name</th>
                              <th>Contact No.</th>
                              <th>City</th>
                              <th>Blood Group</th>
                            </tr>
                          </tfoot>
                          <tbody>
                          <?php foreach($bloodDonateUser  as $key=>$data){ ?>
                            <tr>
                                <td><?php echo $key+1?></td>
                                <td><?php echo $data->name ?></td>
                                <td><?php echo $data->contact_no ?></td>
                                <td><?php echo $data->city ?></td>
                                <td><?php echo $data->blood_group ?></td>
                            </tr>
                          <?php } ?>
                          </tbody>
                        </table>
                        </div>
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .home-page-icon-boxes -->


<!-- Modal -->
<div style="z-index: 2147483647;"id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>




<!-- <script type="text/javascript"  src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script> -->
<script src="<?php echo base_url() ; ?>/assets/vendor/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo base_url() ; ?>/assets/vendor/datatables/dataTables.bootstrap4.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    $('#dataTable').DataTable( {
        initComplete: function () {
          this.api().columns(4).every( function () {
            var column = this;
            var select = $('<select><option value="">Select Blood Group</option></select>')
              .appendTo( $(column.header()).empty() )
              .on( 'change', function () {
                var val = $.fn.dataTable.util.escapeRegex(
                  $(this).val()
                );
                column
                  .search( val ? '^'+val+'$' : '', true, false )
                  .draw();
              } );
            column.data(1).unique().sort().each( function ( d, j ) {
              select.append( '<option value="'+d+'">'+d+'</option>' )
            } );
          } );
        }
      } );
      
  });
</script>



 <script type="text/javascript">
     function editprofile(){
        $("#myModal").modal('show');
     }
    
     /*$(function(){
      alert();
         $("#addBloodGroupModel").hide();
     });*/
     function addBloodGroup(){
        //alert();
         var x = document.getElementById('addBloodGroupModel') ;
         if(x.style.display === "none"){
             //alert("show");
            x.style.display ="block" ;
         }else{
           // alert("hide");
            x.style.display = "none";
         }
        //$("#addBloodGroupModel").modal();
     }
 </script>   
