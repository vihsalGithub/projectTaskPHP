  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<style type="text/css">
    .icon-box:hover, .icon-box.active {
    background: #ecf2f5 !important;
}
.icon-box:hover .entry-title, .icon-box.active .entry-title {
    color: #262626 !important;
}
.icon-box:hover .entry-content p, .icon-box.active .entry-content p {
    color: #262626;
}
.dt-button{
  padding: 7px 21px;
    font-size: 16px;
    font-weight: 500;
    line-height: 1;
    color: #fff;
    text-decoration: navajowhite;
    background: #262222;
}
</style>



<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css">

 <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css"> -->


    <div class="home-page-icon-boxes" style="min-height: 500px;">
        <div class="container">
            <div class="row">

                      <div class="table-responsive">          
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                           <thead>
                            <tr>
                              <th>Sn</th>
                              <th>Question</th>
                              <th>Option1.</th>
                              <th>Option2.</th>
                              <th>Option3.</th>
                              <th>Option4.</th>
                              <th>Answer</th>
                            </tr>
                          </thead>
                          <tfoot>
                            <tr>
                              <th>Sn</th>
                              <th>Question</th>
                              <th>Option1.</th>
                              <th>Option2.</th>
                              <th>Option3.</th>
                              <th>Option4.</th>
                              <th>Answer</th>
                            </tr>
                          </tfoot>
                           <tbody>
                          <?php foreach($questions  as $key=>$data){ ?>
                            <tr>
                                <td><?php echo $key+1?></td>
                                <td><?php echo $data->question ?></td>
                                <td><?php echo $data->op_1 ?></td>
                                <td><?php echo $data->op_2 ?></td>
                                <td><?php echo $data->op_3 ?></td>
                                <td><?php echo $data->op_4 ?></td>
                                <td><?php
                                  if($data->ans == 1){
                                      echo $data->op_1 ;
                                  }elseif($data->ans == 2){
                                    echo $data->op_2;
                                  }elseif($data->ans == 3){
                                    echo $data->op_3 ;
                                  }elseif($data->ans == 4){
                                    echo $data->op_4 ;
                                  }
                                ?></td>
                            </tr>
                          <?php } ?>
                          </tbody>
                        </table>
                        </div>
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .home-page-icon-boxes -->


<!-- Modal -->
<div style="z-index: 2147483647;"id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<!-- <script type="text/javascript"  src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script> -->
<script src="<?php echo base_url() ; ?>/assets/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url() ; ?>/assets/vendor/datatables/dataTables.bootstrap4.js"></script>

<script type="text/javascript"src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript"src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

<script type="text/javascript"src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js">
</script>
<script type="text/javascript"src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
<script type="text/javascript"src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript"src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script type="text/javascript"src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script type="text/javascript"src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
"></script>
<script type="text/javascript">
  $(document).ready(function() {
    $('#dataTable').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy','pdf'
        ]
    } );
} );
</script>
<!-- <script type="text/javascript">
  $(document).ready(function() {
    $('#dataTable').DataTable( {
        initComplete: function () {
          this.api().columns(4).every( function () {
            var column = this;
            var select = $('<select><option value="">Select Blood Group</option></select>')
              .appendTo( $(column.header()).empty() )
              .on( 'change', function () {
                var val = $.fn.dataTable.util.escapeRegex(
                  $(this).val()
                );
                column
                  .search( val ? '^'+val+'$' : '', true, false )
                  .draw();
              } );
            column.data(1).unique().sort().each( function ( d, j ) {
              select.append( '<option value="'+d+'">'+d+'</option>' )
            } );
          } );
        }
      } );
      
  });
</script> -->



 <script type="text/javascript">
     function editprofile(){
        $("#myModal").modal('show');
     }
 </script>   
