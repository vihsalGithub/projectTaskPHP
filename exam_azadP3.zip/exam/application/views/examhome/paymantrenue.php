<!DOCTYPE html>
<html lang="en">
<head>
    <title>आज़ाद सेल्फ हेल्प ग्रुप -मानव सेवा ही ईश्वर सेवा</title>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="icon" href="https://ashgindia.org/wp-content/uploads/2018/09/ashglogo.jpg" type="image/gif" sizes="16x16">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/bootstrap.min.css">

    <!-- FontAwesome CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/font-awesome.min.css">

    <!-- ElegantFonts CSS --> 
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/elegant-fonts.css">

    <!-- themify-icons CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/themify-icons.css">

    <!-- Swiper CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/swiper.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>style.css">
</head>
   

<style type="text/css">
    .icon-box:hover, .icon-box.active {
    background: #ecf2f5 !important;
}
.icon-box:hover .entry-title, .icon-box.active .entry-title {
    color: #262626 !important;
}
.icon-box:hover .entry-content p, .icon-box.active .entry-content p {
    color: #262626;
}

 #questContainer{
    padding: 40px 24px;
    min-height: 600px;
    width: 500px;
    margin: 0px auto;
    background-color: #fff;
    box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
    color: black;
    }
.field-error{
    color: red;
}
#brandImg{
    width: 100%;
}
</style>
<body>
    <?php
     // print_r($userData[0]->name);
    ?>
    <div class="home-page-icon-boxes">
        <div class="container">
            <div class="row"  id="questContainer">
                <div class="col-xl-12 col-md-12 col-xs-12 col-sm-12">
                 <header class="entry-header">
                            <h3 class="text-center"><img  width="150px" height="75px" src="https://ashgindia.org/wp-content/uploads/2018/09/logo_white.png"></h3>
                </header>
                <?php session_start(); echo $this->session->flashdata('cashonlibrary') ?>
               </div>
               <div class="col-xl-12 col-md-12  col-lg-12 mt-12 mt-lg-0 " style="border: 1px solid #ccc;padding: 10px;margin: 10px 0px;">
                        <div class="col-xs-12 col-sm-12" >
                          <?php if($message == 1) {?>
                            <form method="post" action="<?php echo base_url('exam/paymantRenuePackage') ?>">
                              <div class="form-group">
                                <?php echo $this->session->flashdata('errermessage') ?>
                              </div>
                              <div class="form-group">
                                <input type="text" class="form-control"  readonly  placeholder="Full Name"  name ="fullName" id="fullName" value="<?php echo $userData[0]->name ?>" >
                              </div>
                              <div class="form-group">
                                <input type="email" class="form-control"  readonly   placeholder="Email address"  name="useremail" id="useremail" value="<?php echo $userData[0]->email ?>"  >
                              </div>
                              <div class="form-group">
                                <input type="text" min="10" max="10" readonly class="form-control" placeholder="Contact No" required="" name="contactNo" id="contactNo"  value="<?php echo $userData[0]->contact_no  ?>"  >
                              </div>
                                <!-- <span><img src="<?php echo base_url('assets/pay/rupee16.png') ?>"></span> -->
                              <div class="form-group">
                                  <select    required=""  class="form-control" id="regpackage" name="regpackage">
                                      <?php
                                       $package =  $this->db->select('pack_id,charge_rupee,description')->from('oe_package')->where('status',1)->get()->result() ;
                                        //print_r($package);
                                      ?>
                                        <option value="">Select Package</option>
                                        <?php foreach ($package as $key => $value) {
                                            ?>
                                            <option  value="<?php echo $value->pack_id ?>"><?php echo $value->description ?></option>
                                        <?php
                                        } ?>
                                        
                                  </select>
                              </div>

                                <?php
                                    $payment_type =  $this->db->select('*')->from('payment_type')->where('status',1)->get()->result() ;
                                    //print_r($payment_type);
                                    ?>

                              <div class="form-group"  id="paymentTypeDiv">
                                  <select required="" class="form-control" id="paymentType" name="paymentType">
                                        <option value="">Select Payment Pay With</option>
                                        <?php foreach ($payment_type as $key => $value) {
                                            ?>
                                            <option  value="<?php echo $value->payment_type ?>">
                                                <?php echo $value->name ?>
                                            </option>
                                        <?php
                                        } ?>
                                  </select>
                              </div>
                              <input type="hidden" name="loginType" id="loginType" value="1">
                              <input type="hidden" name="userId" id="userId" value="<?php echo $value->id ?>">
                              <button type="submit" class="btn gradient-bg mr-2">Submit</button>
                              <br>
                            </form>

                         <?php }elseif($message == 2){ ?>

                            <?php //print_r($userData) ; ?>
                              <div class="form-group">
                                    <label for="TXN_AMOUNT">Name(Rs):</label>
                                    <input type="text" readonly="" class="form-control"  value="<?php echo $userData[0]->name ?>">
                              </div>
                              <div class="form-group">
                                    <label for="TXN_AMOUNT">Registraion Package:</label>
                                    <input type="text" readonly="" class="form-control"  value="<?php echo $regpackage->description ?>">
                              </div>
                            <form method="post" action="<?php echo base_url('paytm/paymantRedirect') ?>">
                              <div class="form-group">
                                    <label for="TXN_AMOUNT">Package Amount(Rs):</label>
                                    <input type="text" readonly="" class="form-control" id="TXN_AMOUNT" name="TXN_AMOUNT" value="1">
                              </div>
                              <!-- <div class="form-group">
                                    <label for="TXN_AMOUNT">Package Amount(Rs):</label>
                                    <input type="text" readonly="" class="form-control" id="TXN_AMOUNT" name="TXN_AMOUNT" value="<?php echo $amount ?>">
                              </div> -->
                              <div class="form-group">
                                   <input type="hidden" class="form-control" id="ORDER_ID" name="ORDER_ID" value="<?php echo base64_encode($orderId)  ?>">
                               </div>
                               <div class="form-group">
                                  <input type="hidden" class="form-control" id="CUST_ID" name="CUST_ID" value="<?php echo $userId ?>">
                               </div>
                               <div class="form-group">
                                  <input type="hidden" id="INDUSTRY_TYPE_ID" tabindex="4" maxlength="12" size="12" name="INDUSTRY_TYPE_ID" autocomplete="off" value="Retail109">
                               </div>
                              <div class="form-group">
                                  <input type="hidden" id="CHANNEL_ID" tabindex="4" maxlength="12" size="12" name="CHANNEL_ID" autocomplete="off" value="WEB"> 
                              </div> 
                              <div class="form-group">
                                  <input type="submit" class="btn" value="Pay"> 
                              </div> 
                          </form>


                          <?php   } ?>  

        
                        </div>
                </div>
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .home-page-icon-boxes -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        function changevalue(){
           // alert();
           var regpackage = $("#regpackage").val();
           //alert(regpackage); 

           if(regpackage ==1)
           {
            $('#paymentTypeDiv').text('');
            $('#paymentTypeDiv').append('<select required="" class="form-control" id="paymentType" name="paymentType"><option value="1">Select Payment Pay With</option><option value="1">Cash On Library </option><option value="2">By Bank Manualy</option><option value="4">Payment Gateway</option></select>');
            }else{
                $('#paymentTypeDiv').text('');
            $('#paymentTypeDiv').append('<select required="" class="form-control" id="paymentType" name="paymentType"><option value="1">Select Payment Pay With</option><option value="1">Cash On Library </option><option value="2">By Bank Manualy</option></select>');
            }


           //
        }

    </script>


    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.collapsible.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/swiper.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.countdown.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/circle-progress.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.countTo.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.barfiller.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/custom.js'></script>

</body>
</html>



