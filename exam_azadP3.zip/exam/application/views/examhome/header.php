<!DOCTYPE html>
<html lang="en">
<head>
    <title>आज़ाद सेल्फ हेल्प ग्रुप -मानव सेवा ही ईश्वर सेवा</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/bootstrap.min.css">

    <!-- FontAwesome CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/font-awesome.min.css">

    <!-- ElegantFonts CSS --> 
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/elegant-fonts.css">

    <!-- themify-icons CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/themify-icons.css">

    <!-- Swiper CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/swiper.min.css">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>style.css">
    <style type="text/css">
        .mt20{
            margin-top: 20px !important;
        }
    </style>
        <script>
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
          ga('create', 'UA-126787402-1', 'auto');
          ga('send', 'pageview');
        </script>
</head>
<body>
    <header class="site-header">
        <div class="top-header-bar">
            <div class="container">
                <div class="row flex-wrap justify-content-center justify-content-lg-between align-items-lg-center">
                    <div class="col-12 col-lg-8 d-none d-md-flex flex-wrap justify-content-center justify-content-lg-start mb-3 mb-lg-0">
                        <div class="header-bar-email">
                            MAIL: <a href="#">azadhelpgroup@gmail.com</a>
                        </div><!-- .header-bar-email -->

                        <div class="header-bar-text">
                            <p>PHONE: <span>+7566660264</span></p>
                        </div><!-- .header-bar-text -->
                       
                    </div><!-- .col -->

                    <div class="col-12 col-lg-4 d-flex flex-wrap justify-content-center justify-content-lg-end align-items-center">
                        <div style="display: none"class="donate-btn">
                            <a href="#">Donate Now</a>
                        </div><!-- .donate-btn -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .top-header-bar -->

        <div class="nav-bar">
            <div class="container">
                <div class="row">
                    <div class="col-12 d-flex flex-wrap justify-content-between align-items-center">
                        <div class="site-branding d-flex align-items-center">
                           <a class="d-block" href="<?php echo base_url('exam') ?>" rel="home"><img src="https://ashgindia.org/wp-content/uploads/2018/09/logo_white.png" width="200" height="56" alt="आज़ाद सेल्फ हेल्प ग्रुप" data-width="200" data-height="56"></a>
                        </div><!-- .site-branding -->

                        <?php
                             $manu1  = $this->uri->segment(1);
                             if($manu1 == 'exam'){
                                $exam = 'class="current-menu-item"';
                             }else{
                                $exam = '';
                             }


                             $manu  = $this->uri->segment(2);
                             if($manu == 'library'){
                                $lib = 'class="current-menu-item"';$exam = '';
                             }else{
                                $lib = '';
                             }


                             if($manu == 'papers'){
                                $ppr = 'class="current-menu-item"';$exam = '';
                             }else{
                                $ppr = '';
                             }
                           
                             if($manu == 'onlineTestAns'){
                                $ppr2 = 'class="current-menu-item"';$exam = '';
                             }else{
                                $ppr2 = '';
                             }
                            



                             if($manu == 'profile'){
                                $pro = 'class="current-menu-item"';$exam = '';
                             }else{
                                $pro = '';
                             }


                             if($manu == 'bloodgroup'){
                                $bloodgroup = 'class="current-menu-item"';$exam = '';
                             }else{
                                $bloodgroup = '';
                             } 


                            
                            if($manu == 'payments'){
                                $payments = 'class="current-menu-item"';$exam = '';
                             }else{
                                $payments = '';
                            } 


                            if($manu == 'gallery'){
                                $gallery = 'class="current-menu-item"';$exam = '';
                             }else{
                                $gallery = '';
                            } 


                            if($manu == 'currentnews'){
                                $currentnews = 'class="current-menu-item"';$exam = '';
                             }else{
                                $currentnews = '';
                             }
                             if($manu == 'newsmore'){
                                $newsmore = 'class="current-menu-item"';$exam = '';
                             }else{
                                $newsmore = '';
                             }
                            
                            
                        ?>

                        <nav class="site-navigation d-flex justify-content-end align-items-center">
                            <ul class="d-flex flex-column flex-lg-row justify-content-lg-end align-content-center">
                                <li <?php echo $exam ?>><a href="<?php echo base_url('exam') ?>">Home</a></li>
                                <li <?php echo $lib ?> ><a href="<?php echo base_url('exam/library') ?>">Library</a></li>
                                <li <?php echo $gallery ?> ><a href="<?php echo base_url('exam/gallery') ?>">Gallery</a></li>
                                <li <?php echo $ppr.$ppr2 ?> ><a href="<?php echo base_url('exam/papers/') ?>">Online Test</a></li>
                                <li <?php echo $payments ?> ><a href="<?php echo base_url('exam/payments/') ?>">Payment</a></li>
                                <li <?php echo $pro ?>><a href="<?php echo base_url('exam/profile') ?>">Profile</a></li>
                                <li <?php echo $bloodgroup ?>><a href="<?php echo base_url('exam/bloodgroup') ?>">Blood Group</a></li>
                                <li <?php echo $currentnews.$newsmore ?>><a href="<?php echo base_url('exam/currentnews') ?>">Current Facts</a></li>
                                <li><a href="<?php echo base_url('exam/logout') ?>">Logout</a></li>
                            </ul>
                        </nav><!-- .site-navigation -->

                        <div class="hamburger-menu d-lg-none">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div><!-- .hamburger-menu -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .nav-bar -->
          <div class="top-header-bar" style="background: #51d24e;">
            <div class="container">
                <div class="row flex-wrap justify-content-center justify-content-lg-between align-items-lg-center">
                    <div class="col-12 col-lg-4 d-flex flex-wrap justify-content-center justify-content-lg-end align-items-center">
                        <div class="donate-btn" >
                            <span style="padding: 20px 40px;"></span>
                        </div><!-- .donate-btn -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .top-header-bar -->
    </header><!-- .site-header -->
