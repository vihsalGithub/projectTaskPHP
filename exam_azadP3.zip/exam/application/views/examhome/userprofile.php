
<style type="text/css">
    .icon-box:hover, .icon-box.active {
    background: #ecf2f5 !important;
}
.icon-box:hover .entry-title, .icon-box.active .entry-title {
    color: #262626 !important;
}
.icon-box:hover .entry-content p, .icon-box.active .entry-content p {
    color: #262626;
}
</style>

    <div class="home-page-icon-boxes" style="min-height: 500px;">
        <div class="container">
            <div class="row">
              
                <div class="col-12 col-md-12 col-lg-12 mt-4 mt-lg-0  mt20" id="topdiv">
                      <div class="table-responsive">          
                      <table class="table">
                        <?php //print_r($userdata); ?>
                        <thead>
                            <th colspan="2" class="text-left"><h3>Profile Details<h3></th>
                        </thead>
                        <tbody>
                          <tr>
                            <td><b>Name</b></td>
                            <td> <?php echo $userdata->name  ?></td>
                          </tr>
                          <tr>
                            <td><b>Eamil</b></td>
                            <td> <?php echo $userdata->email ?></td>
                          </tr>
                          <tr>
                            <td><b>Username</b></td>
                            <td> <?php echo $userdata->email  ?></td>
                          </tr>
                          <tr>
                            <td><b>Contact No.</b></td>
                            <td> <?php echo $userdata->contact_no  ?></td>
                          </tr>
                          <tr>
                            <td><b>Payment Status</b></td>
                            <td> <?php 
                              if($userdata->payment_status ==1){
                                  echo "<b class='text-success'>Activated</b>" ;
                              }else{
                                  echo "<b class='text-danger'>Deactivated</b>" ;
                              }
                            ?></td>
                          </tr>
                          <tr>
                            <td><b>Registration Date</b></td>
                            <td> <?php echo $userdata->reg_date  ?></td>
                          </tr> 
                          <tr>
                            <td><b>Start Date</b></td>
                            <td> <?php echo $userdata->start_date  ?></td>
                          </tr>
                          <tr>
                            <td><b>Expire Date</b></td>
                            <td> <?php echo $userdata->exp_date  ?></td>
                          </tr>
                          <tr>
                            <td><b>Registration Package</b></td>
                            <?php
                              $package =  $this->db->select('description')->from('oe_package')->where('pack_id',$userdata->package_type)->get()->row() ;
                            ?>
                            <td> <?php echo $package->description  ?></td>
                          </tr>
                           <tr>
                            <td><a class="btn btn-success" style="color:#fff" href="<?php echo base_url('exam/editprofile/') ?>">Edit Profile</a></td>
                            <td></td>
                          </tr> 
                        </tbody>
                      </table>
                      </div>
                </div>
                
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .home-page-icon-boxes -->


<!-- Modal -->
<div style="z-index: 2147483647;" id="myModal"  class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
 <!-- <script type="text/javascript">
     function editprofile(){
      //alert();
        $("#myModal").modal('show') ;
     }
 </script> -->   
