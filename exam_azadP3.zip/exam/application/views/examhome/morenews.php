  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<style type="text/css">
    .icon-box:hover, .icon-box.active {
    background: #ecf2f5 !important;
}
.icon-box:hover .entry-title, .icon-box.active .entry-title {
    color: #262626 !important;
}
.icon-box:hover .entry-content p, .icon-box.active .entry-content p {
    color: #262626;
}
</style>





 <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css"> -->


    <div class="home-page-icon-boxes" style="min-height: 500px;">
        <div class="container">
            <div class="row">
              <?php //print_r($currentnews) ; ?>
                <div class="col-md-12" style="border: 1px solid #ccc;padding:20px; ">
                      <h1><?php echo $currentnews->news_title ?></h1>
                      <p><?php echo $currentnews->news_category ?></p>
                      <div class="carousel-inner" role="listbox">
                        <div class="item active">
                          <img style="width: 100%;max-height:250px" src="<?php echo $currentnews->news_image ?>" alt="Image">
                          <div class="carousel-caption">
                            <!-- <h3>Sell $</h3>
                            <p>Money Money.</p> -->
                          </div>      
                        </div>
                      </div>
                      <p><?php echo $currentnews->news ?></p>
                </div>
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .home-page-icon-boxes -->




<script src="<?php echo base_url() ; ?>/assets/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url() ; ?>/assets/vendor/datatables/dataTables.bootstrap4.js"></script>




 <script type="text/javascript">
     function editprofile(){
        $("#myModal").modal('show');
     }
 </script>   
