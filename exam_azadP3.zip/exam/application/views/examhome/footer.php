 <footer class="site-footer">
        <div class="footer-bar">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <p class="m-0">5,Janki Nagar Near BRTS Opposite Sky Heights,Navlakha Indore 452001</p>
                        <p class="m-0"><b><a style="color: #fff;" href="<?php echo base_url('exam/contactus') ?>">Contact With Our Team</a></b></p>
                    </div><!-- .col-12 -->
                    <!--  <div class="header-bar-email" style="margin-left: 10px;font-weight: bold;">
                        
                    </div> -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .footer-bar -->
    </footer><!-- .site-footer -->

    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.collapsible.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/swiper.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.countdown.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/circle-progress.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.countTo.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/jquery.barfiller.js'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/home/') ?>js/custom.js'></script>

</body>
</html>