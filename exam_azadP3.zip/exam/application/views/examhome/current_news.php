  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<style type="text/css">
    .icon-box:hover, .icon-box.active {
    background: #ecf2f5 !important;
}
.icon-box:hover .entry-title, .icon-box.active .entry-title {
    color: #262626 !important;
}
.icon-box:hover .entry-content p, .icon-box.active .entry-content p {
    color: #262626;
}
</style>





 <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css"> -->


    <div class="home-page-icon-boxes" style="min-height: 500px;">
        <div class="container">
            <div class="row">
                    <?php //print_r($currentnews)  ?>
                      <div class="table-responsive">          
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                          <thead>
                            <tr>
                              <th>Sn</th>
                              <th>Title</th>
                              <th>More Details</th>
                            </tr>
                          </thead>
                          <tfoot>
                            <tr>
                              <th>Sn</th>
                              <th>Title</th>
                              <th>More Details</th>
                            </tr>
                          </tfoot>
                          <tbody>
                          <?php foreach($currentnews  as $key=>$data){ ?>
                            <tr>
                               <td><?php echo $key+1?></td>
                                <td><?php echo $data->news_title ?></td>
                                <td><a href="<?php echo base_url('exam/newsmore/').$data->id ?>" style="color:#fba306">More Detals</a></td>
                            </tr>
                          <?php } ?>
                          </tbody>
                        </table>
                        </div>
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .home-page-icon-boxes -->


<!-- Modal -->
<div style="z-index: 2147483647;"id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<script src="<?php echo base_url() ; ?>/assets/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url() ; ?>/assets/vendor/datatables/dataTables.bootstrap4.js"></script>




 <script type="text/javascript">
     function editprofile(){
        $("#myModal").modal('show');
     }
 </script>   
