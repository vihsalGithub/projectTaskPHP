  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<style type="text/css">
    .icon-box:hover, .icon-box.active {
    background: #ecf2f5 !important;
}
.icon-box:hover .entry-title, .icon-box.active .entry-title {
    color: #262626 !important;
}
.icon-box:hover .entry-content p, .icon-box.active .entry-content p {
    color: #262626;
}
</style>

    <div class="home-page-icon-boxes" style="min-height: 500px;">
        <div class="container">
            <div class="row">

                 
                <div class="col-12 col-md-12 col-lg-12 mt-4 mt-lg-0  mt20" id="topdiv">
                      <div class="table-responsive">          
                        <table class="table">
                          <thead>
                            <tr>
                              <th>#</th>
                              <th>Transection Id</th>
                              <th>Amount</th>
                              <th>Payment Status</th>
                              <th>Package</th>
                              <th>Date</th>
                              <th>Package Expire Date</th>
                            </tr>
                          </thead>
                          <tbody>
                          <?php foreach($payments  as $key=>$data){ ?>
                            <tr>
                              <td><?php echo $key+1 ?></td>
                              <td><?php echo $data->txnid ?></td>
                              <td><?php echo $data->amount ?> Rs.</td>
                              <td><?php echo $data->status ?></td>
                              <td>
                                  <?php
                              $package =  $this->db->select('description')->from('oe_package')->where('pack_id',$data->productinfo)->get()->row() ;
                                  echo $package->description 
                             ?>
                                </td>
                              <td><?php echo $data->date ?></td>
                              <td><?php echo $data->exp_date ?></td>
                            </tr>
                          <?php } ?>
                          </tbody>
                        </table>
                        </div>
                </div>
                
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .home-page-icon-boxes -->


<!-- Modal -->
<div style="z-index: 2147483647;"id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

 <script type="text/javascript">
     function editprofile(){
        $("#myModal").modal('show');
     }
 </script>   
