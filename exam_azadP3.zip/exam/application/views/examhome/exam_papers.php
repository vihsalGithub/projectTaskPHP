

<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-126787402-1', 'auto');
  ga('send', 'pageview');
</script>


<style type="text/css">
@media only screen and (min-width: 600px) {
    #questContainer{
        padding: 40px 24px;
    min-height: 600px;
    width: 500px;
    margin: 0px auto;
    background-color: #fff;
    box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
    color: black;
    }
}

@media only screen and (max-width: 600px) {
    #questContainer{
        padding: 40px 24px;
    margin: 0px auto;
    background-color: #fff;
    box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
    color: black;
    }
}
</style>
<style>
/* The container */
.container1 {
    display: block;
    position: relative;
    padding-left: 35px;
    margin-bottom: 12px;
    cursor: pointer;
    font-size: 22px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

/* Hide the browser's default radio button */
.container1 input {
    position: absolute;
    opacity: 0;
    cursor: pointer;
}

/* Create a custom radio button */
.checkmark {
    position: absolute;
    top: 0;
    left: 0;
    height: 25px;
    width: 25px;
    background-color: #eee;
    border-radius: 50%;
}

/* On mouse-over, add a grey background color */
.container1:hover input ~ .checkmark {
    background-color: #ccc;
}

/* When the radio button is checked, add a blue background */
.container1 input:checked ~ .checkmark {
    background-color: #2196F3;
}

/* Create the indicator (the dot/circle - hidden when not checked) */
.checkmark:after {
    content: "";
    position: absolute;
    display: none;
}

/* Show the indicator (dot/circle) when checked */
.container1 input:checked ~ .checkmark:after {
    display: block;
}

/* Style the indicator (dot/circle) */
.container1 .checkmark:after {
    top: 9px;
    left: 9px;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: white;
}
.quesNo{
    padding: 10px;
    margin-left: 10px;
    border: 50%;
    color: #fff;
    background: #fba306;
    border-radius: 50%;
    font-size: 15px;
    line-height: 10px;
    text-align: center;
}
.mb20{
    margin-bottom: 20px;
}
.exam-form{
    padding-left: 35px;
}
.border{
    border: 1px solid #ccc;
        padding-top: 10px;
}
.paperHead{
        text-align: center;
    font-size: 22px;
    shape-image-threshold: b;
    font-weight: bold;
}
</style>
    <div class="home-page-icon-boxes">
        <div class="container">
            <div class="row">

                    <div class="col-sm-12 col-xs-12  col-md-4 col-lg-4 border " style="margin-top:10px;padding:10px">
                         <?php 
                         foreach ($question as $key => $ques) {
                           // echo '<a>'.$ques->id.'</a>';
                            //echo $ques->id ;
                             if($key%8 == 0){
                                echo '<div class="clearfix mb20"></div>';
                             }
                             $html = '<a href="'.base_url('examtestquizstart/').$ques->id.'"><b class="quesNo">';
                                      $html .=  ($key+1);
                             $html .= '</b></a>';
                             echo $html ;
                         }
                      //print_r($question);
                    ?>
                    </div>
                    <div class="col-sm-12 col-xs-12 col-md-8 col-lg-8 mt-8 border" style="margin-top:10px;">
                            <div style="width:100%"><span id="time2"></span></div>
                            <h4 class="text-center">MP Psc Paper 1</h4>
                            <p class=""><span>Marks 0</span>  <span style="float: right">Question 1 / 10</span></p>
                            <label class="container1 question"><span>(1) <span>केन्&zwj;द्रीय जल एवं विधुत शोध केन्&zwj;द्र कहॉं स्थित है?</span></span></label>
                            <div class="exam-form">
                            <form style="width:100%" method="post" action="http://localhost/vishal/exam/exam/process/">
                                <label class="container1">खड़गवासला
                                  <input type="radio" name="choice" value="1">
                                  <span class="checkmark"></span>
                                </label>
                                <label class="container1">दिल्&zwj;ली में
                                  <input type="radio" name="choice" value="2">
                                  <span class="checkmark"></span>
                                </label>
                                <label class="container1">जामनगर में
                                  <input type="radio" name="choice" value="3">
                                  <span class="checkmark"></span>
                                </label>
                                <label class="container1">श्रीसैलम में
                                  <input type="radio" name="choice" value="4">
                                  <span class="checkmark"></span>
                                </label>
                                    <input type="hidden" name="choiceQuesid" value="402">
                                  <input style="margin:20px 0px" class="btn gradient-bg mr-2" type="submit" value="submit">
                            </form>
                            </div>
                            <p class=""><a href="#"><< Previus</a>  <a  href="#" style="float: right">Next >></a></p>
                    </div>
                <div class="col-12 co;l-md-12 col-lg-12 mt-12 mt-lg-0">
                </div>
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .home-page-icon-boxes -->


    <script type="text/javascript">
        function startTimer(duration, display) {
    var timer = duration, minutes, seconds;
    setInterval(function () {
        minutes = parseInt(timer / 60, 10)
        seconds = parseInt(timer % 60, 10);

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display.textContent = minutes + ":" + seconds;

        if (--timer < 0) {
            timer = duration;
        }
    }, 1000);
}

window.onload = function () {
    var fiveMinutes = 60 * 5,
        display = document.querySelector('#time');
    startTimer(fiveMinutes, display);
};
    </script>
