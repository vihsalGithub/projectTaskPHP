
   
<style type="text/css">
    .icon-box:hover, .icon-box.active {
    background: #ecf2f5 !important;
}
.icon-box:hover .entry-title, .icon-box.active .entry-title {
    color: #262626 !important;
}
.icon-box:hover .entry-content p, .icon-box.active .entry-content p {
    color: #262626;
}
</style>

    <div class="home-page-icon-boxes">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-12" id="topdiv">
                <?php 
                    $userData = $this->db->select('*')->from('oe_users')->where(array('user_id'=>$_SESSION['user_id']))->get()->result();
                    if($userData[0]->payment_status ==0){
                        echo '<p  class="text-danger text-center"><b>Dear '.$userData[0]->name.' Your paymant Status id deactivate please arenue your account <a class="btn" href="'.base_url("exam/paymantrenue").'">Activate</a></b></p>';
                    }
                 ?>
                </div>
                <div class="col-12 col-md-6 col-lg-4 mt-4 mt-lg-0 " id="topdiv">
                    <div class="icon-box">
                        <header class="entry-header">
                            <h3 class="entry-title">Library</h3>
                        </header>

                        <div class="entry-content">
                            
                            <a href="<?php echo base_url('exam/library') ?>" class="btn gradient-bg mr-2">More Details</a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4 mt-4 mt-lg-0 " id="topdiv">
                    <div class="icon-box">
                        <header class="entry-header">
                            <h3 class="entry-title">Blood Donation</h3>
                        </header>

                        <div class="entry-content">
                            <a href="<?php echo base_url('exam/bloodgroup') ?>" class="btn gradient-bg mr-2">More Details</a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4 mt-4 mt-lg-0 " id="topdiv">
                    <div class="icon-box">
                        <header class="entry-header">
                            <h3 class="entry-title">Gallery</h3>
                        </header>

                        <div class="entry-content">
                            <a href="<?php echo base_url('exam/gallery') ?>" class="btn gradient-bg mr-2">More Details</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row" style="margin-top: 20px;">
                <div class="col-12 col-md-6 col-lg-4 mt-4 mt-lg-0 " id="topdiv">
                    <div class="icon-box">
                        <header class="entry-header">
                            <h3 class="entry-title">Online Test</h3>
                        </header>

                        <div class="entry-content">
                            
                            <a href="<?php echo base_url('exam/papers/') ?>" class="btn gradient-bg mr-2">More Details</a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4 mt-4 mt-lg-0 " id="topdiv">
                    <div class="icon-box">
                        <header class="entry-header">
                            <h3 class="entry-title">Current Facts</h3>
                        </header>

                        <div class="entry-content">
                            
                            <a href="<?php echo base_url('exam/currentnews/') ?>" class="btn gradient-bg mr-2">More Details</a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4 mt-4 mt-lg-0 " id="topdiv">
                    <div class="icon-box">
                        <header class="entry-header">
                            <h3 class="entry-title">Paymants Detail</h3>
                        </header>

                        <div class="entry-content">
                            <a href="<?php echo base_url('exam/payments/') ?>" class="btn gradient-bg mr-2">More Details</a>
                        </div>
                    </div>
                </div>
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .home-page-icon-boxes -->
