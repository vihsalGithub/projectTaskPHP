<!-- Sidebar -->
<?php  
$dashboardManu  = $this->uri->segment(1);
 if($dashboardManu == "user"){
      $dashboardactive = 'active';
  }else{
      $dashboardactive = '';
  }
$manuname = $this->uri->segment(2);
  //echo $manuname;
  if($manuname == "userprofile"){
      $userprofile = 'active';
       $dashboardactive = '';
  }else{
      $userprofile = '';
  }
  if($manuname == "paymentprocess"){
      $userpayment = 'active';
       $dashboardactive = '';
  }else{
      $userpayment = '';
  }
  if($manuname == "library"){
      $userlib = 'active';
       $dashboardactive = '';
  }else{
      $userlib = '';
  }
  if($manuname == "bloodgroupinfo"){
      $userbg = 'active';
       $dashboardactive = '';
  }else{
      $userbg = '';
  }
  if($manuname == "events"){
      $userevents = 'active';
       $dashboardactive = '';
  }else{
      $userevents = '';
  }
?>
<?php if($this->session->userdata('status')){ ?>
      <ul class="sidebar navbar-nav">
        <li class="nav-item <?php echo $dashboardactive ;?>">
          <a class="nav-link" href="<?php echo base_url('user'); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
          </a>
        </li>
       <li class="nav-item <?php echo $userprofile ;?>">
          <a class="nav-link" href="<?php echo base_url('user/userprofile'); ?>">
            <i class="fa fa-user"></i>
            <span>My Profile</span>
          </a>
        </li>
      <li class="nav-item  <?php echo $userpayment ?>">
          <a class="nav-link" href="<?php echo base_url('user/paymentprocess'); ?>">
            <i class="far fa-credit-card"></i>
            <span>Payment Detail</span>
          </a>
        </li>
       <li class="nav-item <?php echo $userlib ;?>">
          <a class="nav-link" href="<?php echo base_url('user/library'); ?>">
            <i class="fas fa-fw fa-folder"></i>
            <span>Library</span>
          </a>
        </li>

         <li class="nav-item <?php echo $userbg ;?>">
          <a class="nav-link" href="<?php echo base_url('user/bloodgroupinfo'); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>BG Infromation</span>
          </a>
        </li> 

        <li class="nav-item <?php echo $userevents ;?>">
          <a class="nav-link" href="<?php echo base_url('user/events'); ?>">
            <i class="fa fa-calendar"></i>
            <span>Events</span>
          </a>
        </li>
        
      </ul>
<?php }else {?>
      <ul class="sidebar navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo base_url('user/userprofile'); ?>">
            <i class="fa fa-user"></i>
            <span>My Profile</span>
          </a>
        </li>

        <li class="nav-item active">
          <a class="nav-link" href="<?php echo base_url('user/paymentprocess'); ?>">
            <i class="far fa-credit-card"></i>
            <span>Payment Process</span>
          </a>
        </li>

          <?php 
            if(!empty($userData->blood_group)){
          ?>
            
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo base_url('user/bloodgroupinfo'); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Blood Group Infromation</span>
          </a>
        </li> 


          <?php  }
          ?>
      </ul>
<?php } ?>