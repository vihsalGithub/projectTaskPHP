

    <div id="wrapper">

      <?php include "sidebar.php" ; ?>


      <div id="content-wrapper">

        <div class="container-fluid">
          <!-- Breadcrumbs-->
           
                <?php if($this->session->status){ ?>
                     <p class="breadcrumb-item alert alert-success">Your Account is registered please complete 2nd step of registration for enjoyee of all services of orgnization</p>
                <?php }else{ ?>
                     <p class=" alert alert-danger">Please Activate Your Account</p>
                 <?php } ?>
        

        <?php //print_r($bloodDataGroup) ; ?>
          <!-- Icon Cards-->
    <div class="container">
          <div class="row">
           
            <div class=" col-xl-12  col-md-12  col-sm-12">
                <h2>Blood Group Inforamtion</h2>
                <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th>No.</th>
                        <th>Blood Type  </th>
                        <th>Donate Blood To </th>
                        <th>Receive Blood From</th>
                        
                        <th>More</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($bloodDataGroup as $key => $value) {
                      ?>
                      <tr>
                        <td><?php echo  $key+1 ?></td>
                        <td><?php echo  $value->blood_group ?></td>
                        <td><?php echo  $value->donate_blood_to ?></td>
                        <td><?php echo  $value->receive_blood_from ?></td>
                        <td><a href="#">More Details</a></td>
                      </tr>
                    <?php
                      }
                    ?>
                    </tbody>
                  </table>
                 
            </div>
          </div>
    </div>
  </div>
        <!-- /.container-fluid -->

       <?php include "footersticky.php" ;?>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->
