

    <div id="wrapper">

      <?php include "sidebar.php" ; ?>



      <div id="content-wrapper">

        <div class="container-fluid">
          <!-- Breadcrumbs-->
                <?php if($this->session->status){ ?>
                     <p class="breadcrumb-item alert alert-success">Please complete your profile</p>
                <?php
                 }else{ ?>
                     
                         <?php 
                            if(empty($userData->blood_group)){
                                echo '<p class=" alert alert-success">Your Account is registered please complete 2nd step of registration</p>';
                            }
                          ?>
                        <p class=" alert alert-danger">Please Activate Your Account</p>

                       
                 <?php } ?>
        
          <!-- Icon Cards-->
    <div class="container">
          <div class="row">
           
            <div class="border  padding10 whitebg col-xl-6 col-md-6  col-sm-12">
                   <h2>Profile</h2>
			
         <form class=" form-horizontal" method="post" enctype="multipart/form-data" id="userProfileForm" action="<?php echo base_url('user/profileform') ?>">

                  <input type="hidden" id="userID" name="userID" value="<?php echo $this->session->userdata('user_id'); ?>">
                    
                     <div class="form-group">
                      <label class="control-label col-sm-12" for="Pincode">Profile Image:</label>
                      <div class="col-sm-12">          
                        <img class=" imgcenter " width="100px"  src="<?php echo base_url() ?>/<?php  
                          if(!empty($userData->image)){
                            echo $userData->image ;
                          }else{
                            echo 'uploads/ashg/logo.jpg';
                          }
                         ?>">
                      </div>
                       <?php  
                              if(!empty($userData->image)){
                                $imgpath =  base_url().$userData->image  ;
                              }else{
                                $imgpath =  base_url().LOGOURL  ;
                              }
                       ?>
                      <div class="col-sm-12">          
                        <input type="file" class="form-control" id="imageUP"  value="<?php echo $imgpath ?>" name="imageUP">
                      </div>
                    </div>


                    <div class="form-group">
                      <label class="control-label col-sm-12" for="username">Name</label>
                      <div class="col-sm-12">
                        <input type="text" readonly class="form-control" id="usernameUP" value="<?php echo $this->session->userdata('user_name'); ?>" name="usernameUP">
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-sm-12" for="useremail">Email:</label>
                      <div class="col-sm-12">          
                        <input type="text" readonly class="form-control" id="useremailUP" value="<?php echo $this->session->userdata('email'); ?>" name="useremailUP">
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-sm-12" for="fatehername">Father Name:</label>
                      <div class="col-sm-12">          
                        <input type="text" class="form-control" id="fatherUP" placeholder="Enter Father Name"  value="<?php echo $userData->father_name ?>" name="fatherUP">
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-sm-12" for="fatehername">Highest Qualification:</label>
                      <div class="col-sm-12">          
                        <input type="text" class="form-control" id="qualificationUP" placeholder="Enter qualification Name"  value="<?php echo $userData->qualifiaction ?>" name="qualificationUP">
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-sm-12" for="bloodgroup"> Blood Group:</label>
                      <div class="col-sm-12 ">          
                         <select class="col-sm-12 form-control" name="bloodgroupUP" id="bloodgroupUP" >
                          <option value="<?php  echo $userData->blood_group  ?>">
                            
                            <?php  
                              if(!empty($userData->blood_group)){
                                echo $userData->blood_group  ;
                              }else{
                                echo 'Selected';
                              }
                             ?>

                          </option>
                            <option value="o_negative">O negative</option>
                            <option value="o_positive">O positive</option>
                            <option value="a_negative">A negative</option>
                            <option value="a_positive">A positive</option>
                            <option value="b_negative">B negative</option>
                            <option value="b_positive">B positive</option>
                            <option value="ab_positive">AB positive</option>
                            <option value="ab_positive">AB positive</option>
                          </select> 
                      </div>
                    </div>



                    <div class="form-group">
                      <label class="control-label col-sm-12" for="address">Address:</label>
                      <div class="col-sm-12">          
                        <input type="text" class="form-control" id="addressUP" placeholder="Enter Address" value="<?php echo $userData->address ?>" name="addressUP">
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-sm-12" for="state">State:</label>
                      <div class="col-sm-12">          
                        <input type="text"  readonly="" class="form-control" id="stateUP" placeholder="Enter state " value="Madhya Pradesh" name="stateUP">
                      </div>
                    </div>


                    <div class="form-group">
                      <label class="control-label col-sm-12" for="state">City:</label>
                      <div class="col-sm-12">          
                        <input type="text" value="Indore" value="<?php echo $userData->city ?>" class="form-control" id="cityUP" placeholder="Enter city" name="cityUP">
                      </div>
                    </div>

  

                    <div class="form-group">
                      <label class="control-label col-sm-12" for="Pincode">Pincode:</label>
                      <div class="col-sm-12">          
                        <input type="text" value="<?php echo $userData->pincode ?>" class="form-control" id="pincodeUP" placeholder="Enter Pincode" name="pincodeUP">
                      </div>
                    </div>
                   
                    <div class="form-group">        
                      <div class="col-sm-offset-2 col-sm-12">
                        <button type="submit" id="submitUP" class="btn btn-success">Submit</button>
                        <span id="buttonMessageUP"></span>
                      </div>
                    </div>
                  </form>
                </div>
               
               
                <div class="  col-xl-6 col-md-6  col-sm-12">
                    <?php if(!empty($userData->blood_group)){   ?>

                    <div class=" border padding10 col-sm-12 col-md-12">
                        <h2>Get Referral Url</h2>
                        <p>
                           You can referral url and share of url for pramosion of ashg oragnization
                           if candite are registred by your url than you get bonas marks and this bonas marks use for ashg fee
                        </p>
                        <button  class="btn btn-success mb20">Get URl</button>
                        <?php 
                        $token = $userData->user_id.'_'.time();
                        $tokenid = base64_encode($token) ;
                         ?>
                        <input type="text" class="form-control" value="<?php echo base_url() ?>home/referral/<?php echo $tokenid ?>">
                        <p class="text-danger">
                           <span>*</span>Your Link work when your account is actvate
                        </p>
                    </div>

                    <?php } ?>
                </div>



            </div>
    </div>
  </div>
        <!-- /.container-fluid -->

       <?php include "footersticky.php" ;?>
          <script type="text/javascript">
                   
              $("#submitUP").click(function() {

              var  waitimg = '<?php echo base_url('uploads/ashg/loader.gif') ?>' ;
              $('form[id="userProfileForm"]').validate({
              rules: {
                
                fatherUP: 'required',
                bloodgroupUP: 'required',
                qualification: 'required',
                addressUP: 'required',
                stateUP: 'required',
                cityUP: 'required',
                pincodeUP: 'required',
                },
                 errorPlacement: function(){
                  return false;   
                },
                submitHandler: function(form) {
                  $('#submitUP').hide(); 
                  $('#buttonMessageUP').append('<img src="'+waitimg+'" width="40px" height="40px" class="mb20" >') ; 
                  return true ;      
                 }
              });
            });
          </script>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->
