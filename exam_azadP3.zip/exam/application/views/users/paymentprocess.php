

    <div id="wrapper">

      <?php include "sidebar.php" ; ?>


      <div id="content-wrapper">

        <div class="container-fluid">
          <!-- Breadcrumbs-->
           
                <?php if($this->session->status){ ?>
                     <p class="breadcrumb-item alert alert-success">Your Account is registered please complete 2nd step of registration for enjoyee of all services of orgnization<br>

                     </p>
                <?php }else{ ?>
                     <p class=" alert alert-danger">Please Activate Your Account</p>
                 <?php } ?>
        

        <?php /*print_r($userData)  ;
        	echo '<br>';
        	echo $this->session->userdata('status') ;
        	echo '<pre>';
var_dump($_SESSION);
echo '</pre>';
*/
         ?>
          <!-- Icon Cards-->
    <div class="container">
          <div class="row">
          
            <div class=" col-xl-6  col-md-6  col-sm-12 border mb20 mt20">
               		<h2>Payment Process</h2>
					<form class=" " id="addCardModelCss">
					  <div class="form-group col-md-12">
				    	<img style="width:100%" src="<?php echo base_url('/uploads/ashg/Visa_Master_Discover_Amex.png') ; ?>">
				      </div>
					  <div class="form-group col-md-12 ">
					    <label for="pwd">Card Holder Name:</label>
					    <input  required type="text" class="form-control" value="<?php echo $this->session->userdata('user_name') ;?>" id="card_holder_nameForm">
					    <input type="hidden" class="form-control" id="user_id" value="">
					  </div>
					   
					   <div class="form-group col-md-12 ">
					    <label for="cardnumber">Card Number:</label>
					    <input required type="text" class="form-control" onchange="cardNumber()" maxlength="16" value="" id="cardnumberForm" value>
					  </div>
					  <div class="form-group col-md-12 ">
					    <label for="carcvv">Card CVV:</label>
					    <input required type="text" class="form-control"  maxlength="4" value="" id="cardcvv" >
					  </div>
					   
					   <div class="form-group col-md-12 ">
					       <label for="exp_month">Expired Month:</label>
					       <select  class="form-control selectpicker" id="exp_monthForm" >
					       	     
								<option value="01">January</option>
								<option value="02">February</option>
								<option value="03">March</option>
								<option value="04">April</option>
								<option value="05">May</option>
								<option value="06">June</option>
								<option value="07">July</option>
								<option value="08">August</option>
								<option value="09">September</option>
								<option value="10">October</option>
								<option value="11">November</option>
								<option value="12">December</option>
						  </select>
					   </div>
					   <div class="form-group col-md-12">
					       <label for="exp_year">Expired Year:</label>
					        <select  class="form-control selectpicker" id="exp_yearForm" >
								  	<option value="">Select Year</option>
								    <?php  for($i=0 ;$i<25 ; $i++){ ?>
								    <option value="<?php echo date("Y")+$i ;?>"><?php echo date("Y")+$i ;?></option>
								  <?php } ?>
						    </select>
					    </div>

					  <div class="form-group col-md-12">
					    <label for="card_type">Card Type:</label>
					    <input required type="text" disabled class="form-control" value="" id="card_typeForm">
					  </div>
					  <?php  
					     if($this->session->status){
				            $charge = $chargeData[1]->charges_ammount ;
				           }else{
				           	$charge = $chargeData[0]->charges_ammount+$chargeData[1]->charges_ammount ;
				           }
				        ?>
					  <div class="form-group col-md-12 ">
					    <label for="carcvv">Pay Amount:</label>
					    <input required type="text" disabled class="form-control"   value="<?php echo 
					    $charge ?>" id="payamount" >
					  </div>
					  
					 
					  <button type="button" id="cardSubmitBtn" class="mb20 form-controlfloat-left btn btn-primary" onclick="cardSubmit()">Submit</button>
					  <span id="pleasewaitimage"></span>
					  
					</form> 
            </div>
            <div class="col-xl-6  col-md-6  col-sm-12  mb20 mt20">
            	<div class="alert alert-info">
            	  <h2>Offline Process</h2>
				  <p>For a offline process you can contact with organization or library members<br>
				  	<span class="hindifontpara">ऑफ़लाइन प्रक्रिया के लिए आप संगठन या पुस्तकालय के सदस्यों से संपर्क कर सकते हैं
				  	</span>
				  </p>
				  <table class="table">
					    <tbody>
					      <tr>
					        <td><b>Name</b></td>
					        <td></td>
					      </tr> 
					      <tr>
					        <td><b>Contact</b></td>
					        <td></td>
					      </tr>
					       <tr>
					        <td><b>Time</b></td>
					        <td></td>
					      </tr>
					    </tbody>
				  </table>
				</div>
				<div class="alert alert-info">
            	  <h2>Other Payments Process</h2>
				  <p>You can also pay of payment by other payments gatway<br>
				  	<span class="hindifontpara">आप दूसरे payments gatway द्वारा भी शुल्क का भुगतान  कर सकते हैं 
				  	</span>
				  	<br>
				  	<span class="" >for more information please click <a href="#" class="text-success">Click</a></span>
				  </p>
				  
				</div>

				<div class="alert alert-info">
            	  <h2>For Other Information</h2>
				  <p>You can also pay of payment by other payments gatway </p>
				   <table class="table">
					    <tbody>
					      <tr>
					        <td><b>Registraion Fee</b></td>
					        <td><?php echo RUPEE.$chargeData[0]->charges_ammount ?></td>
					      </tr> 
					      <tr>
					        <td><b>Monthly Fee</b></td>
					        <td><?php echo RUPEE.$chargeData[1]->charges_ammount ?></td>
					      </tr>
					       <tr>
					        <td><b>Time</b></td>
					        <td></td>
					      </tr>
					    </tbody>
				  </table>
				</div>
            </div>
        </div>
    </div>
  </div>
        <!-- /.container-fluid -->

       <?php include "footersticky.php" ;?>


       <script type="text/javascript">
       	
       	function cardNumber(){
              var ccNum = document.getElementById("cardnumberForm").value;
                var visaRegEx = /^(?:4[0-9]{12}(?:[0-9]{3})?)$/;
                var mastercardRegEx = /^(?:5[1-5][0-9]{14})$/;
                var amexpRegEx = /^(?:3[47][0-9]{13})$/;
                var discovRegEx = /^(?:6(?:011|5[0-9][0-9])[0-9]{12})$/;
                var isValid = false;
                if (visaRegEx.test(ccNum)) {
                     $("#card_typeForm").val("Visa Card");
                  isValid = true;
                } else if(mastercardRegEx.test(ccNum)) {
                     /// alert("master");
                       $("#card_typeForm").val("Master Card");
                  isValid = true;
                } else if(amexpRegEx.test(ccNum)) {
                      $("#card_typeForm").val("Amex Card");
                  isValid = true;
                } else if(discovRegEx.test(ccNum)) {
                      $("#card_typeForm").val("Discov Card");
                  isValid = true;
                }else{
                   $("#card_typeForm").val("Other");
                }
           }

        function cardSubmit(){
        	var  url = '<?php echo base_url('user/stripe_payment')  ?>';
        	var  waitimg = '<?php echo base_url('uploads/ashg/loader.gif') ?>' ;
        	$('#cardSubmitBtn').hide(); 
        	$('#pleasewaitimage').append('<img src="'+waitimg+'" width="40px" height="40px" >')
        	var card_holder_nameForm = $('#card_holder_nameForm').val() ;
        	var cardnumberForm = $('#cardnumberForm').val() ;
        	var exp_monthForm = $('#exp_monthForm').val() ;
        	var exp_yearForm = $('#exp_yearForm').val() ;
        	var payamount = $('#payamount').val() ;
        	var cardcvv = $('#cardcvv').val() ;
        	  alert(card_holder_nameForm+'-'+cardnumberForm+'-'+exp_monthForm+'-'+exp_yearForm+'-'+payamount+'-'+cardcvv);
        	$.ajax({
	           type: "POST",
	           url: url,
	           data: {'cardname':card_holder_nameForm,'cardnumber':cardnumberForm,'exp_month':exp_monthForm,'exp_year':exp_yearForm,'cardcvv':cardcvv,'payamount':payamount}, // serializes the form's elements.
	           success: function(data)
	           {
	           	  alert(data);
				  /*var values = JSON.parse(data);
				  if(values.status){
					  $("#messageBoxDiv").append('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+values.message+'</div>');
				  	alert(values.url);
				  	window.location.replace(values.url);
				  }else{
				  	$("#messageBoxDiv").append('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+values.message+'</div>');
				  }*/
	           }
	        });

        }
       </script>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->
