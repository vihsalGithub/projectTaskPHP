<script src="<?php echo base_url() ; ?>/assets//ckeditor/ckeditor.js" type="text/javascript"></script>
<div id="wrapper">
    <?php $this->load->view('admin/sidebar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
			
          <!-- Breadcrumbs-->
			<?php 
				$this->load->view('admin/exammanu.php'); 
				$this->load->view('onlineexam/oe_pprbtnmanu.php');    

			?>
			
			<div class="container">
				<div class="row">
					<div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Subject</th>
                      <th>TP</th>
                      <th>TM</th>
                      <th>MM</th>
                      <th>TT</th>
					  <th>Status</th>
                      <th>Created Date</th>
					  <th>Action</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>Name</th>
                      <th>Subject</th>
                      <th>TP</th>
                      <th>TM</th>
                      <th>MM</th>
                      <th>TT</th>
					  <th>Status</th>
                      <th>Created Date</th>
                      <th>Action</th>
                    </tr>
                  </tfoot>
                  <tbody>
				  <?php foreach ($OE_PAPERS as $key => $value) { ?>
				  
				     <?php 
							$subjectarray = json_decode($value->sub_id);
							$arr = $this->my_model->getFilterTableWithIn(OE_SUBJECT,'name','id',$subjectarray);
							  foreach($arr as $data){
								$array[] = $data->name;  
							  }
							$subject = implode(',',$array);
					 ?>
                    <tr>
					   <td><?php echo $value->name.'_'.$value->sufix_name ?></td>
					   <td><?php echo $subject; ?></td>
					   <td><?php echo $value->exam_time_period.' '  ?>Hour</td>
					   <td><?php echo $value->total_marks  ?></td>
					   <td><?php echo $value->minmum_marks  ?></td>
					   <td><?php echo $value->total_time.' '  ?>Hour</td>
					   <td><?php  if($value->status){
						      echo '<label>Activate</label>';
								}else{
								 echo '<label>Deactive</label>';	
								}  ?>
					   </td>
					   <td><?php echo $value->created_date  ?></td>
					   <td><a onclick="editcreatedpaper(<?php echo $value->id ; ?>)" href="#">Edit</a></td>
					</tr>
				  <?php } ?>
                 
                  </tbody>
                </table>
              </div>
				</div>
			</div>
		</div>
    </div>
        <!-- Sticky Footer -->
        
		<?php 
			$this->load->view('admin/footer_sticky.php');    
		?>
    </div>
      <!-- /.content-wrapper -->
</div>
<script>
 function editcreatedpaper(id){
	 $("#myModal").modal('show') ;
	 /* $.ajax({
		url:'<?php echo base_url('onlineexam/editpaperlist') ?>',
		type:"post",
		data: {'id':id},
		success:function(data){
			//alert(data);
			//$("#myModal").model();
		}
	 }); */
 }
 
</script>

 <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <p>We Are Work on</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>