<script src="<?php echo base_url() ; ?>/assets//ckeditor/ckeditor.js" type="text/javascript"></script>
<div id="wrapper">
    <?php $this->load->view('admin/sidebar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
			
          <!-- Breadcrumbs-->
			<?php 
				$this->load->view('admin/test-exammanu.php'); 
				//print_r($OE_TEST_QUESTIONS);
			?>
			
			<div class="container">
				<div class="row">
				<?php echo $this->session->flashdata('flashmessage') ;?>
					<div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Sn</th>
                      <th>Paper Name</th>
                      <th>Answer</th>
                      <th>Status</th>
					  <th>Action</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>Sn</th>
                      <th>Paper Name</th>
                      <th>Answer</th>
                      <th>Status</th>
					  <th>Action</th>
                    </tr>
                  </tfoot>
                  <tbody>
				  <?php foreach ($OE_TEST_QUESTIONS as $key => $value) { ?>
					<tr>
					   <td><?php echo $value->question ?></td>
					   <td><?php echo '(1)'.$value->op_1 .' ,(2)'.$value->op_2 .'(3)'.$value->op_3 .' ,(4)'.$value->op_4  ?></td>
					   <td><?php echo $value->ans ?></td>
					   <td><?php if($value->ques_status){ echo 'Active';}else{ echo 'Deactive' ;} ?></td>
					    <td><a  href="<?php echo base_url('onlineexam/testQuesEdit/').$value->id  ?>">Edit</a></td>
					</tr>
				  <?php } ?>
                  </tbody>
                </table>
              </div>
				</div>
			</div>
		</div>
    </div>
        <!-- Sticky Footer -->
        
		<?php 
			$this->load->view('admin/footer_sticky.php');    
		?>
    </div>
      <!-- /.content-wrapper -->
</div>
