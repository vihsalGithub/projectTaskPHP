<script src="<?php echo base_url() ; ?>/assets//ckeditor/ckeditor.js" type="text/javascript"></script>
<div id="wrapper">
    <?php $this->load->view('admin/sidebar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
			
          <!-- Breadcrumbs-->
			<?php 
				$this->load->view('admin/exammanu.php');    
				$this->load->view('onlineexam/oe_pprbtnmanu.php');    
			?>
			<div class="container">
				<div class="row">
				 <h3 class="text-center"><?php echo $selectPprData->name .'_'.$selectPprData->sufix_name?></h3>
				<?php
			  // print_r($selectPprData);
			  // print_r($selectListData);
			?>
				
				</div>
			</div>
			<div class="container">
				<div class="row">
				<form class="form form-horizontal" action="<?php echo site_url('onlineexam/paper_choose_question');?>" method="post" >
                    <div class="form-body">
					<div class="row" >
					<div class="col-md-4">
						<div class="form-group">
						<label class="label-control" for="lname">Total Subject</label>
						<input type="text" class="form-control"  readonly  name="totalSubject" id="totalSubject" value="<?php echo count($selectListData)?>" >
					  </div>
                    </div>
					<div class="col-md-4">
					   <div class="form-group">
						<label class="label-control" for="lname">Total Marks Choose</label>
						<input type="text" class="form-control"  readonly  name="totalMarksChooceQus" id="totalMarksChooceQus" value="0" >
					  </div>
                    </div>
					<div class="col-md-4">
					   <div class="form-group">
						<label class="label-control" for="lname">Total Qusetion Choose</label>
						<input type="text" class="form-control"  readonly  name="totalQusetionChooceQus" id="totalQusetionChooceQus" value="0" >
					  </div>
                    </div>
					</div>
                    <div class="row" id="ques">
						<div class="col-md-12">
						<?php // echo '<pre>';print_r($question['question_7']); ?>
						<table class="table table-bordered" id="dataTable"  cellspacing="0">
							  <thead>
								<tr>
								  <th>SN</th>
								  <th>Subject</th>
								  <th>Questions</th>
								  <th>Answer</th>
								  <th>Marks</th>
								  <th>Action</th>
								</tr>
							  </thead>
							  <tfoot>
								<tr>
								  <th>SN</th>
								  <th>Subject</th>
								  <th>Questions</th>
								  <th>Answer</th>
								  <th>Marks</th>
								  <th>Action</th>
								</tr>
							  </tfoot>
							  <tbody>
							  
						<?php foreach($selectListData as $key=>$subjectData){?>	
								<?php
								$subjectName = $this->db->select('name')->from(OE_SUBJECT)->where(array('id'=>$subjectData->id))->get()->row();
								$sub_id = 'question_'.$subjectData->id ; ?>

							  <?php foreach($question["$sub_id"] as $key=>$value){?>
								<tr   name="qus_row1" id="row_id_<?php echo $sub_id ?>">
									<td><?php echo $key+1 ; ?></td>
									<td><?php 
										echo $subjectName->name;
									?></td>
									<td>
									<?php echo base64_decode($value->Q_en) ?>
									</td>
									<td>
									<?php 
										if($value->Ans == 1){echo base64_decode($value->A_e1) ;}
										elseif($value->Ans == 2){echo base64_decode($value->A_e2) ;}
										elseif($value->Ans == 3){echo base64_decode($value->A_e3) ;}
										else{echo base64_decode($value->A_e4) ;}
									?>
									</td>
									<td>
									<?php echo $value->marks ?>
									</td>
									<td>
										<a href="<?php echo base_url('onlineexam/questionedit/').base64_encode($value->id) ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a>
										<input style="zoom:1.5" type="checkbox" name="selectQus[]" id="selectQus__<?php echo $value->id  ?>" onclick="checkmarks(<?php echo $value->id  ?> ,<?php echo $value->marks  ?>)" value="<?php echo $value->id .'_'.$value->sub_id  .'_'.$value->marks ?>">					
									</td>
								</tr>
							  <?php } ?>
						<?php } ?> 
							
							  </tbody>
							</table>
						</div>
                        <div class="col-md-4">
                          <div class="form-group">
                            <label class="label-control" for="crewcount"></label></br>
                            <input  type="submit" class="btn btn-primary" value="Submit Now" />
                            <input  type="button" onclick="getAllSelectValue()" class="btn btn-primary" value="Submit Now11" />
                          </div>
                        </div>
					</div>
					<input type="hidden" value="<?php echo $selectPprData->id ?>" name="paperID">
					<input type="hidden" value=<?php echo $selectPprData->sub_id  ?> name="subjectId">
                    </div>
                  </form>
				
			</div>
		</div>
    </div>
        <!-- Sticky Footer -->
        
		<?php 
			//$this->load->view('admin/footer_sticky.php');    
		?>
    </div>
      <!-- /.content-wrapper -->
</div>

<script>
	$(document).ready(function() {
		$('#dataTable').DataTable( {
				initComplete: function () {
					this.api().columns(1).every( function () {
						var column = this;
						var select = $('<select><option value=""></option></select>')
							.appendTo( $(column.header()).empty() )
							.on( 'change', function () {
								var val = $.fn.dataTable.util.escapeRegex(
									$(this).val()
								);
								column
									.search( val ? '^'+val+'$' : '', true, false )
									.draw();
							} );
						column.data(1).unique().sort().each( function ( d, j ) {
							select.append( '<option value="'+d+'">'+d+'</option>' )
						} );
					} );
				}
			} );
			
	});
   
    var dataArray = [] ;
   function checkmarks(qid ,qmarks){
	 var marks =   parseInt($('#totalMarksChooceQus').val());
	 var qustion =   parseInt($('#totalQusetionChooceQus').val());
	var search = dataArray.indexOf(qid);
	if(search){
	   	    console.log(dataArray);
	  }else{
		var totalMarks = parseInt(qmarks)+ marks ;
	   $('#totalMarksChooceQus').val(totalMarks) ;
	   var totalQus = qustion+ 1;
	   $('#totalQusetionChooceQus').val(totalQus) ;
		dataArray.push(qid);
	    console.log(dataArray);
	  }
	   
   }
   
   function getAllSelectValue(){
	   
   }
  
</script>