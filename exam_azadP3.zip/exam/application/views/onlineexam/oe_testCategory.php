<div id="wrapper">
    <?php $this->load->view('admin/sidebar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">     
		
          <!-- Breadcrumbs-->
			<?php 
				$this->load->view('admin/test-exammanu.php');    
			?>
				  <!-- DataTables Example -->
			<div class="container">
				<div class="row">	
				<div class="col-md-6 col-sm-12  col-xl-6 ">
				<form class=" form-horizontal border pt20" method="post" enctype="multipart/form-data" id="addCategoryForm" action="#">
                    <h3 id="formTitle">Add Category</h3>
					<div class="col-sm-12 display-none">          
                        <img class=" imgcenter " width="100px" src="http://localhost/lakhanpatel///uploads/users/1534674315.jpg">
                     </div>
					<div class="col-sm-12 display-none">          
                        <input type="file" class="form-control" id="imageUP" value="http://localhost/lakhanpatel//uploads/users/1534674315.jpg" name="imageUP">
                    </div>
                    <div class="form-group">
                      <label class="control-label col-sm-12" for="fatehername">Category Name:</label>
                      <div class="col-sm-12">          
                        <input type="text" class="form-control" id="categoryName" placeholder="Category Name"  name="categoryName">
                        <input type="hidden" id="categoryId" name="categoryId" >
                      </div>
                    </div>
					<div class="form-group">
                      <label class="control-label col-sm-12" for="categoryStatus">Select Status:</label>
                      <div class="col-sm-12">  
						 <select class="form-control" name="categoryStatus" id="categoryStatus">
							<option value="1">Status</option>
							<option value="1">Active</option>
						  </select>
                      </div>
                    </div>

                    <div class="form-group">        
                      <div class="col-sm-offset-2 col-sm-12">
                        <button id="submitUP" class="btn btn-success"   >Submit</button>
                        <button id="updateUP" class="btn btn-success"   >Update</button>
                        <span id="buttonMessageUP"></span>
                      </div>
                    </div>
                  </form>
				</div>
					<div class="col-md-6 col-sm-12  col-xl-6 ">
						<?php //print_r($oe_category) ; ?>
						<div class="table-responsive padding20" id="ajaxCatHtmlx" >
							<table class="table table-bordered" id="dataTable" cellspacing="0">
							  <thead>
								<tr>
								  <th>SN</th>
								  <th>Name</th>
								  <th>Status</th>
								  <th>Action</th>
								</tr>
							  </thead>
							  <tfoot>
								<tr>
								  <th>SN</th>
								  <th>Name</th>
								  <th>Status</th>
								  <th>Action</th>
								</tr>
							  </tfoot>
							  <tbody>

							  	<?php foreach($oe_category as $key => $value) { ?>
							  	  	<tr>
										<td>1</td>
										<td><?php echo $value->name ?></td>
										<td><span class="bg-success text-white">Activate</span></td>
										<td>
										<span onclick="CategoryFun(<?php echo $value->id ?>,'edit')"><i class="fa fa-pencil" aria-hidden="true">Edit</i></span>
										<!-- <span onclick="CategoryFun(6,'delete')"><i class="fa fa-trash" aria-hidden="true"></i></span> -->					
										</td>
									</tr>	
								<?php } ?>		
							  </tbody>
							</table>
						</div>
					</div>
			     </div>
			</div>
	
        </div>
	
	
		<script>
			$(function(){
				$("#updateUP").hide();
			   /* $.ajax({
					type: "post",
					url: '<?php echo base_url("onlineexam/categoryTemp") ?>',
					success: function(responseData) {
						if(responseData){
							//alert(responseData) ;
							$("#ajaxCatHtml").append(responseData);
						}else{
							alert('hello1') ;
						}
					}
				});*/

			});

		   $("#submitUP").click(function(){
				$('form[id="addCategoryForm"]').validate({
					rules: {
						categoryName: 'required',
						categoryStatus: 'required',
					  },
					   errorPlacement: function(){
							return false;   /*suppresses error message text*/
						},
					  submitHandler: function(form) {
						addCategoryFun()
					  }
					});
		   });
		   function addCategoryFun(){
			   var url = '<?php echo base_url("onlineexam/addcategory") ?>'
			   $.ajax({
					type: "post",
					url: url,
					data: $("#addCategoryForm").serialize(),
					success: function(responseData) {
						if(responseData){
							$('#categoryName').val('');
							$('#categoryStatus').val('');
							$("#updateUP").hide();
							$("#submitUP").show();
							$('#formTitle').text('Update Category');
							$("#ajaxCatHtml").text('');
							$("#ajaxCatHtml").append(responseData);
						}else{
							alert('Not added') ;
						}
					}
				});
		   }
		   
		   function CategoryFun(catid,message){
			   
			    if(message == 'edit'){
					var url = '<?php echo base_url("onlineexam/selectcategory") ?>';
						   $.ajax({
								type: "post",
								url: url,
								data: {'catid':catid},
								success: function(responseData) {
									if(responseData){
										//console.log(responseData);
										var obj = JSON.parse(responseData);
										$('#categoryName').val(obj.name);
										$('#categoryStatus').val(obj.status);
										$('#categoryId').val(obj.id);
										$("#updateUP").show();
										$("#submitUP").hide();
										$('#formTitle').text('Edit Category');
									}else{
										alert('not deleted') ;
									}
								}
							});
				}else{
					var confirmMsg = "Are you sure for delete Category!";
					var url = '<?php echo base_url("onlineexam/deletecategory") ?>';
					var r = confirm(confirmMsg);
					if (r == true) {
						   $.ajax({
								type: "post",
								url: url,
								data: {'catid':catid},
								success: function(responseData) {
									if(responseData){
										alert('Category deleted') ;
										$('#categoryName').val('');
										$('#categoryStatus').val('');
										$("#updateUP").hide();
										$("#submitUP").show();
										$('#formTitle').text('Update Category');
										$("#ajaxCatHtml").text('');
										$("#ajaxCatHtml").append(responseData);
									}else{
										alert('not deleted') ;
									}
								}
							});
					}
				}
		   }
		   
		   $("#updateUP").click(function(){
				$('form[id="addCategoryForm"]').validate({
					rules: {
						categoryName: 'required',
						categoryStatus: 'required',
					  },
					   errorPlacement: function(){
							return false;   /*suppresses error message text*/
						},
					  submitHandler: function(form) {
						updatecategory()
					  }
					});
		   });
		   
		   function updatecategory(){
			   var url = '<?php echo base_url("onlineexam/updatecategory") ?>'
			   $.ajax({
					type: "post",
					url: url,
					data: $("#addCategoryForm").serialize(),
					success: function(responseData) {
						if(responseData){
							$('#categoryName').val('');
							$('#categoryStatus').val('');
							$("#updateUP").hide();
							$("#submitUP").show();
							$('#formTitle').text('Add Category');
							$("#ajaxCatHtml").text('');
							$("#ajaxCatHtml").append(responseData);
						}else{
							alert('Not added') ;
						}
					}
				});
		   }
	</script>
        <!-- /.container-fluid -->

        <!-- Sticky Footer .php -->
		
		<?php 
			$this->load->view('admin/footer_sticky.php');    
		?>


    </div>
      <!-- /.content-wrapper -->

</div>
    <!-- /#wrapper -->
