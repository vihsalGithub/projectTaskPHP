<script src="<?php echo base_url() ; ?>/assets//ckeditor/ckeditor.js" type="text/javascript"></script>
<div id="wrapper">
    <?php $this->load->view('admin/sidebar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
			
          <!-- Breadcrumbs-->
			<?php 
				$this->load->view('admin/test-exammanu.php'); 
				//print_r($OE_TEST_PAPERS);
			?>
			
			<div class="container">
				<div class="row">
				<?php echo $this->session->flashdata('flashmessage') ;?>
					<div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Sn</th>
                      <th>Paper Name</th>
                      <th>Category Name</th>
                      <th>Date</th>
                      <th>Total Questions</th>
                      <th>Status</th>
                      <th>Paper Mode</th>
					  <th>Action</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>Sn</th>
                      <th>Paper Name</th>
                      <th>Category Name</th>
                      <th>Date</th>
                      <th>Total Questions</th>
                      <th>Status</th>
                      <th>Paper Mode</th>
					  <th>Action</th>
                    </tr>
                  </tfoot>
                  <tbody>
				  <?php foreach ($OE_TEST_PAPERS as $key => $value) { ?>
				  
                    <tr>
					   <td><?php echo $key+1 ?></td>
					   <td><?php echo $value->ppr_name ?></td>
					   <td><?php 
							$catName =$this->db->select('*')->from('oe_category')->where(array('id'=>$value->ppr_cat))->get()->row();
					    echo $catName->name ;
					  ?></td>
					   <td><?php echo $value->ppr_date ?></td>
					   <td><?php 
							$res =$this->db->select('*')->from('oe_testquestions')->where(array('ppr_id'=>$value->id))->get()->result();
					    echo count($res);
					  ?></td>
					   <td><?php  
					   if($value->status == 1){
						echo  'Active';
					  }elseif($value->status == 2){
						echo  'Pdf Genrate';
					  }else{
						echo  'Deactive';
					  }
					      ?>
					   </td>
					   
					    <td><?php  
							if($value->ppr_mode == 1){
								echo '<span class="text-danger">Private Mode</span>';
							}elseif($value->ppr_mode == 2){
								echo  '<span class="text-info">Created Mode</span>';
							}else{
								echo  '<span class="text-success">Public Mode</span>';
							}
					      ?>
					   </td>
					   <td><a  href="<?php echo base_url('onlineexam/testpapersedit/').$value->id  ?>">Edit</a><br>
					       <a  href="<?php echo base_url('onlineexam/testqueslist/').$value->id  ?>">View</a></td>
					</tr>
				  <?php } ?>
                 
                  </tbody>
                </table>
              </div>
				</div>
			</div>
		</div>
    </div>
        <!-- Sticky Footer -->
        
		<?php 
			$this->load->view('admin/footer_sticky.php');    
		?>
    </div>
      <!-- /.content-wrapper -->
</div>
<script>
 function editcreatedpaper(id){
	 $("#myModal").modal('show') ;
	 /* $.ajax({
		url:'<?php echo base_url('onlineexam/editpaperlist') ?>',
		type:"post",
		data: {'id':id},
		success:function(data){
			//alert(data);
			//$("#myModal").model();
		}
	 }); */
 }
 
</script>

 <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <p>We Are Work on</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>