<script src="<?php echo base_url() ; ?>/assets//ckeditor/ckeditor.js" type="text/javascript"></script>
<div id="wrapper">
    <?php $this->load->view('admin/sidebar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
			
          <!-- Breadcrumbs-->
			<?php 
				$this->load->view('admin/exammanu.php');    
			?>
			<div class="container">
				<a class="btn btn-success" href="<?php echo base_url('onlineexam/addques'); ?>">Add Question</a>
			</div>
		<!--	<link href="<?php echo base_url() ; ?>/assets/textediter/editor.css" rel="stylesheet">
			<script src="<?php echo base_url() ; ?>/assets/textediter/editor.js"></script>-->
				  <!-- DataTables Example -->
			<?php  //echo '<pre>'; print_r($sglQusData->Q_en) ;echo '</pre>'; ?>
			<div class="container">
			<form class="form " action="<?php echo site_url('onlineexam/updateQuestion'); ?>" method="post" >
				<div class="row">	
					<div class="col-md-12">
					  <div class="form-group">
						<label class="label-control" for="lname">Question In English *</label>
						<textarea type="text"  class="form-control border-primary ckeditor" placeholder="Question in English" name="quse" required><?php echo base64_decode($sglQusData->Q_en); ?></textarea> 
					  </div>
                    </div>
					 <div class="col-md-12">
					  <div class="form-group">
						<label class="label-control" for="lname">सवाल हिंदी में*</label>
						<textarea type="text" class="form-control border-primary ckeditor" placeholder="Question in Hindi" id="title" name="qush"  required ><?php echo (base64_decode($sglQusData->Q_hi)) ;?></textarea> 
					  </div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label class="label-control" for="lname">Option 1 In English*</label>
						<input type="text"  class="form-control border-primary" placeholder="Option 1 In English" name="opae" value="<?php echo base64_decode($sglQusData->A_e1); ?>" required>
					  </div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label class="label-control" for="lname">विकल्प 1  हिंदी में*</label>
						<input type="text"  class="form-control border-primary" placeholder="विकल्प 1  हिंदी में" id="title1" name="opah" value="<?php echo (base64_decode($sglQusData->A_h1)) ;?>" required>
					  </div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label class="label-control" for="lname">Option 2 In English*</label>
						<input type="text" class="form-control border-primary" placeholder="Option 2 In English" name="opbe" value="<?php echo base64_decode($sglQusData->A_e2); ?>" required>
					  </div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label class="label-control" for="lname">विकल्प 2  हिंदी में*</label>
						<input type="text"  class="form-control border-primary" placeholder="विकल्प 2  हिंदी में" id="title2" name="opbh" value="<?php echo (base64_decode($sglQusData->A_h2)) ;?>" required>
					  </div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label class="label-control" for="lname">Option 3 In English*</label>
						<input type="text"  class="form-control border-primary" placeholder="Option 3 In English" name="opce" value="<?php echo base64_decode($sglQusData->A_e3); ?>" required >
					  </div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label class="label-control" for="lname">विकल्प 3  हिंदी में*</label>
						<input type="text" class="form-control border-primary" placeholder="विकल्प 3  हिंदी में" id="title3" name="opch"  value="<?php echo (base64_decode($sglQusData->A_h3)) ;?>" required>
					  </div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label class="label-control" for="lname">Option 4 In English*</label>
						<input type="text"   class="form-control border-primary" placeholder="Option 4 In English" name="opde" value="<?php echo base64_decode($sglQusData->A_e4); ?>" required>
					  </div>
					</div>
                        
						<div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">विकल्प 4  हिंदी में*</label>
                            <input type="text"   class="form-control border-primary" placeholder="विकल्प 4  हिंदी में" id="title4" name="opdh" value="<?php echo (base64_decode($sglQusData->A_h4)); ?>" required>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">Option 5 In English*</label>
                            <input type="text"   class="form-control border-primary" placeholder="Option 5 In English" name="opee" value="<?php echo base64_decode($sglQusData->A_e5); ?>" >
                          </div>
                        </div>
                        	<div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">विकल्प 5  हिंदी में*</label>
                            <input type="text"   class="form-control border-primary" placeholder="विकल्प 5 हिंदी में" id="title5" name="opeh" value="<?php echo (base64_decode($sglQusData->A_h5)) ;?>" >
                          </div>
                        </div>
						<div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">Answer *</label>
                            <input type="text"   class="form-control border-primary" placeholder="Answer (IF Multiple 1,2,3)" name="ans" id="extra7" value="<?php echo $sglQusData->Ans ;?>" onkeypress="return isNumber(event)" required>
                          </div>
                        </div>
						<div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">Marks *</label>
                            <input type="text"   class="form-control border-primary" placeholder="Marks" name="mark"  value="<?php echo $sglQusData->marks ;?>" required>
                          </div>
                        </div>
						<div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">Minus Marking *</label>
                            <input type="text"   class="form-control border-primary" placeholder=" Minus Marks" name="minusmrk"  value="<?php echo $sglQusData->minusmark ;?>" required>
                          </div>
                        </div>
						<div class="col-md-12">
                          <div class="form-group">
                            <label class="label-control" for="lname">Solution*</label>
                            <textarea type="text" class="form-control border-primary ckeditor" placeholder="Solution " id="title" name="solu"  required ><?php echo base64_decode($sglQusData->solution); ?></textarea> 
                          </div>
                        </div>
						<input type="hidden" name="qid" value="<?php echo base64_encode($sglQusData->id); ?>" >
						 <div class="col-md-12">
                          <div class="form-group">
                            <label class="label-control" for="crewcount"></label></br>
                            <input  type="submit" class="btn btn-primary" value="Submit Now" />
                          </div>
                        </div>
			     </div>
				</form>
			</div>
        </div>
        <!-- Sticky Footer -->
        
		<?php 
			$this->load->view('admin/footer_sticky.php');    
		?>
    </div>
      <!-- /.content-wrapper -->
</div>
<script>
			$(document).ready(function() {
				$("#txtEditor").Editor();
			});
		</script>
    <!-- /#wrapper -->