<div id="wrapper">
    <?php $this->load->view('admin/sidebar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
          <!-- Breadcrumbs-->
			<?php 
				$this->load->view('admin/exammanu.php');    
			?>
				  <!-- DataTables Example -->
			<div class="container">
				<div class="row">	
					<div class="col-md-8 col-sm-12  col-xl-8 ">
						<div class="table-responsive padding20" id="ajaxCatHtml" >
						</div>
					</div>
					<div class="col-md-4 col-sm-12  col-xl-4 ">
					</div>
			     </div>
			</div>
        </div>
        <!-- Sticky Footer -->
       
		<?php 
			$this->load->view('admin/footer_sticky.php');    
		?>
    </div>
      <!-- /.content-wrapper -->
</div>
    <!-- /#wrapper -->
	<script>
			$(function(){
	
			    $.ajax({
					type: "post",
					url: '<?php echo base_url("onlineexam/questionsTemp") ?>',
					success: function(responseData) {
						if(responseData){
							//alert(responseData) ;
							$("#ajaxCatHtml").append(responseData);
						}else{
							alert('hello1') ;
						}
					}
				});

			});

		   $("#submitUP").click(function(){
				$('form[id="addCategoryForm"]').validate({
					rules: {
						categoryName: 'required',
						categoryStatus: 'required',
					  },
					   errorPlacement: function(){
							return false;   /*suppresses error message text*/
						},
					  submitHandler: function(form) {
						addCategoryFun()
					  }
					});
		   });
		   function addCategoryFun(){
			   var url = '<?php echo base_url("onlineexam/addcategory") ?>'
			   $.ajax({
					type: "post",
					url: url,
					data: $("#addCategoryForm").serialize(),
					success: function(responseData) {
						if(responseData){
							$("#ajaxCatHtml").text('');
							$("#ajaxCatHtml").append(responseData);
						}else{
							alert('Not added') ;
						}
					}
				});
		   }
		   
		   function CategoryFun(catid,message){
			   
			    if(message == 'edit'){
					var url = '<?php echo base_url("onlineexam/selectcategory") ?>';
						   $.ajax({
								type: "post",
								url: url,
								data: {'catid':catid},
								success: function(responseData) {
									if(responseData){
										console.log(responseData);
										var obj = JSON.parse(responseData);
										$('#categoryName').val(obj.name);
										$('#categoryStatus').val(obj.status);
										$('#categoryStatus').val(obj.status);
										$('#submitUP').val('Update');
										$('#formTitle').text('Edit Category');
									}else{
										alert('not deleted') ;
									}
								}
							});
				}else{
					var confirmMsg = "Are you sure for delete Category!";
					var url = '<?php echo base_url("onlineexam/deletecategory") ?>';
					var r = confirm(confirmMsg);
					if (r == true) {
						   $.ajax({
								type: "post",
								url: url,
								data: {'catid':catid},
								success: function(responseData) {
									if(responseData){
										alert('Category deleted') ;
										$("#ajaxCatHtml").text('');
										$("#ajaxCatHtml").append(responseData);
									}else{
										alert('not deleted') ;
									}
								}
							});
					}
				}
		   }
		</script>
        <!-- /.container-fluid -->
