<script src="<?php echo base_url() ; ?>/assets//ckeditor/ckeditor.js" type="text/javascript"></script>
<div id="wrapper">
    <?php $this->load->view('admin/sidebar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
			
          <!-- Breadcrumbs-->
			<?php 
				$this->load->view('admin/test-exammanu.php'); 
				//print_r($OE_TEST_PAPERS);
			?>
			
			<div class="container">
				<div class="row">
				
	<?php 
	  if($testpaperadd == 1){
	?>		
	    <div class="border margin20  padding10 whitebg col-xl-6 col-md-6  col-sm-12">
			<h2>Add Paper</h2> 
			<form class=" form-horizontal" method="post" enctype="multipart/form-data" id="" action="<?php echo base_url('onlineexam/inserttestpapers') ?>">

                    <div class="form-group">
                      <label class="control-label col-sm-12" for="username">Paper Name</label>
                      <div class="col-sm-12">
                        <input type="text"   required="" name="pprname" value="" class="form-control">
                      </div>
                    </div>
					
					<div class="form-group">
                      <label class="control-label col-sm-12" for="username">PDF Url Set</label>
                      <div class="col-sm-12">
                        <input type="text"   required="" name="ppr_url" value="#" class="form-control">
                      </div>
                    </div>
					
                    <div class="form-group">
                      <label class="control-label col-sm-12" for="pprStatus">Paper Status:</label>
                      <div class="col-sm-12">  
						 <select class="form-control" name="pprStatus" id="pprStatus">
							<option value="3">Deactive</option>
						  </select>
                      </div>
                    </div>
					
					<div class="form-group">
                      <label class="control-label col-sm-12" for="pprMode">Paper Mode:</label>
                      <div class="col-sm-12">  
						 <select class="form-control" name="pprMode" id="pprMode">
							<option value="1">Private Mode</option>
						  </select>
                      </div>
                    </div>

                     <div class="form-group">
                      <label class="control-label col-sm-12" for="pprCategory">Paper Category:</label>
                      <div class="col-sm-12">  
						 <select class="form-control" required="" name="pprCategory" id="pprCategory">
								<?php
										echo '<option  value="">Select Paper Category</option>';
									foreach ($ppr_category as $key => $value) {
										echo '<option '.$select.' value="'.$value->id.'">'.$value->name.'</option>';
									}
								?>
						  </select>
                      </div>
                    </div>
                   
                    <div class="form-group">        
                      <div class="col-sm-offset-2 col-sm-12">
                        <button type="submit" class="btn btn-success">Submit</button>
                      </div>
                    </div>
			</form>
		</div> 
    <?php 
	  }else{
	?>		
		<div class="border margin20  padding10 whitebg col-xl-6 col-md-6  col-sm-12">
			<h2>Edit Paper</h2> 
			<form class=" form-horizontal" method="post" enctype="multipart/form-data" id="" action="<?php echo base_url('onlineexam/testpapersupdate') ?>">
                  <input type="hidden" id="pperID" name="pperID" value="<?php echo $editpprdata->id ?>">
                    <?php
						//print_r($editpprdata);
					?>
                    <div class="form-group">
                      <label class="control-label col-sm-12" for="username">Paper Name</label>
                      <div class="col-sm-12">
                        <input type="text" required=""  name="pprname" value="<?php echo $editpprdata->ppr_name ?>" class="form-control">
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-sm-12" for="username">PDF Url Set</label>
                      <div class="col-sm-12">
                        <input type="text"   required="" name="ppr_url" value="<?php echo $editpprdata->ppr_url ?>" class="form-control">
                      </div>
                    </div>
					
					<?php
					  if($editpprdata->status == 1){
						$option = 'Active';
						$optionValue = 1;
					  }elseif($editpprdata->status == 2){
						$option = 'Pdf Genrate';
						$optionValue = 2;
					  }else{
						  $option = 'Deactive';
						$optionValue = 3;
					  }
						
					?>
                    <div class="form-group">
                      <label class="control-label col-sm-12" for="pprStatus">Paper Status:</label>
                      <div class="col-sm-12">  
						 <select class="form-control" name="pprStatus" id="pprStatus">
							<option value="<?php echo $optionValue ?>"><?php echo $option ?></option>
							<option value="1">Active</option>
							<option value="3">Deactive</option>
							<option value="2">Pdf Genrate</option>
						  </select>
                      </div>
                    </div>
					
					<?php
					  if($editpprdata->ppr_mode == 1){
						$option = 'Private Mode';
						$optionValue = 1;
					  }elseif($editpprdata->ppr_mode == 2){
						$option = 'Created Mode';
						$optionValue = 2;
					  }else{
						  $option = 'Public Mode';
						$optionValue = 3;
					  }
						
					?>
                    <div class="form-group">
                      <label class="control-label col-sm-12" for="pprMode">Paper Mode:</label>
                      <div class="col-sm-12">  
						 <select class="form-control" name="pprMode" id="pprMode">
							<option value="<?php echo $optionValue ?>"><?php echo $option ?></option>
							<option value="1">Private Mode</option>
							<option value="2">Created Mode</option>
							<option value="3">Public Mode</option>
						  </select>
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-sm-12" for="pprCategory">Paper Category:</label>
                      <div class="col-sm-12">  
						 <select class="form-control"  required="" name="pprCategory" id="pprCategory">
								<?php
									echo '<option  value="">Select Paper Category</option>';
									foreach ($ppr_category as $key => $value) {
										if($value->id == $editpprdata->ppr_cat){
											$select = 'selected';
										}else{
											$select = '';
										}
										echo '<option '.$select.' value="'.$value->id.'">'.$value->name.'</option>';
									}
								?>
						  </select>
                      </div>
                    </div>

                    <?php //print_r($ppr_category); ?>
                   
                    <div class="form-group">        
                      <div class="col-sm-offset-2 col-sm-12">
                        <button type="submit" class="btn btn-success">Update</button>
                      </div>
                    </div>
			</form>
		</div> 
			  
	  <?php } ?>
			  
			  
			  
			  
				</div>
			</div>
		</div>
    </div>
        <!-- Sticky Footer -->
        
		<?php 
			$this->load->view('admin/footer_sticky.php');    
		?>
    </div>
      <!-- /.content-wrapper -->
</div>