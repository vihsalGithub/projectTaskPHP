<div class="container">
	<div class="row">
	  <a href="<?php echo base_url('onlineexam/papers') ?>" class="mb20 btn btn-info">Papers</a>
	  <a href="<?php echo base_url('onlineexam/newpaper') ?>" style="margin-left:10px;" class="mb20 btn btn-info">Add Paper</a>
	  
	  <span style="margin-left:10px;" class="mb20 btn btn-info" onclick="Question()">Add Question</span>
	</div>
</div>

<script>
 function Question(){
	 $.ajax({
		url:'<?php echo base_url('onlineexam/select_ppr_for_ques') ?>',
		type:"get",
		success:function(data){
			//alert(data);
			$("#selectManu").text('');
			$("#selectManu").append(data);
			$("#selectSubModel").modal('show') ;
		}
	 });
	 
	 
 }
 
 function papersave(){
	 
	var selectpaper = $( "#selectSub option:selected" ).val();
	  if(selectpaper == ''){
		  $("#msgSelect").text('');
		  $("#msgSelect").append('<span style="color:red">Please Select Paper</span>');
	  }else{
		  //alert("<?php echo base_url('onlineexam/createpaper/')  ?>"+selectpaper);
		  location.href = "<?php echo base_url('onlineexam/createpaper/')  ?>"+selectpaper ;
	  }
 }
</script>

<!-- <a  type="button"  class="btn btn-primary" href="<?php //echo base_url('onlineexam/createpaper') ?>" style="margin-left:10px;" class="mb20 btn btn-info">Save</a>
-->

<!-- Modal -->
  <div class="modal fade" id="selectSubModel" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <p id="selectManu"></p>
          <p id="msgSelect"></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" onclick="papersave()">Save</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>