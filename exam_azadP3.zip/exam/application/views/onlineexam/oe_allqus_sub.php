<div id="wrapper">
    <?php $this->load->view('admin/sidebar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
          <!-- Breadcrumbs-->
			<?php 
				$this->load->view('admin/exammanu.php');    
			?>
				  <!-- DataTables Example -->
			<?php  //echo '<pre>'; print_r($quesWithSub[0]) ;echo '</pre>'; ?>
			<div class="container">
				<div class="row">	
					<div class="col-md-12 col-sm-12  col-xl-12 ">
						<div class="table-responsive padding20" id="" >
							<table class="table table-bordered" id="dataTable"  cellspacing="0">
							  <thead>
								<tr>
								  <th>SN</th>
								  <th>Questions</th>
								  <th>Action</th>
								</tr>
							  </thead>
							  <tfoot>
								<tr>
								  <th>SN</th>
								  <th>Questions</th>
								  <th>Action</th>
								</tr>
							  </tfoot>
							  <tbody>
							  <?php foreach ($quesWithSub as $key => $value) { ?>
								<tr>
									<td><?php echo $key+1 ; ?></td>
									<td>
										<?php $space = '&nbsp;&nbsp;&nbsp;'; ?>
										<?php echo base64_decode($value->Q_en) ?><br>
										<?php echo '<b>(1)</b>'.SPACE_FOUR.''.base64_decode($value->A_e1).SPACE_EIGHT.'<b>(2)</b>'.SPACE_FOUR.''.base64_decode($value->A_e2) ?><br>
										<?php echo '<b>(3)</b>'.SPACE_FOUR.''.base64_decode($value->A_e1).SPACE_EIGHT.'<b>(4)</b>'.SPACE_FOUR.''.base64_decode($value->A_e2) ?>
									</td>
									<td>
										<a href="<?php echo base_url('onlineexam/questionedit/').base64_encode($value->id) ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a>
										<a href="#"><i class="fa fa-trash" aria-hidden="true"></i></a>					
									</td>
								</tr>
							  <?php } ?>
							  </tbody>
							</table>
						</div>
					</div>
			     </div>
			</div>
        </div>
        <!-- Sticky Footer -->
		
		<?php 
			$this->load->view('admin/footer_sticky.php');    
		?>
    </div>
      <!-- /.content-wrapper -->
</div>
    <!-- /#wrapper -->