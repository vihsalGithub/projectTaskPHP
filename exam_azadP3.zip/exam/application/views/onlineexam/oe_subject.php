<div id="wrapper">
    <?php $this->load->view('admin/sidebar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
		
          <!-- Breadcrumbs-->
			<?php 
				$this->load->view('admin/exammanu.php');    
			?>
				  <!-- DataTables Example -->
			<div class="container">
				
				<div class="row">	
				<div class="col-md-6 col-sm-12  col-xl-6 ">
				<form class=" form-horizontal border pt20" method="post" enctype="multipart/form-data" id="addCategoryForm" action="#">
                    <?php echo $this->session->flashdata('oe_message');  ?>
					<div id="show_message"></div>
					<h3 id="formTitle">Add Subjects</h3>
					<div class="col-sm-12 display-none">          
                        <img class=" imgcenter " width="100px" src="http://localhost/lakhanpatel///uploads/users/1534674315.jpg">
                     </div>
					<div class="col-sm-12 display-none">          
                        <input type="file" class="form-control" id="imageUP" value="http://localhost/lakhanpatel//uploads/users/1534674315.jpg" name="imageUP">
                    </div>
                    <div class="form-group">
                      <label class="control-label col-sm-12" for="fatehername">Subjects Name:</label>
                      <div class="col-sm-12">          
                        <input type="text" class="form-control" id="categoryName" placeholder="Subjects Name"  name="categoryName">
                        <input type="hidden" id="categoryId" name="categoryId" >
                      </div>
                    </div>
					<div class="form-group">
                      <label class="control-label col-sm-12" for="categoryStatus">Select Status:</label>
                      <div class="col-sm-12">  
						 <select class="form-control" name="categoryStatus" id="categoryStatus">
							<option value="1">Status</option>
							<option value="1">Active</option>
							<option value="0">Deactive</option>
						  </select>
                      </div>
                    </div>

                    <div class="form-group">        
                      <div class="col-sm-offset-2 col-sm-12">
                        <button id="submitUP" class="btn btn-success"   >Submit</button>
                        <button id="updateUP" class="btn btn-success"   >Update</button>
                        <span id="buttonMessageUP"></span>
                      </div>
                    </div>
                  </form>
				</div>
					<div class="col-md-6 col-sm-12  col-xl-6 ">
						<div class="table-responsive padding20" id="ajaxCatHtml" >
						</div>
					</div>
			     </div>
			</div>
	
        </div>
	
	
		<script>
			$(function(){
				$("#updateUP").hide();
			    $.ajax({
					type: "post",
					url: '<?php echo base_url("onlineexam/subjectTemp") ?>',
					success: function(responseData) {
						if(responseData){
							//alert(responseData) ;
							$("#ajaxCatHtml").append(responseData);
						}else{
							alert('hello1') ;
						}
					}
				});

			});

		   $("#submitUP").click(function(){
				$('form[id="addCategoryForm"]').validate({
					rules: {
						categoryName: 'required',
						categoryStatus: 'required',
					  },
					   errorPlacement: function(){
							return false;   /*suppresses error message text*/
						},
					  submitHandler: function(form) {
						addSubFun()
					  }
					});
		   });
		   function addSubFun(){
			   var url = '<?php echo base_url("onlineexam/addsubject") ?>'
			   $.ajax({
					type: "post",
					url: url,
					data: $("#addCategoryForm").serialize(),
					success: function(responseData) {
						if(responseData){
							alert('Added') ;
							$('#categoryName').val('');
							$('#categoryStatus').val('');
							$("#updateUP").hide();
							$("#submitUP").show();
							$('#formTitle').text('Update Category');
							$("#ajaxCatHtml").text('');
							$("#ajaxCatHtml").append(responseData);
						}else{
							alert('Not added') ;
						}
					}
				});
		   }
		   
		   function subjectFun(catid,message){
			    if(message == 'edit'){
					var url = '<?php echo base_url("onlineexam/selectsubject") ?>';
						   $.ajax({
								type: "post",
								url: url,
								data: {'catid':catid},
								success: function(responseData) {
									if(responseData){
										console.log(responseData);
										var obj = JSON.parse(responseData);
										$('#categoryName').val(obj.name);
										$('#categoryStatus').val(obj.status);
										$('#categoryId').val(obj.id);
										$("#updateUP").show();
										$("#submitUP").hide();
										$('#formTitle').text('Edit Category');
									}else{
										alert('not deleted') ;
									}
								}
							});
				}else{
					var confirmMsg = "Are you sure for delete Subject!";
					var url = '<?php echo base_url("onlineexam/deletesubject") ?>';
					var r = confirm(confirmMsg);
					if (r == true) {
						   $.ajax({
								type: "post",
								url: url,
								data: {'catid':catid},
								success: function(responseData) {
									if(responseData){
										var obj = jQuery.parseJSON( responseData );
										if( obj.status === "exist" ){
											//alert();
											$("#show_message").text();
											$("#show_message").append(obj.oe_message);
											
										}else{
											alert('Subject deleted') ;
											$('#categoryName').val('');
											$('#categoryStatus').val('');
											$("#updateUP").hide();
											$("#submitUP").show();
											$('#formTitle').text('Update Subject');
											$("#ajaxCatHtml").text('');
											$("#ajaxCatHtml").append(obj.body);
										}
										
									}else{
										alert('not deleted') ;
									}
								}
							});
					}
				}
		   }
		   
		   $("#updateUP").click(function(){
			    alert();
				$('form[id="addCategoryForm"]').validate({
					rules: {
						categoryName: 'required',
						categoryStatus: 'required',
					  },
					   errorPlacement: function(){
							return false;  
						},
					  submitHandler: function(form) {
						  //updatesubject()
						  var url1 = '<?php echo base_url("onlineexam/updatesubject") ?>';
						   $.ajax({
								type: "post",
								url: url1,
								data: $("#addCategoryForm").serialize(),
								success: function(responseData) {
									if(responseData){
										$('#categoryName').val('');
										$('#categoryStatus').val('');
										$("#updateUP").hide();
										$("#submitUP").show();
										$('#formTitle').text('Add Subject');
										$("#ajaxCatHtml").text('');
										$("#ajaxCatHtml").append(responseData);
									}else{
										alert('Not added') ;
									}
								}
							});
					  }
					});  
		   });
		   
		   function updatesubject(){
			   alert();
			 
		   }
		</script>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
       
		<?php 
			$this->load->view('admin/footer_sticky.php');    
		?>

    </div>
      <!-- /.content-wrapper -->

</div>
    <!-- /#wrapper -->
