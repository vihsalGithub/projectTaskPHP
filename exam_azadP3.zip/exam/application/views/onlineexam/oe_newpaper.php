<script src="<?php echo base_url() ; ?>/assets//ckeditor/ckeditor.js" type="text/javascript"></script>
<div id="wrapper">
    <?php $this->load->view('admin/sidebar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
			
          <!-- Breadcrumbs-->
			<?php 
				$this->load->view('admin/exammanu.php');    
				$this->load->view('onlineexam/oe_pprbtnmanu.php');    
			?>
			
			<div class="container">
				<div class="row">
				<form class="form " action="<?php echo site_url('onlineexam/addpapers');?>" method="post" >
					 <div class="form-body">
					 <div class="row" >
				<?php 
					echo validation_errors(); 
					echo $this->session->flashdata('show_message1');	
					?>
					
						<div class="col-md-6">
						  <div class="form-group">
							<label class="label-control form-label" for="pprName" >Paper Name *</label>
							<input type="text" required class="form-control" name="pprName"  id="pprName">
						  </div>
						</div>
						<div class="col-md-6">
						  <div class="form-group">
							<label class="label-control form-label" for="lname" id="passg">Paper Suffix *</label>
							<input type="text" required class="form-control" value="<?php  echo date("j_F_Y"); ?>" name="pprSufx"  id="pprSufx">
						  </div>
						</div>
						<div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control form-label" for="lname">Paper Type *</label>
                            <select class="form-control" name="pprCat"  class="mn-input"  required>
                            <option value="" >Select Paper Category</option>
							<?php if(!empty($OE_CATEGORY)){
								foreach($OE_CATEGORY as $st){ ?>
									<option value="<?php echo $st->id;?>"><?php echo $st->name; ?></option>
					         	<?php }} ?>
							</select>
                          </div>
						</div>
						<div class="col-md-12">
						 <div class="form-group">
                            <label class="label-control form-label" for="lname">Chack Subjects *</label>
							<div class="row">
							<?php if(!empty($OE_SUBJECT)){
							foreach($OE_SUBJECT as $st){ ?>
									<div class="col-md-3">
									<label  class="checkbox-inline">
									<input style="zoom:1.5"  type="checkbox" name="chackSub[]" value="<?php echo $st->id;?>">
									<?php echo $st->name; ?></label>
									</div>
					         <?php }} ?>
							</div>
						  </div>
						</div>
						<div class="col-md-6">
						  <div class="form-group">
							<label class="label-control form-label" for="ttlmarks" id="ttlmarkslabel">Paper Total Marks *</label>
							<input type="number" min="1"  required class="form-control" value="1" name="ttlmarks"  id="ttlmarks">
						  </div>
						</div>
						
						<div class="col-md-6">
						  <div class="form-group">
							<label class="label-control form-label" for="ttlmarks" id="">Paper Minimum Marks *</label>
							<input type="number" min="1" required  class="form-control" value="1" name="minMarks"  id="minMarks">
						  </div>
						</div>
						
						<div class="col-md-6">
						  <div class="form-group">
							<label class="label-control form-label" for="ttlmarks" id="">Paper Maximum Marks *</label>
							<input type="number" min="1"  required class="form-control" value="" name="ttlmarks"  id="ttlmarks">
						  </div>
						</div>
						
						<div class="col-md-6">
						  <div class="form-group">
							<label class="label-control form-label" for="ttlTime" id="ttlTimelabel">Paper Total Time *</label>
								<select class="form-control" name="ttlTime" id="ttlTime" required="">
									<option value="1">1 Hour</option>
									<option value="1.5">1.5 Hour</option>
									<option value="2">2 Hour</option>
									<option value="2.5">2.5 Hour</option>
									<option value="3">3 Hour</option>
									<option value="3.5">3.5 Hour</option>
								</select>
						  </div>
						</div>
						<div class="col-md-4">
                          <div class="form-group">
                            <label class="label-control" for="crewcount"></label></br>
                            <input  type="submit" class="btn btn-primary" value="Submit Now" />
                          </div>
                        </div>
                    </div>
				</div>
				</form>
				</div>
			</div>
		</div>
    </div>
        <!-- Sticky Footer -->
        
		<?php 
			$this->load->view('admin/footer_sticky.php');    
		?>
    </div>
      <!-- /.content-wrapper -->
</div>