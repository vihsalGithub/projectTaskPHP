<script src="<?php echo base_url() ; ?>/assets//ckeditor/ckeditor.js" type="text/javascript"></script>
<div id="wrapper">
    <?php $this->load->view('admin/sidebar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
          <!-- Breadcrumbs-->
			<?php 
				$this->load->view('admin/exammanu.php');    
			?>
		<!--	<link href="<?php echo base_url() ; ?>/assets/textediter/editor.css" rel="stylesheet">
			<script src="<?php echo base_url() ; ?>/assets/textediter/editor.js"></script>-->
				  <!-- DataTables Example -->
			<?php  //echo '<pre>'; print_r($sglQusData->Q_en) ;echo '</pre>'; ?>
			<div class="container">
				<div class="row">	
				<?php
				
				echo	$this->session->flashdata('show_message');;
					//print_r($subjData);
				?>
				
				<form class="form form-horizontal" action="<?php echo site_url('onlineexam/addNewQuestion');?>" method="post" >
                    <div class="form-body">
					<div class="row" >
					<div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">Subjects *</label>
                            <select name="subject"  class="mn-input"  required>
                            <option value="" >Select Subject</option>
							<?php if(!empty($subjData)){
								foreach($subjData as $st){ ?>
									<option value="<?php echo $st->id;?>"><?php echo $st->name; ?></option>
					         	<?php }} ?>
							</select>
                          </div>
                    </div>
					<div class="col-md-6">
					  <div class="form-group">
						<label class="label-control" for="lname" id="passg">Select Passage *</label>
					  </div>
					</div>
					<div class="col-md-12">
					  <div class="form-group">
					  <input type="hidden" name="multich" value="1">
					  </div>
					</div>
					</div>
                    <div class="row" id="ques">
                        <div class="col-md-12">
                          <div class="form-group">
                            <label class="label-control" for="lname">Question In English *</label>
                            <textarea  class="form-control ckeditor" placeholder="Question in English" name="quse" required></textarea>
                          </div>
                        </div>
						 <div class="col-md-12">
                          <div class="form-group">
                            <label class="label-control" for="lname">सवाल हिंदी में*</label>
                            <textarea  class="form-control ckeditor" placeholder="Question in Hindi" id="title" name="qush" required ></textarea>
                          </div>
                        </div>
						<div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">Option 1 In English*</label>
                            <input type="text"  class="form-control border-primary" placeholder="Option 1 In English" name="opae" required>
                          </div>
                        </div>
						<div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">विकल्प 1  हिंदी में*</label>
                            <input type="text"  class="form-control border-primary" placeholder="विकल्प 1  हिंदी में" id="title1" name="opah" required>
                          </div>
                        </div>
						<div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">Option 2 In English*</label>
                            <input type="text" class="form-control border-primary" placeholder="Option 2 In English" name="opbe" required>
                          </div>
                        </div>
						<div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">विकल्प 2  हिंदी में*</label>
                            <input type="text"  class="form-control border-primary" placeholder="विकल्प 2  हिंदी में" id="title2" name="opbh" required>
                          </div>
                        </div>
						<div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">Option 3 In English*</label>
                            <input type="text"  class="form-control border-primary" placeholder="Option 3 In English" name="opce" required >
                          </div>
                        </div>
						<div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">विकल्प 3  हिंदी में*</label>
                            <input type="text" class="form-control border-primary" placeholder="विकल्प 3  हिंदी में" id="title3" name="opch"  required>
                          </div>
                        </div>
						<div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">Option 4 In English*</label>
                            <input type="text"   class="form-control border-primary" placeholder="Option 4 In English" name="opde" required>
                          </div>
                        </div>
						<div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">विकल्प 4  हिंदी में*</label>
                            <input type="text"   class="form-control border-primary" placeholder="विकल्प 4  हिंदी में" id="title4" name="opdh" required>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">Option 5 In English*</label>
                            <input type="text"   class="form-control border-primary" placeholder="Option 5 In English" name="opee" >
                          </div>
                        </div>
						<div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">विकल्प 5  हिंदी में*</label>
                            <input type="text"   class="form-control border-primary" placeholder="विकल्प 5  हिंदी में" id="title5" name="opeh" >
                          </div>
                        </div>
						<div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">Answer *</label>
                            <input type="text"   class="form-control border-primary" placeholder="Answer (IF Multiple 1,2,3)" name="ans" id="extra7" onkeypress="return isNumber(event)" required>
                          </div>
                        </div>
						<div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">Minus Marking</label>
                            <input type="text"   class="form-control border-primary" placeholder="Minus Mark" name="minusmrk" value="0" >
                          </div>
                        </div>
						<div class="col-md-6">
                          <div class="form-group">
                            <label class="label-control" for="lname">Marks</label>
                            <input type="text"   class="form-control border-primary" placeholder="marks" value="1" name="mark">
                          </div>
                        </div>
						<div class="col-md-12">
                          <div class="form-group">
                            <label class="label-control " for="lname">Solution</label>
                            <textarea  class="form-control border-primary ckeditor" placeholder="Answer" name="solu"></textarea>
                          </div>
                        </div>
							
                        <div class="col-md-4">
                          <div class="form-group">
                            <label class="label-control" for="crewcount"></label></br>
                            <input  type="submit" class="btn btn-primary" value="Submit Now" />
                          </div>
                        </div>
					</div>
						
                    </div>
                  </form>
			     </div>
			</div>
        </div>
        <!-- Sticky Footer -->
        
		<?php 
			$this->load->view('admin/footer_sticky.php');    
		?>
    </div>
      <!-- /.content-wrapper -->
</div>
<script>
			$(document).ready(function() {
				$("#txtEditor").Editor();
			});
</script>

<!--******************************-->
<script type="text/javascript" src="http://www.google.com/jsapi"></script>
<link href="http://www.google.com/uds/modules/elements/transliteration/api.css"
     type="text/css" rel="stylesheet"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>


google.load("elements", "1", {
           packages: "transliteration"
         });
function OnLoad() {  
 var options = {
      sourceLanguage:
      google.elements.transliteration.LanguageCode.ENGLISH,
      destinationLanguage:
      [google.elements.transliteration.LanguageCode.HINDI],
      shortcutKey: 'ctrl+g',
      transliterationEnabled: true
};

  
  var control = new google.elements.transliteration.TransliterationControl(options);
  control.makeTransliteratable(["title"]);
  control.makeTransliteratable(["title1"]);
  control.makeTransliteratable(["title2"]);
  control.makeTransliteratable(["title3"]);
  control.makeTransliteratable(["title4"]);
  //var control = new google.elements.transliteration.TransliterationControl(options);
  //control.makeTransliteratable(["subject"]);
} 

google.setOnLoadCallback(OnLoad);

function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 43 || charCode > 57 || (charCode > 44 && charCode < 48))) {
        return false;
    }
    return true;
}
</script>
    <!-- /#wrapper -->