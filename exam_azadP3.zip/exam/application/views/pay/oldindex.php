<?php

if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') == 0){
	//Request hash
	$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';	
	if(strcasecmp($contentType, 'application/json') == 0){
		$data = json_decode(file_get_contents('php://input'));
		$hash=hash('sha512', $data->key.'|'.$data->txnid.'|'.$data->amount.'|'.$data->pinfo.'|'.$data->fname.'|'.$data->email.'|||||'.$data->udf5.'||||||'.$data->salt);
		$json=array();
		$json['success'] = $hash;
    	echo json_encode($json);
	
	}
	exit(0);
}
 
function getCallbackUrl()
{
	  //print_r($_SERVER); die;
	$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
	return base_url('exam/payuresponce');
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PayUmoney BOLT PHP7 Kit</title>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

<!-- this meta viewport is required for BOLT //-->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" >
<!-- BOLT Sandbox/test //-->
<script id="bolt" src="https://sboxcheckout-static.citruspay.com/bolt/run/bolt.min.js" 
bolt-color="e34524" bolt-logo="http://boltiswatching.com/wp-content/uploads/2015/09/Bolt-Logo-e14421724859591.png"></script>
<!-- BOLT Production/Live //-->
<!--// script id="bolt" src="https://checkout-static.citruspay.com/bolt/run/bolt.min.js" bolt-color="e34524" bolt-logo="http://boltiswatching.com/wp-content/uploads/2015/09/Bolt-Logo-e14421724859591.png"></script //-->
<link rel="stylesheet" href="<?php echo base_url('assets/home/') ?>css/bootstrap.min.css">


</head>
<style type="text/css">
	.main {
		margin-left:30px;
		font-family:Verdana, Geneva, sans-serif, serif;
	}
	.text {
		float:left;
		width:180px;
	}
	.dv {
		margin-bottom:5px;
	}
	#questContainer{
	    width: 500px;
    margin: 0px auto;
    margin-top: 10%;
    padding: 32px;
    background-color: #fff;
    box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
    color: black;
	}
</style>
<body>

		<div class="container">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12 mt-12 mt-lg-0">
                	<div class="container">
                		<div class="cause-wrap d-flex flex-wrap justify-content-between" id="questContainer">
					<div class="main">
						<div style="padding-bottom: 20px;">
					    	<img src="<?php echo base_url('assets/pay') ?>/payumoney.png" />
					    </div>
					   
					<form action="#" id="payment_form">

						<div class="form-group">
						   <input type="hidden" id="udf5" name="udf5" value="BOLT_KIT_PHP7" />
						    <input type="hidden" id="surl" name="surl" value="<?php echo getCallbackUrl(); ?>" />
						   <input type="hidden" id="key" name="key" placeholder="Merchant Key" value="ax1BQLLp" />
						  <input type="hidden" id="salt" name="salt" placeholder="Merchant Salt" value="t21qaYDpoH" />
						   <input type="hidden" id="txnid" name="txnid" placeholder="Transaction ID" value="<?php echo  "Txn" . rand(10000,99999999)?>" />
						   <span class="text"><label>Amount (in INR):</label></span>
						   <input type="text" readonly="" class="form-control"  id="amount" name="amount" placeholder="Amount" value="20.00" />
					    </div>
					    
					    <div class="form-group">
					    <!-- <span class="text"><label>Product Info:</label></span> -->
					    <input type="text" class="form-control" id="pinfo" name="pinfo" placeholder="Product Info" value="1" />
					    	<!-- <select class="form-control" id="sel1">
							    <option>1 Month Package()</option>
							    <option>1 Month Package(3 Month)</option>
							    <option>1 Month Package(6 Month)</option>
							  </select> -->
					    </div>
					    
					    <div class="form-group">
					    <span class="text"><label>First Name:</label></span>
					    <input type="text"   id="fname" class="form-control" name="fname" placeholder="First Name" value="<?= $name ?>" />
					    </div>
					    
					    <div class="form-group">
					    <span class="text"><label>Email ID:</label></span>
					    <input type="text"   id="email" class="form-control" name="email" placeholder="Email ID" value="<?= $email ?>" />
					    </div>
					    
					    <div class="form-group">
					    <span class="text"><label>Mobile/Cell Number:</label></span>
					    <input type="text"   id="mobile" class="form-control" name="mobile" placeholder="Mobile/Cell Number" value="<?= $contact_no ?>" />
					    </div>
					    
					    <div class="form-group">
					    <input type="hidden" id="hash" class="form-control"  name="hash" placeholder="Hash" value="" />
					    </div>
					    
					    <div><input type="submit" class="btn btn-success" value="Pay" onclick="launchBOLT(); return false;" /></div>
					</form>
					</div>
						</div>
					</div>
				</div>
			</div>
		</div>



<script type="text/javascript"><!--
$('#payment_form').bind('keyup blur', function(){
	$.ajax({
          url: '<?php echo base_url('exam/paymentprocess/') ?>',
          type: 'post',
          data: JSON.stringify({ 
            key: $('#key').val(),
			salt: $('#salt').val(),
			txnid: $('#txnid').val(),
			amount: $('#amount').val(),
		    pinfo: $('#pinfo').val(),
            fname: $('#fname').val(),
			email: $('#email').val(),
			mobile: $('#mobile').val(),
			udf5: $('#udf5').val()
          }),
		  contentType: "application/json",
          dataType: 'json',
          success: function(json) {
            if (json['error']) {
			 $('#alertinfo').html('<i class="fa fa-info-circle"></i>'+json['error']);
            }
			else if (json['success']) {	
				$('#hash').val(json['success']);
            }
          }
        }); 
});
//-->
</script>
<script type="text/javascript"><!--
function launchBOLT()
{
	bolt.launch({
	key: $('#key').val(),
	txnid: $('#txnid').val(), 
	hash: $('#hash').val(),
	amount: $('#amount').val(),
	firstname: $('#fname').val(),
	email: $('#email').val(),
	phone: $('#mobile').val(),
	productinfo: $('#pinfo').val(),
	udf5: $('#udf5').val(),
	surl : $('#surl').val(),
	furl: $('#surl').val(),
	mode: 'dropout'	
},{ responseHandler: function(BOLT){
	console.log( BOLT.response.txnStatus );		
	if(BOLT.response.txnStatus != 'CANCEL')
	{
		//Salt is passd here for demo purpose only. For practical use keep salt at server side only.
		var fr = '<form action=\"'+$('#surl').val()+'\" method=\"post\">' +
		'<input type=\"hidden\" name=\"key\" value=\"'+BOLT.response.key+'\" />' +
		'<input type=\"hidden\" name=\"salt\" value=\"'+$('#salt').val()+'\" />' +
		'<input type=\"hidden\" name=\"txnid\" value=\"'+BOLT.response.txnid+'\" />' +
		'<input type=\"hidden\" name=\"amount\" value=\"'+BOLT.response.amount+'\" />' +
		'<input type=\"hidden\" name=\"productinfo\" value=\"'+BOLT.response.productinfo+'\" />' +
		'<input type=\"hidden\" name=\"firstname\" value=\"'+BOLT.response.firstname+'\" />' +
		'<input type=\"hidden\" name=\"email\" value=\"'+BOLT.response.email+'\" />' +
		'<input type=\"hidden\" name=\"udf5\" value=\"'+BOLT.response.udf5+'\" />' +
		'<input type=\"hidden\" name=\"mihpayid\" value=\"'+BOLT.response.mihpayid+'\" />' +
		'<input type=\"hidden\" name=\"status\" value=\"'+BOLT.response.status+'\" />' +
		'<input type=\"hidden\" name=\"hash\" value=\"'+BOLT.response.hash+'\" />' +
		'</form>';
		var form = jQuery(fr);
		jQuery('body').append(form);								
		form.submit();
	}
},
	catchException: function(BOLT){
 		alert( BOLT.message );
	}
});
}
//--
</script>	
</body>
</html>
	
