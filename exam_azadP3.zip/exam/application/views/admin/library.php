
    <div id="wrapper">
     <?php include "sidebar.php" ;?>
      <div id="content-wrapper">
        <div class="container-fluid">
          <div class="alert alert-danger alert-dismissible fade in"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <?php echo $this->session->flashdata('resMessage') ?>
              </div>
          <!-- DataTables Example -->
          <div class="card mb-3">

            <div class="card-header"> 
              <i class="fas fa-table"></i>
              Students Information</div>
            <div class="card-body">
              <div><button class="btn btn-info" style="margin-bottom: 10px;"><a style="color: #fff;" href="<?php echo base_url('admin/addusers') ?>">Add Users</a></button></div>
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>SN.</th>
                      <th>Image</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Contact</th>
                      <th>Qualification</th>
                      <th>Status</th>
                      <th>Details</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>SN</th>
                      <th>Image</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Contact</th>
                      <th>Qualification</th>
                      <th>Status</th>
                      <th>Details</th>
                      <th>Action</th>
                    </tr>
                  </tfoot>
                  <tbody>
          <?php foreach ($userData as $key => $value) { ?>
                    <tr>
            <td><?php echo $key + 1 ?></td>
            <td><img width="30px" height="30px" src="<?php 
              if($value->image){
                echo base_url().'/'.$value->image ;
              }else{
                echo base_url().'/'.LOGOURL ;
              }
              ?>"/></td>
                      <td><?php echo $value->first_name .' '.$value->last_name  ?></td>
                      <td><?php echo $value->email  ?></td>
            <td><?php echo $value->contact_no  ?></td>
            <td><?php echo $value->qualifiaction  ?></td>
            <td><?php if($value->status){ echo '<span class="text-success">Active</span>';}else{echo '<span class="text-danger">Deactive</span>';} ?></td>
            <td><button class="btn btn-info"style="margin-bottom: 5px;"><a style="color: #fff;" href="<?php echo base_url('admin/userdetails').'/'.base64_encode($value->user_id) ?>">View</a></button>
                <button class="btn btn-info"style="margin-bottom: 5px;"><a style="color: #fff;" href="<?php echo base_url().'admin/user_fees/'.$value->user_id ?>">View Fees</a></button>
            </td>
            <td><button class="btn btn-info"style="margin-bottom: 5px;"><a style="color: #fff;" href="<?php echo base_url().'admin/updateusers/'.$value->user_id ?>">Edit</a></button>&nbsp; <button class="btn btn-info"style="margin-bottom: 5px;"><a style="color: #fff;" href="<?php echo base_url().'admin/deleteusers/'.$value->user_id ?>">Delete</a></button>&nbsp; <button class="btn btn-info"style="margin-bottom: 5px;"><a style="color: #fff;" href="<?php echo base_url().'admin/addfees/'.$value->user_id ?>">Add Fees</a></button>
            </td>

                    </tr>
          <?php } ?>
                      
                  </tbody>
                </table>
              </div>
            </div>
          </div>
      
       <!-- Area Chart Example-->
          <div class="card mb-3 display-none">
            <div class="card-header">
              <i class="fas fa-chart-area"></i>
              Area Chart Example</div>
            <div class="card-body">
              <canvas id="myAreaChart" width="100%" height="30"></canvas>
            </div>
            <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
          </div>
        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->
<!-- <script type="text/javascript">
  function userDelete(user_id){
      var r = confirm("Press a button OK For Delete from list");
          if (r == true) {
               $.ajax({
                type: "POST",
                url: "<?php //echo base_url('admin/deleteusers') ?>"+'/'+user_id,
                success: function(data){
                   $("#resultarea").text(data);
                   location.reload();

                }
                 });
          }
     }  
</script> -->