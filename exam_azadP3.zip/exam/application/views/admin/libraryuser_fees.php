
    <div id="wrapper">

     <?php include "sidebar.php" ;?>
      <div id="content-wrapper">

        <div class="container-fluid">
             <!-- Icon Cards-->
          <div class="row">
          <!--*****START*******-->
          <div class="border margin20  padding10 whitebg col-xl-12 col-md-12  col-sm-12">
                   <h2>Profile</h2> 

            
           
            <div class="col-12 col-md-12 col-lg-12 mt-4 mt-lg-0  mt20" id="topdiv">
                      <div class="table-responsive">          
                        <table class="table" >
                          <thead>
                            <tr>
                              <th>#</th>
                              <th>Transection Id</th>
                              <th>Amount</th>
                              <th>Payment Status</th>
                              <th>Package</th>
                              <th>Date</th>
                              <th>Package Expire Date</th>
                            </tr>
                          </thead>
                          <tbody>                                                                                                                                                                                     
                          <?php foreach($userData  as $key=>$data){ ?>
                            <tr>
                              <td><?php echo $key+1 ?></td>
                              <td><?php echo $data->orderid ?></td>
                              <td><?php echo $data->amount ?> Rs.</td>
                              <td><?php echo $data->status ?></td>
                            <td>
                                   <?php
                              $package =  $this->db->select('description')->from('lib_package')->where('pack_id',$data->package_type)->get()->row() ;
                                  echo $package->description ;
                             ?>
                                </td> 
                              <td><?php echo $data->date ?></td>
                              <td><?php echo $data->exp_date ?></td>
                            </tr>
                          <?php } ?>
                          </tbody>
                        </table>
                        </div>
                </div>
          <?php echo $this->session->flashdata('adUSerPassFlachCheck') ; ?>
                </div>
          
          
          
          
          <!--*****END********-->

     </div>

        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>
    
    <script type="text/javascript">
    
      $("#frmregistration").click(function(){
        $('form[id="registration_form"]').validate({
          
          var  waitimg = '<?php echo base_url('uploads/ashg/loader.gif') ?>' ;
        rules: {
          firstName: 'required',
          lastName: 'required',
          contactNo: 'required',
          inputEmail: 'required',
          inputPassword: 'required',
          confirmPassword: 'required',
          userAddress: 'required',
          },
           errorPlacement: function(){
            return false;   /*suppresses error message text*/
          },
          submitHandler: function(form) {
          return true ;
          }
        });
      });
         </script>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->
