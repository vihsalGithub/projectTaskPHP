<script src="<?php echo base_url() ; ?>/assets//ckeditor/ckeditor.js" type="text/javascript"></script>
 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
   <style type="text/css" rel="http://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css"></style>
<div id="wrapper">
    <?php $this->load->view('admin/sidebar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
      
          <!-- Breadcrumbs-->
      <?php 
       // $this->load->view('admin/test-exammanu.php'); 
       // print_r($userId);
       // print_r($userData);
        //print_r($libPackage);
      ?>
      
      <div class="container">
        <div class="row">
       <div class="border margin20  padding10 whitebg col-xl-6 col-md-6  col-sm-12">
      <h2>Add Library Fees</h2> 
      <form class=" form-horizontal" method="post" enctype="multipart/form-data" id="" action="<?php echo base_url('admin/addlibraryfee/').$userId ?>">

 <input type="hidden" name="user_id" value="<?php echo $user_id; ?>" class="form-control">

                    <div class="form-group">
                      <label class="control-label col-sm-12" for="username">First Name</label>
                      <div class="col-sm-12">
                        <input type="readonly" readonly value="<?php echo $userData->first_name.'-'.$userData->last_name ; ?>" class="form-control">
                      </div>
                    </div>
          
          <div class="form-group">
                      <label class="control-label col-sm-12" for="email">Email</label>
                      <div class="col-sm-12">
                        <input type="readonly" readonly   value="<?php echo $userData->user_name ; ?>"  class="form-control">
                      </div>
                    </div>
          
            <div class="form-group">
                      <label class="control-label col-sm-12" for="amount">Amount</label>
                      <div class="col-sm-12">
                        <input type="number" required name="amount" value="" class="form-control">
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-sm-12" for="username">Entry Date</label>
                      <div class="col-sm-12">
                        <input type="text" required name="fee_entry_date" value="" class="form-control datepicker">
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-sm-12" for="username">Expire Date</label>
                      <div class="col-sm-12">
                        <input type="text" name="exp_date " value="" required class="form-control datepicker">
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-sm-12" for="username">Select Package</label>
                      <div class="col-sm-12">
                            <select class="form-control"  required id="lib_package" name="lib_package">
                                <option value="" required >Select Package</option>
                                <?php
                                  foreach ($libPackage as $key => $value) {
                                     echo '<option value="'.$value->pack_id.'">'.$value->description.'</option>';
                                  }
                                ?>
                            </select>
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-sm-12" for="amount">Status</label>
                      <div class="col-sm-12">
                        <input type="hidden"   name="status" value="1" class="form-control">
                        <input type="hidden"   name="orderid" value="<?php echo rand(1000,10000) ?>" class="form-control">
                        <input type="hidden"   name="user_id" value="<?php echo $userId ; ?>" class="form-control">
                      </div>
                    </div>
                   
                    <div class="form-group">        
                      <div class="col-sm-offset-2 col-sm-12">
                        <button type="submit" class="btn btn-success">Submit</button>
                      </div>
                    </div>
      </form>
    </div> 
        
        </div>
      </div>
    </div>
    </div>
        <!-- Sticky Footer -->
         <!--******************************"calender Script"*****************************-->
     <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script>
                  jQuery(document).ready(function($) {
                      /* $(".datepicker").datepicker({ dateFormat: "yy-mm-dd" }); */
            $( ".datepicker" ).datepicker({
              changeMonth: true,
              changeYear: true,
              dateFormat: "dd-mm-yy"
            });
                  });
              </script> 
     <!--******************************"calender Script"*****************************-->
        
    <?php 
      $this->load->view('admin/footer_sticky.php');    
    ?>
    </div>
      <!-- /.content-wrapper -->
</div>