<script src="<?php echo base_url() ; ?>/assets//ckeditor/ckeditor.js" type="text/javascript"></script>
<div id="wrapper">
    <?php $this->load->view('admin/sidebar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
			
          <!-- Breadcrumbs-->
			<?php 
				$this->load->view('admin/test-exammanu.php'); 
				//print_r($OE_TEST_PAPERS);
			?>
			
			<div class="container">
				<div class="row">
				<?php echo $this->session->flashdata('flashmessage') ;?>
					<div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Sn</th>
                      <th>Image path</th>
                      <th>User Name</th>
                      <th>Order id</th>
                      <th>Useremail</th>
                      <th>Contact No</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>Sn</th>
                      <th>Image path</th>
                      <th>User Name</th>
                      <th>Order id</th>
                      <th>Useremail</th>
                      <th>Contact No</th>
                    </tr>
                  </tfoot>
                  <tbody>
				  <?php foreach ($userData as $key => $value) { ?>
				      <?php  $imgpath = base_url("uploads/vrification/"). $value->image_path  ?>
            <tr>
					   <td><?php echo $key+1 ?></td>
             <td><img src="<?php echo $imgpath  ?>" width="50px" height="50px"><a  href="#" onclick='fillimag("<?php echo $imgpath  ?>","<?php echo $value->order_id ?>","<?php echo $value->useremail ?>")'>show</a></td>
					   <td><?php echo $value->fullname ?></td>
					   <td><?php echo $value->order_id ?></td>
					   <td><?php echo $value->useremail ?></td>
					   <td><?php echo $value->contact_no ?></td>					   
					</tr>
				  <?php } ?>
                 
                  </tbody>
                </table>
              </div>
				</div>
			</div>
		</div>
    </div>
        <!-- Sticky Footer -->
        
		<?php 
			$this->load->view('admin/footer_sticky.php');    
		?>
    </div>
      <!-- /.content-wrapper -->
</div>
<script>
 function fillimag(imgpath,orderID,email){
 // alert(imgpath);
    $("#imagePath").text('');
    var img =   '<img src="'+imgpath+'"   height="250px"><p><b>Email:</b>  '+email+'</p><p><b>Oer IDrd:</b>  '+orderID+'</p>';
    $("#imagePath").append(img);
	 $("#myModal").modal('show') ;
 }
</script>

 <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <div id="imagePath"></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>