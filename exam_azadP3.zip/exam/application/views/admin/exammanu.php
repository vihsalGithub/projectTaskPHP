<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
<style>
  .manuactive{
	  color:#fff !important ;
  }
  .form-label{
	  font-size:15px;
	  font-weight:bold;
  }
</style>
<?php
$examManu  = $this->uri->segment(2);
if($examManu == 'category'){
	$catManuClass = 'manuactive';
}else{
	$catManuClass = '';
}
if($examManu == 'subjects'){
	$subManuClass = 'manuactive';
}else{
	$subManuClass = '';
}

if($examManu == 'questions' || $examManu  == 'allquestions'|| $examManu  == 'questionedit'){
	$qusManuClass = 'manuactive';
}else{
	$qusManuClass = '';
}

if($examManu == 'addques'){
	$qusManuClass1 = 'manuactive';
}else{
	$qusManuClass1 = '';
}
if($examManu == 'papers'){
	$papersManuClass1 = 'manuactive';
}else{
	$papersManuClass1 = '';
}

if($examManu == 'createpaper'){
	$crtPprManuClass1 = 'manuactive';
}else{
	$crtPprManuClass1 = '';
}

?>

<nav class="navbar navbar-expand navbar-dark bg-dark static-top mb20">
	 <ul class="navbar-nav ml-auto ml-md-0">
			<li class="nav-item dropdown no-arrow">
			  <a class="nav-link  <?php echo $catManuClass ?>" href="<?php echo base_url('onlineexam/category') ?>"  >
			   Category
			  </a>
			</li>|
			<li class="nav-item dropdown no-arrow">
			  <a class="nav-link <?php echo $subManuClass ?>" href="<?php echo base_url('onlineexam/subjects') ?>"  >
			   Subject
			  </a>
			</li>|
			<li class="nav-item dropdown no-arrow">
			  <a class="nav-link  <?php echo $qusManuClass ?>" href="<?php echo base_url('onlineexam/questions') ?>"  >
			   Question
			  </a>
			</li>|
			<li class="nav-item dropdown no-arrow">
			  <a class="nav-link  <?php echo $qusManuClass1 ?>" href="<?php echo base_url('onlineexam/addques') ?>"  >
			   Add Question
			  </a>
			</li>
			<li class="nav-item dropdown no-arrow">
			  <a class="nav-link  <?php echo $papersManuClass1 ?>" href="<?php echo base_url('onlineexam/papers') ?>"  >
			   Papers
			  </a>
			</li>
			
			
	 </ul>
</nav>
