    
    <div id="wrapper">
     <?php include "sidebar.php" ;?>
      <div id="content-wrapper">
        <div class="container-fluid">

          <nav class="navbar navbar-expand navbar-dark bg-dark static-top mb20">
             <ul class="navbar-nav ml-auto ml-md-0">
                 <li class="nav-item dropdown no-arrow">
                  <a class="nav-link  " href="<?php echo base_url('admin/addCurrentFacts/1') ?>">
                    Add News
                  </a>
                </li>
             </ul>
          </nav>
          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header"> 
              <i class="fas fa-table"></i>
              <?php echo $page_title ?></div>
              <?php
                 // print_r($currentFacts2);
              ?>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>SN</th>
                      <th>Image</th>
                      <th>Name</th>
                      <th>Content</th>
                      <th>category</th>
                     <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>SN</th>
                      <th>Image</th>
                      <th>Name</th>
                      <th>Content</th>
                      <th>category</th>
					           <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </tfoot>
                  <tbody>
				  <?php foreach ($currentFacts2 as $key => $value) { ?>
                  <td><?php echo $key+1 ?></td>
                  <td><img src="<?php echo $value->news_image ?>" width="50" height="50"/></td>
                  <td><?php echo $value->news_title ?></td>
                  <td><?php echo $value->news ?></td>
                  <td><?php echo $value->news_category ?></td>
                  <td><?php echo $value->status ?></td> 
                  <td>action</td> 
				  <?php } ?>
                      
                  </tbody>
                </table>
              </div>
            </div>
          </div>
		  
		   <!-- Area Chart Example-->
          <div class="card mb-3 display-none">
            <div class="card-header">
              <i class="fas fa-chart-area"></i>
              Area Chart Example</div>
            <div class="card-body">
              <canvas id="myAreaChart" width="100%" height="30"></canvas>
            </div>
            <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
          </div>
        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->
