    <div id="wrapper">

     <?php include "sidebar.php" ;?>
      <div id="content-wrapper">

        <div class="container-fluid">

             <!-- Icon Cards-->
            <div class="row">
           
		      <?php //print_r($userData) ; ?>
		      <!--*****START*******-->
		      
		      <div class="border margin20  padding10 whitebg col-xl-12 col-md-12  col-sm-12">
                   <h4>Add Events</h4> 
                   
                         <!--------------show alert message----------------------->
            
            <?php if($error=$this->session->flashdata('success')): ?>
            <div class="alert alert-success">
            <?= $error; ?>
            </div>
            <?php endif; ?>
            
             <?php if($error=$this->session->flashdata('failure')): ?>
            <div class="alert alert-danger">
            <?= $error; ?>
            </div>
            <?php endif; ?>
            
    <!----------------end show alert message------------------>
				   
         <form class=" form-horizontal" method="post" enctype="multipart/form-data" id="userProfileForm" action="<?php echo base_url('admin/addevents') ?>">                    

                    <div class="form-group">
                      <div class="col-md-8">
                       Title<input type="text"  class="form-control" name="title" placeholder="Enter Event Title"> 
                        <div class="text-danger"><?= form_error('title'); ?></div>
                      </div>
                      <div class="col-md-8">
                       Image <input type="file"  class="form-control" name="userfile">
                        <div class="text-danger"><?= form_error('userfile'); ?></div>
                      </div>
                    </div>
                    
                     <div class="form-group">
                      <div class="col-sm-8">
                       Date <input type="text"  class="form-control" name="eventdate" Placeholder="DD/MM/YYYY">
                        <div class="text-danger"><?= form_error('eventdate'); ?></div>
                      </div>
                      <div class="col-sm-8">
                       Time<input type="text"  class="form-control" name="eventtime" Placeholder="h:mm:ss">
                        <div class="text-danger"><?= form_error('eventtime'); ?></div>
                      </div>
                    </div>
                    
                    
                    <div class="form-group">
                      <div class="col-sm-8">          
                        Description <textarea class="form-control" name="description"></textarea>
                         <div class="text-danger"><?= form_error('description'); ?></div>
                      </div>
                    </div>
                      <div class="form-group">
                      <div class="col-sm-8">          
                        Address <textarea class="form-control" name="address"></textarea>
                         <div class="text-danger"><?= form_error('address'); ?></div>
                      </div>
                    </div>
                    
                    <hr>
                    <h6>Contact Persont :</h6>
                    
                       <div class="form-group">
                      <div class="col-sm-8">
                       Name <input type="text"  class="form-control" name="cpname" placeholder="Enter Contact Person Name">
                        <div class="text-danger"><?= form_error('cpname'); ?></div>
                      </div>
                      <div class="col-sm-8">
                       Email <input type="email"  class="form-control" name="cpemail"  placeholder="Enter Contact Person Email">
                        <div class="text-danger"><?= form_error('cpemail'); ?></div>
                      </div>
                    </div>
                    
                                           <div class="form-group">
                      <div class="col-sm-8">
                       Contact <input type="text"  class="form-control" name="cpcontact" placeholder="Enter Contact Person Contact">
                        <div class="text-danger"><?= form_error('cpcontact'); ?></div>
                      </div>
                      <div class="col-sm-8">
                       Address <input type="text"  class="form-control" name="cpaddress" placeholder="Enter Contact Persont Address">
                        <div class="text-danger"><?= form_error('cpaddress'); ?></div>
                      </div>
                    </div>
                    
 
                   
                    <div class="form-group">        
                      <div class="col-sm-offset-2 col-sm-12">
                      <input type="hidden" name="date" value="<?php echo date('d-m-Y'); ?>">
                        <button type="submit" class="btn btn-info" >Submit</button>
                        <span id="buttonMessageUP"></span>
                      </div>
                    </div>
                  </form>
				 
                </div>
		      
		      
		      
		      
		      <!--*****END********-->

	   </div>

        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>
		
		<script type="text/javascript">
		
			$("#frmregistration").click(function(){
				$('form[id="registration_form"]').validate({
					
					var  waitimg = '<?php echo base_url('uploads/ashg/loader.gif') ?>' ;
				rules: {
					firstName: 'required',
					lastName: 'required',
					contactNo: 'required',
					inputEmail: 'required',
					inputPassword: 'required',
					confirmPassword: 'required',
					userAddress: 'required',
				  },
				   errorPlacement: function(){
						return false;   /*suppresses error message text*/
					},
				  submitHandler: function(form) {
					return true ;
				  }
				});
			});
         </script>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->
