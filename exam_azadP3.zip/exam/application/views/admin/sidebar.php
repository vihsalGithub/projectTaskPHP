  <?php  $dashboardManu  = $this->uri->segment(2);	
  if($dashboardManu == "dashboard"){$dashboardactive = 'active';}else{ $dashboardactive = '';	}	
  if($dashboardManu == "students"){ $studentsactive = 'active';	}else{ $studentsactive = '';	}	
  if($dashboardManu == "library"){  $libraryactive = 'active';	}else{  $libraryactive = '';	}	
  if($dashboardManu == "members"){      $employeeactive = 'active';	}else{		$employeeactive = '';	}	
  if($dashboardManu == "payments"){      $paymentsactive = 'active';	}else{		$paymentsactive = '';	}	
  if($dashboardManu == "birthday"){      $birthdayactive = 'active';	}else{		$birthdayactive = '';	}	
  if($dashboardManu == "bloodgroup"){      $bloodgroupactive = 'active';  }else{    $bloodgroupactive = '';  }  
  if($dashboardManu == "examsusers"){      $examsusers = 'active';	}else{		$examsusers = '';	}	
  if($dashboardManu == "events"){      $eventsactive = 'active';	}else{		$eventsactive = '';	}	
  if($dashboardManu == "events"){      $varification = 'active';  }else{    $varification = ''; } 
  if($dashboardManu == "enquiry1"){      $enquiry1 = 'active';  }else{    $enquiry1 = ''; } 
  if($dashboardManu == "currentFacts"){      $currentFacts = 'active';  }else{    $currentFacts = ''; } 
  if($dashboardManu == "user_varifiaction"){      $user_varifiaction = 'active';	}else{		$user_varifiaction = '';	}	
  $manuname = $this->uri->segment(1);	
  if($manuname == 'onlineexam'){		$Online = 'active';	}else{		$Online = '';	}  ?>

      <!-- Sidebar -->      

<ul class="sidebar navbar-nav">    
      <li class="nav-item <?php echo $dashboardactive ?>">         
       <a class="nav-link" href="<?php echo base_url('admin/dashboard') ?>">            
       	<i class="fas fa-fw fa-tachometer-alt"></i>            
       	<span>Dashboard</span>         
       	 </a>        
      </li>			

     	

     <li class="nav-item <?php echo $libraryactive  ?>">
          <a class="nav-link"  href="<?php echo base_url('admin/library') ?>">
            <i class="fas fa-fw fa-book"></i>
            <span>Library</span>
          </a>
        </li> 
		
		<!-- <li class="nav-item <?php echo $studentsactive  ?>">
          <a class="nav-link"  href="<?php echo base_url('admin/students') ?>">
            <i class="fas fa-fw fa-users"></i>
            <span>Students</span>
          </a>
        </li> -->
		
		<!-- <li class="nav-item <?php echo $employeeactive ?>">
          <a class="nav-link"  href="<?php echo base_url('admin/members') ?>">
            <i class="fas fa-fw fa-user"></i>
            <span>Members</span>
          </a>
    </li> -->
		
		
			<!-- <li class="nav-item <?php echo $paymentsactive ?>">
          <a class="nav-link "  href="<?php echo base_url('admin/payments') ?>">
            <i class="fas fa-fw fa-list"></i>
            <span>Payments</span>
          </a>
        </li> 
		
		<!-- <li class="nav-item <?php echo $birthdayactive ?>">
          <a class="nav-link"  href="<?php echo base_url('admin/birthday') ?>">
            <i class="fas fa-fw fa-birthday-cake"></i>
            <span>Birth Day</span>
          </a>
        </li> -->
		
			<!--<li class="nav-item <?php echo $bloodgroupactive ?>">
          <a class="nav-link"  href="<?php echo base_url('admin/bloodgroup') ?>">
            <i class="fas fa-fw fa fa-hospital-o"></i>
            <span>Blood Group</span>
          </a>
      </li>
		
		<!-- <li class="nav-item <?php echo $eventsactive ?>">
          <a class="nav-link"  href="<?php echo base_url('admin/events') ?>">
            <i class="fas fa-fw fa-calendar"></i>
            <span>Events</span>
          </a>
        </li> -->
		
		
		<!-- <li class="nav-item <?php echo $Online ; ?>">
          <a class="nav-link" href="<?php echo base_url('onlineexam/category') ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Online Exam</span>
          </a>
        </li> -->


     	<!-- <li class="nav-item <?php echo $enquiry1 ; ?>">
          <a class="nav-link" href="<?php echo base_url('admin/enquiry') ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Student Enquiry</span>
          </a>
      </li>


      <li class="nav-item <?php echo $currentFacts ; ?>">
          <a class="nav-link" href="<?php echo base_url('admin/currentFacts') ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Current Facts</span>
          </a>
      </li>

     
       <li class="nav-item <?php echo $examsusers ; ?>">         
        <a class="nav-link" href="<?php echo base_url('admin/examsusers') ?>">           
         <i class="fas fa-fw fa-tachometer-alt"></i>           
          <span>Online Exam Users</span>         
           </a>    
       </li>				
       <li class="nav-item <?php echo $Online ; ?>">          
       	<a class="nav-link" href="<?php echo base_url('onlineexam/testpapers') ?>">            
       		<i class="fas fa-fw fa-tachometer-alt"></i>            
       		<span>Online Exam </span>          
       	</a>        
       </li>
        <li class="nav-item <?php echo $user_varifiaction ; ?>">          
       	<a class="nav-link" href="<?php echo base_url('admin/user_varifiaction') ?>">            
       		<i class="fas fa-fw fa-tachometer-alt"></i>            
       		<span>User Varifications</span>          
       	</a>        
       </li>				
       <li class="nav-item ">          
	       	<a class="nav-link" target="_blank" href="http://www.easyhindityping.com/">            
	       		<i class="fas fa-fw fa-tachometer-alt"></i>            
	       		<span>Hindi Typing</span>          
	       	</a>       
       	</li>        
       	  <li class="nav-item dropdown display-none">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-folder"></i>
            <span>Pages</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <h6 class="dropdown-header">Login Screens:</h6>
            <a class="dropdown-item" href="login.html">Login</a>
            <a class="dropdown-item" href="register.html">Register</a>
            <a class="dropdown-item" href="forgot-password.html">Forgot Password</a>
            <div class="dropdown-divider"></div>
            <h6 class="dropdown-header">Other Pages:</h6>
            <a class="dropdown-item" href="404.html">404 Page</a>
            <a class="dropdown-item" href="blank.html">Blank Page</a>
          </div>
        </li> -->

        <li class="nav-item display-none">

          <a class="nav-link" href="charts.html">

            <i class="fas fa-fw fa-chart-area"></i>

            <span>Charts</span></a>

        </li>

        <li class="nav-item display-none">

          <a class="nav-link" href="tables.html">

            <i class="fas fa-fw fa-table"></i>

            <span>Tables</span></a>

        </li>

    </ul>
	
	

