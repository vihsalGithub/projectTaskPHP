    <div id="wrapper">

     <?php include "sidebar.php" ;?>
      <div id="content-wrapper">

        <div class="container-fluid">

             <!-- Icon Cards-->
            <div class="row">
           
		      <?php //print_r($userData) ; ?>
		      <!--*****START*******-->
		      
		      <div class="border margin20  padding10 whitebg col-xl-12 col-md-12  col-sm-12">
                   <h4>Update Events</h4> 
                   
                         <!--------------show alert message----------------------->
            
            <?php if($error=$this->session->flashdata('success')): ?>
            <div class="alert alert-success">
            <?= $error; ?>
            </div>
            <?php endif; ?>
            
             <?php if($error=$this->session->flashdata('failure')): ?>
            <div class="alert alert-danger">
            <?= $error; ?>
            </div>
            <?php endif; ?>
            
            <?php
            foreach($eventsdata as $row){
            $title=$row->title;
            $imagepath=$row->image_path;
            $eventdate=$row->eventdate;
            $eventtime=$row->eventtime;
            $desc=$row->description;
            $address=$row->address;
            $cpname=$row->cpname;
            $cpemail=$row->cpemail;
            $cpcontact=$row->cpcontact;
            $cpaddress=$row->cpaddress;
            
            }
            
            ?>
            
            
    <!----------------end show alert message------------------>
				   
         <?php echo form_open_multipart("Admin/updateeventsbyid/{$row->id}"); ?>                   

                    <div class="form-group">
                      <div class="col-md-8">
                       Title<input type="text"  class="form-control" name="title" value="<?= $title ?>"> 
                        <div class="text-danger"><?= form_error('title'); ?></div>
                      </div>
                      <div class="col-md-8">
                       Image <br><img src="<?= $imagepath; ?>" style="width:50px; height:50px;"><input type="file"  class="form-control" name="userfile" >
                        <div class="text-danger"><?= form_error('userfile'); ?></div>
                      </div>
                    </div>
                    
                     <div class="form-group">
                      <div class="col-sm-8">
                       Date <input type="text"  class="form-control" name="eventdate"  value="<?= $eventdate ?>">
                        <div class="text-danger"><?= form_error('eventdate'); ?></div>
                      </div>
                      <div class="col-sm-8">
                       Time<input type="text"  class="form-control" name="eventtime"  value="<?= $eventtime ?>" >
                        <div class="text-danger"><?= form_error('eventtime'); ?></div>
                      </div>
                    </div>
                    
                    
                    <div class="form-group">
                      <div class="col-sm-8">           
                        Description <textarea class="form-control" name="description" ><?= $desc; ?></textarea>
                         <div class="text-danger"><?= form_error('description'); ?></div>
                      </div>
                    </div>
                      <div class="form-group">
                      <div class="col-sm-8">          
                        Address <textarea class="form-control" name="address" ><?= $address; ?></textarea>
                         <div class="text-danger"><?= form_error('address'); ?></div>
                      </div>
                    </div>
                    
                    <hr>
                    <h6>Contact Persont :</h6>
                    
                       <div class="form-group">
                      <div class="col-sm-8">
                       Name <input type="text"  class="form-control" name="cpname"  value="<?= $cpname ?>">
                        <div class="text-danger"><?= form_error('cpname'); ?></div>
                      </div>
                      <div class="col-sm-8">
                       Email <input type="email"  class="form-control" name="cpemail"  value="<?= $cpemail ?>">
                        <div class="text-danger"><?= form_error('cpemail'); ?></div>
                      </div>
                    </div>
                    
                                           <div class="form-group">
                      <div class="col-sm-8">
                       Contact <input type="text"  class="form-control" name="cpcontact"  value="<?= $cpcontact ?>">
                        <div class="text-danger"><?= form_error('cpcontact'); ?></div>
                      </div>
                      <div class="col-sm-8">
                       Address <input type="text"  class="form-control" name="cpaddress" value="<?= $cpaddress ?>">
                        <div class="text-danger"><?= form_error('cpaddress'); ?></div>
                      </div>
                    </div>
                    
 
                   
                    <div class="form-group">        
                      <div class="col-sm-offset-2 col-sm-12">
                      <input type="hidden" name="date" value="<?php echo date('d-m-Y'); ?>">
                        <button type="submit" class="btn btn-success">Update</button>
                        <span id="buttonMessageUP"></span>
                      </div>
                    </div>
                  </form>
				 
                </div>
		      
		      
		      
		      
		      <!--*****END********-->

	   </div>

        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>
		
		<script type="text/javascript">
		
			$("#frmregistration").click(function(){
				$('form[id="registration_form"]').validate({
					
					var  waitimg = '<?php echo base_url('uploads/ashg/loader.gif') ?>' ;
				rules: {
					firstName: 'required',
					lastName: 'required',
					contactNo: 'required',
					inputEmail: 'required',
					inputPassword: 'required',
					confirmPassword: 'required',
					userAddress: 'required',
				  },
				   errorPlacement: function(){
						return false;   /*suppresses error message text*/
					},
				  submitHandler: function(form) {
					return true ;
				  }
				});
			});
         </script>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->
