

    <div id="wrapper">

     <?php include "sidebar.php" ;?>
      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- $data['totalActiveUser'] = count($totalActiveUser);
           $data['totalDeactiveUser'] = count($totalDeactiveUser);
           $data['totalUser'] = count($totalUser); -->

          <!-- Icon Cards-->
          <div class="row  ">
            <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-primary o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fas fa-fw fa-users"></i>
                  </div>
                  <div class="mr-5">Total Online Exam Students</div>
                  <span style="font-size: 20px"><b><?php echo $totalUser ?></b></span>
                </div>
                <a class="card-footer text-white clearfix small z-1" href="<?php echo base_url('onlineexam/testpapers') ?>">
                  <span class="float-left">View Details</span>
                  <span class="float-right">
                    <i class="fas fa-angle-right"></i>
                  </span>
                </a>
              </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-warning o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fas fa-fw fa-list"></i>
                  </div>
                  <div class="mr-5">Total Activate Students</div>
                  <span style="font-size: 20px"><b><?php echo $totalActiveUser ?></b></span>
                </div>
                <a class="card-footer text-white clearfix small z-1" href="<?php echo base_url('admin/activate_exam_user') ?>">
                  <span class="float-left">View Details</span>
                  <span class="float-right">
                    <i class="fas fa-angle-right"></i>
                  </span>
                </a>
              </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-success o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                  </div>
                   <div class="mr-5">Total Deactive Students</div>
                  <span style="font-size: 20px"><b><?php echo $totalDeactiveUser ?></b></span>
                </div>
                <a class="card-footer text-white clearfix small z-1" href="<?php echo base_url('admin/deactivate_exam_user') ?>">
                  <span class="float-left">View Details</span>
                  <span class="float-right">
                    <i class="fas fa-angle-right"></i>
                  </span>
                </a>
              </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-danger o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fas fas fa-fw fa-book"></i>
                  </div>
                   <div class="mr-5">Total Amount (In Rupee)</div>
                  <span style="font-size: 20px"><b>Rs.<?php echo $totalAmount[0]->amount ?></b></span>
                </div>
                <a class="card-footer text-white clearfix small z-1" href="<?php echo base_url('admin/payments') ?>">
                  <span class="float-left">View Details</span>
                  <span class="float-right">
                    <i class="fas fa-angle-right"></i>
                  </span>
                </a>
              </div>
            </div>
          </div>
          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              <?php echo $page_title ?></div>
            <div class="card-body">
              <div class="table-responsive">
                



                <table class="table table-bordered" id="dataTable" cellspacing="0">
                      <thead>
                      <tr>
                        <th>SN</th>
                        <th>User Name</th>
                        <th>Package</th>
                        <th>Amount(In INR)</th>
                        <th>Date</th>
                      </tr>
                      </thead>
                      <tfoot>
                      <tr>
                        <th>SN</th>
                        <th>User Name</th>
                        <th>Package</th>
                        <th>Amount(In INR)</th>
                        <th>Date</th>
                      </tr>
                      </tfoot>
                      <tbody>
                        <?php
                          foreach ($paymantsData as $key => $paymValue) {
                           ?>
                            <tr>
                            <td><?php echo $key+1 ?></td>
                            <td><?php echo $paymValue->name ?></td>
                            <td><?php 
                              $oe_package = $this->db->select('name')->from('oe_package ')->where('pack_id',$paymValue->productinfo)->get()->row();
                            echo $oe_package->name ;
                             ?></td>
                            <td><?php echo $paymValue->amount ?></td>
                            <td><?php echo $paymValue->date ?></td>
                          </tr>
                           <?php
                          }
                        ?>
                         
                      </tbody>
                  </table>




              </div>
            </div>
          </div>
		  
		   <!-- Area Chart Example-->
          <div class="card mb-3 display-none">
            <div class="card-header">
              <i class="fas fa-chart-area"></i>
              Area Chart Example</div>
            <div class="card-body">
              <canvas id="myAreaChart" width="100%" height="30"></canvas>
            </div>
            <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
          </div>
        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->
