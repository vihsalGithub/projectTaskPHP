
    <div id="wrapper">
     <?php include "sidebar.php" ;?>
      <div id="content-wrapper">
        <div class="container-fluid">
          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
             Blood Group</div>
            <div class="card-body">
              <div class="table-responsive">
                <div class="table-responsive">          
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                          <thead>
                            <tr>
                              <th>Sn</th>
                              <th>Name</th>
                              <th>Contact No.</th>
                              <th>Subject</th>
                              <th>Message</th>
                              <th>Date</th>
                              <th>Reply</th>
                            </tr>
                          </thead>
                          <tfoot>
                            <tr>
                              <th>Sn</th>
                              <th>Name</th>
                              <th>Contact No.</th>
                              <th>Subject</th>
                              <th>Message</th>
                              <th>Date</th>
                              <th>Reply</th>
                            </tr>
                          </tfoot>
                          <tbody>
                          <?php foreach($enquiry  as $key=>$data){ ?>
                            <tr>
                                <td><?php echo $key+1?></td>
                                <td><?php echo $data->name ?></td>
                                <td><?php echo $data->contact ?></td>
                                <td><?php echo $data->subject ?></td>
                                <td><?php echo $data->message ?></td>
                                <td><?php echo $data->created_at ?></td>
                                <td><a href="#">Reply</a></td>
                            </tr>
                          <?php } ?>
                          </tbody>
                        </table>
                        </div>
              </div>
            </div>
          </div>
		  <?php
        //  print_r($enquiry);
      ?>
		   <!-- Area Chart Example-->
          <div class="card mb-3 display-none">  
            <div class="card-header">
              <i class="fas fa-chart-area"></i>
              Area Chart Example</div>
            <div class="card-body">
              <canvas id="myAreaChart" width="100%" height="30"></canvas>
            </div>
            <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
          </div>
        </div>
        <!-- /.container-fluid -->
<script>

	/*$(document).ready(function() {
		$('#dataTable').DataTable( {
				initComplete: function () {
					this.api().columns(4).every( function () {
						var column = this;
						var select = $('<select><option value="">Blood Group</option></select>')
							.appendTo( $(column.header()).empty() )
							.on( 'change', function () {
								var val = $.fn.dataTable.util.escapeRegex(
									$(this).val()
								);
								column
									.search( val ? '^'+val+'$' : '', true, false )
									.draw();
							} );
						column.data(1).unique().sort().each( function ( d, j ) {
							select.append( '<option value="'+d+'">'+d+'</option>' )
						} );
					} );
				}
			} );
			
	});*/
</script>
        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->
