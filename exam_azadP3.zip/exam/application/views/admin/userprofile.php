
    <div id="wrapper">

     <?php include "sidebar.php" ;?>
      <div id="content-wrapper">

        <div class="container-fluid">

             <!-- Icon Cards-->
            <div class="row">
           
		      <?php //print_r($userData) ; ?>
		      <!--*****START*******-->
		      
		      <div class="border margin20  padding10 whitebg col-xl-6 col-md-6  col-sm-12">
                   <h2>Profile</h2> 
				   
         <form class=" form-horizontal" method="post" enctype="multipart/form-data" id="userProfileForm" action="<?php echo base_url('admin/useractivate/') ?>">

                  <input type="hidden" id="userID" name="userID" value="<?php echo base64_encode($userData->user_id ) ?>">
                    
                     <div class="form-group">
                      <label class="control-label col-sm-12" for="Pincode">Profile Image:</label>
                      <div class="col-sm-12">          
                        <img class=" imgcenter " width="100px" src="http://azadhelp.org/<?php echo $userData->image ?>">
                      </div>
                                       


                    <div class="form-group">
                      <label class="control-label col-sm-12" for="username">Name</label>
                      <div class="col-sm-12">
                        <input type="text" readonly="" value="<?php echo $userData->first_name.' '.$userData->last_name ?>" class="form-control" >
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-sm-12" for="useremail">Email:</label>
                      <div class="col-sm-12">          
                        <input type="text" readonly="" value="<?php echo $userData->email ?>" class="form-control" >
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-sm-12" for="fatehername">Father Name:</label>
                      <div class="col-sm-12">          
                        <input type="text" readonly="" value="<?php echo $userData->father_name?>" class="form-control" >
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-sm-12" for="fatehername">Highest Qualification:</label>
                      <div class="col-sm-12">          
                        <input type="text" readonly=""  value="<?php echo $userData->qualifiaction?>" class="form-control" >
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-sm-12" for="fatehername">Inter City:</label>
                        <div class="col-sm-12">
                        <input type="text" readonly="" value="<?php echo $userData->city ?>"  class="form-control"  placeholder="Enter city" >
                      </div>
                    </div>

  

                    <div class="form-group">
                      <label class="control-label col-sm-12" for="Pincode">Pincode:</label>
                      <div class="col-sm-12">          
                        <input type="text"  readonly="" value="<?php echo $userData->pincode  ?>" class="form-control">
                      </div>
                    </div>
						<?php
							$a = 'Active';
							$b = 'Deactive';
							$result = ($userData->status) ? $a :$b;
						?>
					
                    <div class="form-group">
                      <label class="control-label col-sm-12" for="userstatus">Status:</label>
                      <div class="col-sm-12">  
						 <select class="form-control" name="userStatus" id="userStatus">
							<option value="<?php echo $userData->status    ?>" ><?php echo $result  ?></option>
							<option value="1">Active</option>
							<option value="0">Deactive</option>
						  </select>
                      </div>
                    </div>
                   
                    <div class="form-group">        
                      <div class="col-sm-offset-2 col-sm-12">
                        <button type="submit" class="btn btn-success">Submit</button>
                        <span id="buttonMessageUP"></span>
                      </div>
                    </div>
                  </form>
				  <?php echo $this->session->flashdata('adUSerPassFlachCheck') ; ?>
                </div>
		      
		      
		      
		      
		      <!--*****END********-->

	   </div>

        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>
		
		<script type="text/javascript">
		
			$("#frmregistration").click(function(){
				$('form[id="registration_form"]').validate({
					
					var  waitimg = '<?php echo base_url('uploads/ashg/loader.gif') ?>' ;
				rules: {
					firstName: 'required',
					lastName: 'required',
					contactNo: 'required',
					inputEmail: 'required',
					inputPassword: 'required',
					confirmPassword: 'required',
					userAddress: 'required',
				  },
				   errorPlacement: function(){
						return false;   /*suppresses error message text*/
					},
				  submitHandler: function(form) {
					return true ;
				  }
				});
			});
         </script>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->
