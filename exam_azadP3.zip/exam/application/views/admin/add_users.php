    <div id="wrapper">

     <?php include "sidebar.php" ;?>
      <div id="content-wrapper">

        <div class="container-fluid">

             <!-- Icon Cards-->
            <div class="row">
           
		      <?php   //print_r($userData) ; ?>
		      <!--*****START*******-->
		      
		      <div class="border margin20  padding10 whitebg col-xl-12 col-md-12  col-sm-12">
                   <h4>Add Users</h4> 
                   
                         <!--------------show alert message----------------------->
            
            <?php if($error=$this->session->flashdata('success')): ?>
            <div class="alert alert-success">
            <?= $error; ?>
            </div>
            <?php endif; ?>
            
             <?php if($error=$this->session->flashdata('failure')): ?>
            <div class="alert alert-danger">
            <?= $error; ?>
            </div>
            <?php endif; ?>
            
    <!----------------end show alert message------------------>
				   
         <form class=" form-horizontal" method="post" enctype="multipart/form-data" id="userProfileForm" action="<?php echo base_url('admin/addusers') ?>">                    

                    <div class="form-group">
                      <div class="col-md-8">
                       First Name<input type="text"  class="form-control" name="first_name" placeholder="Enter First Name"> 
                        <div class="text-danger"><?= form_error('first_name'); ?></div>
                      </div>
                       <div class="form-group">
                      <div class="col-md-8">
                       Last Name<input type="text"  class="form-control" name="last_name" placeholder="Enter Last Name"> 
                        <div class="text-danger"><?= form_error('last_name'); ?></div>
                      </div>
                     <div class="form-group">
                      <div class="col-sm-8">
                       Email <input type="email"  class="form-control" name="email" placeholder="Enter Your Email Address">
                        <div class="text-danger"><?= form_error('email'); ?></div>
                      </div>
                     
                    </div>
                    </div>
                       <div class="form-group">
                     
                      <div class="col-md-8">
                       Image <input type="file"  class="form-control" name="image">
                        <div class="text-danger"><?= form_error('image'); ?></div>
                      </div>
                      <div class="col-sm-8">          
                        Permanent Address <textarea class="form-control" name="address"></textarea>
                         <div class="text-danger"><?= form_error('address'); ?></div>
                      </div>
                    </div>
                    
                     <div class="form-group">
                      <div class="col-sm-8">
                       Joining Date <input type="date"  class="form-control" name="joining_date" Placeholder="DD/MM/YYYY">
                        <div class="text-danger"><?= form_error('joining_date'); ?></div>
                      </div>
                      <div class="col-sm-8">
                       Batch Time<input type="time"  class="form-control" name="batch_time" Placeholder="h:mm:ss">
                        <div class="text-danger"><?= form_error('batch_time'); ?></div>
                      </div>
                    </div>
                     <div class="form-group">
                      <div class="col-sm-8">
                       Contact No. <input type="text"  class="form-control" name="contact_no" placeholder="Enter Your Contact No">
                        <div class="text-danger"><?= form_error('contact_no'); ?></div>
                      </div>
                      <div class="col-sm-8">
                       Aadhaar No./ID No. <input type="text"  class="form-control" name="aadhar_no" placeholder="Enter Your Aadhaar No/ID No">
                        <div class="text-danger"><?= form_error('aadhar_no'); ?></div>
                      </div>
                    </div>
                  <div class="form-group">
                      <div class="col-sm-8">
                       Fathers Name <input type="text"  class="form-control" name="father_name" placeholder="Enter Your Father's Name">
                        <div class="text-danger"><?= form_error('father_name'); ?></div>
                      </div>
                       <div class="col-sm-8">
                       Fathers Occuption <input type="text"  class="form-control" name="father_occ" placeholder="Enter Your Father's Occuption">
                        <div class="text-danger"><?= form_error('father_occ'); ?></div>
                      </div>
                    </div>  
                  
                       <div class="form-group">
                      <div class="col-sm-8">
                       Mothers Name <input type="text"  class="form-control" name="mother_name" placeholder="Enter Your Mother's Name">
                        <div class="text-danger"><?= form_error('mother_name'); ?></div>
                      </div>
                       <div class="col-sm-8">
                       Mothers Occuption <input type="text"  class="form-control" name="mother_occ" placeholder="Enter Your Mother's Occuption">
                        <div class="text-danger"><?= form_error('mother_occ'); ?></div>
                      </div>
                    </div>
                      <div class="form-group">
                      <div class="col-sm-8">
                       Date Of Birth <input type="date"  class="form-control" name="birth_date" Placeholder="DD/MM/YYYY">
                        <div class="text-danger"><?= form_error('birth_date'); ?></div>
                      </div>
                      <div class="col-sm-8">
                         Gender <input type="text"  class="form-control" name="gender" placeholder="" value="<?= $gender ?>"> 
                      <!--   Gender:    Male<input value="<?= $gender ?>"  type="radio" name="gender"  <?php //if($res['gender']=="male"){echo "checked";}?>/>
          Female<input <?php //if($res['gender']=="female"){echo "checked";}?> type="radio" name="gender" value="<?= $gender ?>"/>  -->
                        <div class="text-danger"><?= form_error('gender'); ?></div>
                      </div>
                    </div>


                     <div class="form-group" >
                       <div class="col-sm-8">
                    Status<select class="form-control"  name="status" id="status" required="" >
                      <?php
                        if($status){
                                $selected1 = "selected";
                                $selected2 = "";
                           }else{
                                $selected1 = "";
                                $selected2 = "selected";
                           }
                      ?>
                      <option <?php echo $selected1 ?> value="1">Active</option>
                      <option <?php echo $selected2 ?> value="0">Deactive</option>
                    </select>
                    <div class="text-danger"><?= form_error('status '); ?></div>
                      </div>
                </div>
                    <div class="form-group">
                      <div class="col-sm-8">
                    <!-- BloodGroup<select class="form-control"  name="blood_group" id="blood_group" >
                      <option value="">Select Blood Group</option>
                       <?php 
                       // foreach($userType as $key =>$value){
                       //     if($blood_group == $value->blood_group){
                       //          $selected = "selected";
                       //     }else{
                       //          $selected = "";
                       //     }
                       //    echo '<option '.$selected.' value="'.$value->blood_group.'">'.$value->blood_group.'</option>';
                       //  }
                       ?>
                    </select> -->
                   BloodGroup<select class="form-control" name="blood_group" >
							<!-- <option value="<?php //echo $userData->status    ?>" ></option> -->
              <option >Select Bloodgroup</option>
							<option value="O_positive">O+</option>
							<option value="O_negative">O-</option>
              <option value="A_positive">A+</option>
              <option value="A_negative">A-</option>
               <option value="B_positive">B+</option>
              <option value="B_negative">B-</option>
              <option value="AB_positive">AB+</option>
              <option value="AB_negative">AB-</option>
						  </select>
                        <div class="text-danger"><?= form_error('blood_group '); ?></div>
                      </div>
                      <div class="col-sm-8">
                        Blood Donation <input type="text"  class="form-control" name="blood_donation" placeholder="">
                        <div class="text-danger"><?= form_error('blood_donation'); ?></div>
                      </div>
                    </div>
                     
                    <div class="form-group">
                      <div class="col-sm-8">          
                        Description <textarea class="form-control" name="description"></textarea>
                         <div class="text-danger"><?= form_error('description'); ?></div>
                      </div>
                    </div>

                    <div class="form-group">        
                      <div class="col-sm-offset-2 col-sm-12">
                      <input type="hidden" name="date" value="<?php echo date('d-m-Y'); ?>">
                        <button type="submit" class="btn btn-info">Submit</button>
                        <span id="buttonMessageUP"></span>
                      </div>
                    </div>
                  </form>
				 
                </div>
		      
		      
		      
		      
		      <!--*****END********-->

	   </div>

        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>
		
		<script type="text/javascript">
		
			$("#frmregistration").click(function(){
				$('form[id="registration_form"]').validate({
					
					var  waitimg = '<?php echo base_url('uploads/ashg/loader.gif') ?>' ;
				rules: {
					firstName: 'required',
					lastName: 'required',
					contactNo: 'required',
					inputEmail: 'required',
					inputPassword: 'required',
					confirmPassword: 'required',
					userAddress: 'required',
				  },
				   errorPlacement: function(){
						return false;   /*suppresses error message text*/
					},
				  submitHandler: function(form) {
					return true ;
				  }
				});
			});
         </script>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->
<script>

  $(document).ready(function() {
    $('#dataTable').DataTable( {
        initComplete: function () {
          this.api().columns(4).every( function () {
            var column = this;
            var select = $('<select><option value="">Blood Group</option></select>')
              .appendTo( $(column.header()).empty() )
              .on( 'change', function () {
                var val = $.fn.dataTable.util.escapeRegex(
                  $(this).val()
                );
                column
                  .search( val ? '^'+val+'$' : '', true, false )
                  .draw();
              } );
            column.data(1).unique().sort().each( function ( d, j ) {
              select.append( '<option value="'+d+'">'+d+'</option>' )
            } );
          } );
        }
      } );
      
  });
</script>