    <div id="wrapper">
     <?php include "sidebar.php" ;?>
      <div id="content-wrapper">
        <div class="container-fluid">
          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
             Events</div>  
             
                                   <!--------------show alert message----------------------->
            
            <?php if($error=$this->session->flashdata('success')): ?>
            <div class="alert alert-success">
            <?= $error; ?>
            </div>
            <?php endif; ?>
            
             <?php if($error=$this->session->flashdata('failure')): ?>
            <div class="alert alert-danger">
            <?= $error; ?>
            </div>
            <?php endif; ?>
            
    <!----------------end show alert message------------------>
             
               <div class="card-header"><a href="<?= base_url('Admin/addevents'); ?>"><button class="btn btn-default">Add Events</button></a></div>
               
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>SN.</th>
                      <th>Title</th>
                      <th>Image</th>
                      <th>Event Date</th>
                      <th>Event Time</th>
                      <th>Address</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                    <th>SN.</th>
                      <th>Title</th>
                      <th>Image</th>
                      <th>Event Date</th>
                      <th>Event Time</th>
                      <th>Address</th>
                      <th>Action</th>
                    </tr>
                  </tfoot>
                  <tbody>
				  <?php foreach ($eventsdata as $key => $value) { 
				  
				  $imagepath=$value->image_path;
				  $eventtime=$value->eventtime;
				  ?>
				  

					  <td><?php echo $key + 1 ?></td>
					  <td><?php echo $value->title  ?></td>
					  <td><img width="30px" height="30px" src="<?php echo $imagepath; ?>"/></td>
                                          <td><?php echo $value->eventdate ?></td>
                                          <td><?php echo $eventtime  ?></td>
					  <td><?php echo $value->address  ?></td>
					  
					   <td><a href="<?php echo base_url().'admin/updateevents/'.$value->id ?>">Edit</a>&nbsp; <a href="<?php echo base_url().'admin/deleteevents/'.$value->id ?>">Delete</a></td>
                    </tr>
				  <?php } ?>
                 
                  </tbody>
                </table>
              </div>
            </div>
          </div>
		  
		   <!-- Area Chart Example-->
          <div class="card mb-3 display-none">
            <div class="card-header">
              <i class="fas fa-chart-area"></i>
              Area Chart Example</div>
            <div class="card-body">
              <canvas id="myAreaChart" width="100%" height="30"></canvas>
            </div>
            <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
          </div>
        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->
