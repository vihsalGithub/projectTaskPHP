<style type="text/css">
  .deactivate{
        padding: 1px 5px;
    background: red;
    color: #fff;
  }
  .activate{
       padding: 1px 5px;
    background: #28a745;
    color: #fff;
  }
</style>
    

    <div id="wrapper">
     <?php include "sidebar.php" ;?>
      <div id="content-wrapper">
        <div class="container-fluid">
          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              <?php echo $page_title ?></div>
              <?php //print_r($userData[0]) ?> 
            <div class="card-body">
              <div class="table-responsive">
                <p><b class="text-success"><?php echo $this->session->flashdata('messageRes'); ?></b></p>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>SN</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Contact</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>SN</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Contact</th>
                      <th>Status</th>
                    </tr>
                  </tfoot>
                  <tbody>

                    <?php
                      foreach ($userData as $key => $dataValue) {
                       ?>
                       <tr>
                         <td><?php echo $key+1 ?></td>
                         <td><?php echo $dataValue->name ?></td>
                         <td><?php echo $dataValue->email ?></td>
                         <td><?php echo $dataValue->contact_no ?></td>
                         <td><?php echo $dataValue->reg_date ?></td>
                       </tr>
                    <?php
                      }
                    ?>
                      
                  </tbody>
                </table>
              </div>
            </div>
          </div>
		  
		   <!-- Area Chart Example-->
          <div class="card mb-3 display-none">
            <div class="card-header">
              <i class="fas fa-chart-area"></i>
              Area Chart Example</div>
            <div class="card-body">
              <canvas id="myAreaChart" width="100%" height="30"></canvas>
            </div>
            <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
          </div>
        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->
    <!-- <script type="text/javascript">
     $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#dataTable thead tr').clone(true).appendTo( '#dataTable thead' );
    $('#dataTable thead tr:eq(1) th').each( function (i) {
            var title = $(this).text();
            $(this).html( '<input type="text" placeholder="Search '+title+'" />' );
     
            $( 'input', this ).on( 'keyup change', function () {
                if ( table.column(i).search() !== this.value ) {
                    table
                        .column(i)
                        .search( this.value )
                        .draw();
                }
            } );
        } );
     
        var table = $('#dataTable').DataTable( {
            orderCellsTop: true,
            fixedHeader: true
        } );
    } );
    </script> -->
