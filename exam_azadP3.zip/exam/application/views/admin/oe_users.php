<style type="text/css">
  .deactivate{
        padding: 1px 5px;
    background: red;
    color: #fff;
  }
  .activate{
       padding: 1px 5px;
    background: #28a745;
    color: #fff;
  }
</style>
    

    <div id="wrapper">
     <?php include "sidebar.php" ;?>
      <div id="content-wrapper">
        <div class="container-fluid">
          <!-- DataTables Example -->

          <nav class="navbar navbar-expand navbar-dark bg-dark static-top mb20">
   <ul class="navbar-nav ml-auto ml-md-0">
       <li class="nav-item dropdown no-arrow">
        <a class="nav-link  " href="<?php echo base_url('admin/examsusers') ?>">
         All Users
        </a>
      </li>|
       <li class="nav-item dropdown no-arrow">
        <a class="nav-link  manuactive" href="<?php echo base_url('admin/examsusers/1') ?>">
         Activated User
        </a>
      </li> 
      <li class="nav-item dropdown no-arrow">
        <a class="nav-link  " href="<?php echo base_url('admin/examsusers/2') ?>">
         Deacivated User
        </a>
      </li>
   </ul>
</nav>
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              <?php echo $messageTitle ?></div>
            <div class="card-body">
              <div class="table-responsive">
                <p><b class="text-success"><?php echo $this->session->flashdata('messageRes'); ?></b></p>
                <table class="table table-bordered" id="example" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>SN</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Contact</th>
                      <th>Package</th>
                      <th>Amount (INR)</th>
                      <th>Status</th>
                      <th>Payment Status</th>
                     <!--  <th>User Token</th> -->
                      <th>Activate</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>SN</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Contact</th>
                      <th>Package</th>
                      <th>Amount (INR)</th>
                      <th>Status</th>
					            <th>Payment Status</th>
<!--                       <th>User Token</th>
 -->                      <th>Activate</th>
                    </tr>
                  </tfoot>
                  <tbody>
				  <?php foreach ($userData as $key => $value) { ?>
                    <tr>
					  <td><?php echo $key + 1 ?></td>
                      <td><?php echo $value->name  ?></td>
                      <td><?php echo $value->email  ?></td>
            <td><?php echo $value->contact_no  ?></td>
            <td><?php 
                              $oe_package = $this->db->select('name')->from('oe_package ')->where('pack_id',$value->productinfo)->get()->row();
                            echo $oe_package->name ;
                             ?></td>
            <?php
              $payments = $this->db->select('*')->from('payments')->where(array('user_id'=>$value->user_id))->get()->row() ;
              echo ' <td>'.$payments->amount.'</td>';
            ?>
					  <td><?php  if($value->status){
						      echo '<label class="activate">Activate</label>';
								}else{
								 echo '<label  class="deactivate">Deactive</label>';	
								}  ?>
					  </td>
						<td><?php  if($value->payment_status){
							      echo '<label class="activate">Activate</label>';
                }else{
                 echo '<label  class="deactivate">Deactive</label>';  
                }  ?>
						</td>
           <!--  <td><?php echo $value->reg_token  ?></td> -->
					  <!--  <td><a href="<?php echo base_url('admin/examuserstatus').'/'.base64_encode($value->user_id) ?>">View Details</a>
					   </td> -->
             <td>
              <?php if($value->payment_status){?>
                 <b class="text-success">Activated</b>
            <?php }else{ ?>
              <a href="<?php echo base_url('admin/examuseractivate').'/'.base64_encode($value->user_id) ?>">Acivate</a>

            <?php } ?>

             </td>
                    </tr>
				  <?php } ?>
                      
                  </tbody>
                </table>
              </div>
            </div>
          </div>
		  
		  
<script type="text/javascript">
  $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
             'csv', 'excel', 'pdf', 'print'
        ]
    } );
} );
</script>
        <!-- /.container-fluid -->
        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>
    
      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->