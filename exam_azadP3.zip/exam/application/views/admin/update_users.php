    <div id="wrapper">

     <?php include "sidebar.php" ;?>
	  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	 <style type="text/css" rel="http://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css"></style>
      <div id="content-wrapper">

        <div class="container-fluid">
			 <?php if($error=$this->session->flashdata('success')): ?>
            <div class="alert alert-success">
            <?= $error; ?>
            </div>
            <?php endif; ?>
            
             <?php if($error=$this->session->flashdata('failure')): ?>
            <div class="alert alert-danger">
            <?= $error; ?>
            </div>
            <?php endif; ?>
            
            <?php
            foreach($usersdata as $row){
            $first_name=$row->first_name;
            $last_name=$row->last_name;
            $email=$row->email;
            $imagepath=$row->image;
            $address=$row->address;
            $joining_date=$row->joining_date;
            $batch_time=$row->batch_time;
            $contact_no=$row->contact_no;
            $aadhar_no=$row->aadhar_no;
            $father_name=$row->father_name;
            $father_occ=$row->father_occ;
            $mother_name=$row->mother_name;
            $mother_occ=$row->mother_occ;
            $birth_date=$row->birth_date;
            $gender=$row->gender;
            $status=$row->status;
            $blood_group=$row->blood_group;
            $blood_donation=$row->blood_donation;
            $description=$row->description;
            $user_id=$row->user_id;
            
            }
            
            ?>
		
			<div class="row">
					<div class="col-lg-12">
						<div class="panel panel-default margin20">
							<div class="panel-heading border   padding10 whitebg" style="margin:20px 0px;">
								<h4>Update Users</h4> 
							</div>
							<div class="panel-body">
								<div class="row">
									<div class="col-lg-12">
									<?php echo form_open_multipart("Admin/updateusersbyid/{$user_id}"); ?>
									</div>

									<div class="claer-fix"></div>
										  <div class="col-md-4">
										   <div class="form-group">
											Image <br><img src="<?= $imagepath; ?>" style="width:50px; height:50px;">
											</div>
										  </div>
										  <div class="col-md-4">
										   <div class="form-group">
											upload Image <input type="file"  class="form-control" name="image" ><?= form_error('image'); ?>
											</div>
										  </div>
										  <div class="col-sm-4">          
											Permanent Address <input class="form-control"  value="<?= $address ?>" name="address" >
											 <div class="text-danger"><?= form_error('address'); ?></div>
										  </div>
									<div class="claer-fix"></div>
									<div class="col-md-4">
										<div class="form-group">
										   First Name<input type="text"  class="form-control" name="first_name" placeholder="Enter First Name" value="<?= $first_name ?>"> 
											<div class="text-danger"><?= form_error('first_name'); ?></div>
										 </div>
									 </div>
										<div class="col-md-4">
									   <div class="form-group">
										   Last Name<input type="text"  class="form-control" name="last_name" placeholder="Enter Last Name" value="<?= $last_name ?>"> 
											<div class="text-danger"><?= form_error('last_name'); ?></div>
										</div>
										 </div>
										<div class="col-sm-4">
										<div class="form-group">
										   Email <input type="email"  class="form-control" name="email" placeholder="Enter Your Email Address" value="<?= $email ?>">
											<div class="text-danger"><?= form_error('email'); ?></div>
										  </div>
										</div>
									<div class="claer-fix"></div>
										<div class="col-sm-3">
											<div class="form-group">
										   Joining Date <input type="text"  class="form-control" name="joining_date" Placeholder="DD/MM/YYYY" value="<?= $joining_date ?>">
											<div class="text-danger"><?= form_error('joining_date'); ?></div>
											</div>
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												Batch Time<input type="text"  class="form-control" name="batch_time" Placeholder="h:mm:ss" value="<?= $batch_time ?>">
												<div class="text-danger"><?= form_error('batch_time'); ?></div>
											</div>
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												Contact No. <input type="text"  class="form-control" name="contact_no" placeholder="Enter Your Contact No" value="<?= $contact_no ?>">
												<div class="text-danger"><?= form_error('contact_no'); ?></div>
											</div>
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												Aadhaar No./ID No. <input type="text"  class="form-control" name="aadhar_no" placeholder="Enter Your Aadhaar No/ID No" value="<?= $aadhar_no ?>">
											<div class="text-danger"><?= form_error('aadhar_no'); ?></div>
											</div>
										</div>
									<div class="claer-fix"></div>
										<div class="col-sm-6">
											<div class="form-group">
										   Fathers Name <input type="text"  class="form-control" name="father_name" placeholder="Enter Your Father's Name" value="<?= $father_name ?>">
											<div class="text-danger"><?= form_error('father_name'); ?></div>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
										   Fathers Occuption <input type="text"  class="form-control" name="father_occ" placeholder="Enter Your Father's Occuption" value="<?= $father_occ ?>">
											<div class="text-danger"><?= form_error('father_occ'); ?></div>
											</div>
										</div>
									<div class="claer-fix"></div>
										<div class="col-sm-6">
											<div class="form-group">
										   Mothers Name <input type="text"  class="form-control" name="mother_name" placeholder="Enter Your Mother's Name" value="<?= $mother_name ?>">
											<div class="text-danger"><?= form_error('mother_name'); ?></div>
											</div>
										 </div>
										<div class="col-sm-6">
											<div class="form-group">
											Mothers Occuption <input type="text"  class="form-control" name="mother_occ" placeholder="Enter Your Mother's Occuption" value="<?= $mother_occ ?>">
											<div class="text-danger"><?= form_error('mother_occ'); ?></div>
											</div>
										</div>
									<div class="claer-fix"></div>
										<div class="col-sm-6">
											<div class="form-group">
										   Date Of Birth <input type="text"  class="form-control datepicker" name="birth_date" Placeholder="DD/MM/YYYY" value="<?= $birth_date ?>">
											<div class="text-danger"><?= form_error('birth_date'); ?></div>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
													<?php 
															if($gender == 'female'){
																  $feCheck = 'checked="checked"';
																  $mdCheck = '';
															}else{
																 $feCheck = '';
																  $mdCheck = 'checked="checked"';
															}
													?>
													Male<input value="male"  <?php echo $mdCheck  ?> type="radio" name="gender"  />
													Female<input value="female" <?php echo $feCheck  ?> type="radio" name="gender" />  
											<div class="text-danger" ><?= form_error('gender'); ?></div>
											</div>
										</div>
										
									<div class="claer-fix"></div>
										
										<div class="col-sm-4">
											<div class="form-group">
											Status
											<select class="form-control"  name="status" id="status" required="" >
											  <?php
												if($status){
														$selected1 = "selected";
														$selected2 = "";
												   }else{
														$selected1 = "";
														$selected2 = "selected";
												   }
											  ?>
											  <option <?php echo $selected1 ?> value="1">Active</option>
											  <option <?php echo $selected2 ?> value="0">Deactive</option>
											</select>
											<div class="text-danger"><?= form_error('status '); ?></div>
											</div>
										</div>
										
										<div class="col-sm-4">
											<div class="form-group">
											BloodGroup
											<select class="form-control"  name="blood_group" id="blood_group" >
											  <option value="">Select Blood Group</option>
											   <?php foreach($userData as $key =>$value){
												   if($blood_group == $value->blood_group){
														$selected = "selected";
												   }else{
														$selected = "";
												   }
												  echo '<option '.$selected.' value="'.$value->blood_group.'">'.$value->blood_group.'</option>';
												}
											   ?>
											</select>
											<div class="text-danger"><?= form_error('blood_group '); ?></div>
										  </div>
										</div>
										
										<div class="col-sm-4">
											<div class="form-group">
											Blood Donation <input type="text"  class="form-control" name="blood_donation" placeholder="" value="<?= $blood_donation ?>">
											<div class="text-danger"><?= form_error('blood_donation'); ?></div>
										  </div>
										</div>
										
									<div class="claer-fix"></div>
										<div class="col-sm-12">          
											<div class="form-group">
											Description <textarea class="form-control" name="description" ><?= $description ?></textarea>
											 <div class="text-danger"><?= form_error('description'); ?></div>
										  </div>
										</div>
									<div class="claer-fix"></div>
									<div class="col-lg-12">
										<div class="form-group">        
										  <div class="col-sm-offset-2 col-sm-12">
											<button type="submit" class="btn btn-success">Update</button>
											<span id="buttonMessageUP"></span>
										  </div>
										</div>
										</form>
									</div>
					
								</div>
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>
		
		<script type="text/javascript">
		
			$("#frmregistration").click(function(){
				$('form[id="registration_form"]').validate({
					
					var  waitimg = '<?php echo base_url('uploads/ashg/loader.gif') ?>' ;
				rules: {
					firstName: 'required',
					lastName: 'required',
					contactNo: 'required',
					inputEmail: 'required',
					inputPassword: 'required',
					confirmPassword: 'required',
					userAddress: 'required',
				  },
				   errorPlacement: function(){
						return false;   /*suppresses error message text*/
					},
				  submitHandler: function(form) {
					return true ;
				  }
				});
			});
         </script>
		 <!--******************************"calender Script"*****************************-->
		 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		<script>
                  jQuery(document).ready(function($) {
                      /* $(".datepicker").datepicker({ dateFormat: "yy-mm-dd" }); */
					  $( ".datepicker" ).datepicker({
						  changeMonth: true,
						  changeYear: true,
						  dateFormat: "dd-mm-yy"
						});
                  });
              </script> 
		 <!--******************************"calender Script"*****************************-->
		 
      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->
