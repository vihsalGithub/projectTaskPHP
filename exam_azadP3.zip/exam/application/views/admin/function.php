 <---------controller------------->

/**********************"library"********************/
    /*rb*/  -> isko admin controller me search krna pura function isi k andar he
    
    
  public function library(){
    if ($this->admin_model->admin_checkloggedin()){ 
         $data['userData'] = $this->my_model->getSingeleTable(USERS);
          // $data['users'] = $this->db->select('*')->from('users')->order_by('user_id','ASCE')->get()->result() ;
    // print_r($data['users']); die;
         $this->load->view('users/header.php');
         $this->load->view('admin/library.php',$data);
         $this->load->view('users/footer.php');
    }else{
      $this->session->set_flashdata('adUSerPassFlachCheck','<div class="alert alert-danger alert-dismissible">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>User name or password is wrong
      </div>');
      redirect('admin/login');
    }
  }
public function user_fees(){

    $userid = $_SESSION['user_id'] ;
    if ($this->admin_model->admin_checkloggedin($userid)){ 
    //$data['userdata'] = $this->db->select('*')->from('users')->where('user_id',$userid)->get()->row() ;
      $data['userData'] =  $this->db->select('*')->from('users')->join('library_fees', 'users.user_id = library_fees.user_id', 'inner')->order_by("id", "desc")->get()->result();

    // $data['payments'] = $this->db->select('*')->from('library_fees')->where('user_id',$userid)->get()->result() ;
    $this->load->view('admin/header');
    $this->load->view('admin/libraryuser_fees',$data);
    $this->load->view('admin/footer');
  }

  }
public function addfees(){

 $this->load->view('users/header.php');
      $this->load->view('admin/addlib_fees.php',$data);
      $this->load->view('users/footer.php');
    //    $condition =(
    //  ($this->session->userdata('logintype') == 'admin') && 
    //  ($this->session->userdata('status') == 1) && 
    //  ($this->session->userdata('logged_in') == 1 )
    // );
    // if($condition){ 
    //  $data['userData'] = $this->my_model->getSingeleTable(USERS);
  
    //  // 


    //  $this->load->view('users/header.php');
    //  $this->load->view('admin/addlib_fees.php',$data);
    //  $this->load->view('users/footer.php');

    // }else{
    //  redirect('admin/login');
    // }

}

public function addlibraryfee(){

 $condition =(
      ($this->session->userdata('logintype') == 'admin') && 
      ($this->session->userdata('status') == 1) && 
      ($this->session->userdata('logged_in') == 1 )
    );

if($condition){ 
  

$user_id = base64_decode($userid) ;
      $userData = $this->db->select('*')->from('users')->where('user_id',$user_id)->get()->row();

 if(count($userData)){

                    $userUpdate = array('status'=>1,'payment_status'=>1 );
                  $this->db->where('user_id',$user_id) ;
                  $this->db->update('users',$userUpdate) ;


              if($userData->package_type == 1){
                    $exp_date = date('d-m-Y', strtotime("+30 days")) ;
                  }elseif($userData->package_type == 2){
                    $exp_date = date('d-m-Y', strtotime("+60 days")) ;
                  }elseif($userData->package_type ==3){
                    $exp_date = date('d-m-Y', strtotime("+90 days")) ;
                  }
                 }

$reg_charge =  $this->db->select('cahrge_rupee')->from('registration_charge')->where(array('charge_id' => 3 ))->get()->row() ;
       $regpackage =  $this->db->select('*')->from('lib_package')->where(array('pack_id' => $userData->package_type ))->get()->row() ;

      $amount= number_format((float)$number, 2, '.', '');

      // $firstname = $this->input->post('firstname');
      // $email =  $this->input->post('email');
      // $package_type =  $this->input->post('package_type');
      // $exp_date =  $this->input->post('exp_date');
      // $productinfo =  $this->input->post('productinfo');
      // $amount =  $this->input->post($amount);
      // $exp_date =  $this->input->post($exp_date);


$data = array(
            'user_id'=> $user_id, 
                'orderid'=> time() ,
                'amount'=> $amount ,
                'productinfo'=> $package_type  ,
                'first_name'=> $first_name ,
                'email'=> $email ,
                'status'=> 'success' ,
                'signup_type'=> 1 ,
                'package_type'=>$package_type ,
                'date'=>date("d-m-Y")   ,
                'exp_date'=> $expiradate  ,
            ) ; 

  $this->db->insert('library_fees',$data) ;

  redirect('admin/addfees');
      $this->load->view('users/header.php');
      $this->load->view('admin/addlib_fees.php',$data);
      $this->load->view('users/footer.php');
}else{
      redirect('admin/login');
    }

}

  public function addusers(){
    
   if($this->form_validation->run('users_validation'))
        {
          //$data['userType'] = $this->db->select('blood_group')->from('blood_group')->get()->result() ;
          // $data['userData'] = $this->my_model->getSingeleTable(blood_group);
        $this->load->view('users/header.php');
            $this->load->view('admin/add_users.php');
            $this->load->view('users/footer.php');

           $data = $this->input->post();
        // print_r($data);
        //   exit();
          
          $target_dir = './uploads/';
                $filename=time().'_'.$_FILES["image"]["name"];
                $target_file = $target_dir.$filename;

                if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                   $image_path=base_url('uploads/'.$filename);
                  $data['image']=$image_path;
                }
                    
          $this->load->model('admin_model');  
          if($this->admin_model->add_users( $data))
          return redirect($this->load->view('admin/add_users.php'));
          
          }else{
          $this->load->view('users/header.php');
            $this->load->view('admin/add_users.php');
            $this->load->view('users/footer.php');
          }   
  
  }

public function updateusers()
  {             
  
   $id = $this->uri->segment(3);
           // echo"$id";
           
           $this->load->model('admin_model');  
     $data['usersdata']=$this->admin_model->selectusersbyid($id);
                    
            $this->load->view('users/header.php');        
      return $this->load->view('admin/update_users',$data);
      $this->load->view('users/footer.php');
  }



  public function updateusersbyid($userid)
  {             
   // echo"$userid";
   // exit();
  if($this->form_validation->run('users_validation'))
   {
   $data = $this->input->post();
   //echo"$data";
   //exit();
          $target_dir = './uploads/';
                $filename=time().'_'.$_FILES["image"]["name"];
                $target_file = $target_dir.$filename;

                if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                   $image_path=base_url('uploads/'.$filename);
                 $data['image']=$image_path;
                } 
   $this->load->model('admin_model');  
    if($this->admin_model->update_usersbyid($userid,$data)){
    $this->session->set_flashdata('success','Update Successfull');
    return redirect('Admin/library');
    }else{
    $this->session->set_flashdata('failure','Not Updated');
    return redirect('Admin/library');
    }   
    }else{
          $this->load->view('users/header.php');        
          $this->load->view('admin/update_users');
          $this->load->view('users/footer.php');
          }  
  }

public function deleteusers($userid)
  {
    
      //echo $userid ;
      $this->db->where('user_id',$userid) ;
    $this->db->update('users',array('delete_status' =>0));
    // $this->session->set_flashdata('addusersSession', '<p><b class="text-danger">Deleted</b></p>');
              redirect('admin/library');
    // $json = array('status'=>1 ) ;
    // echo json_encode($json);


  }


    /*rb*/ 

<------Admin_model------>
 
  public function add_users($data)
    {

     if($this->db->insert('users',$data)){
     $this->session->set_flashdata('success','User Added Successfully');
     return redirect('Admin/addusers');
     }else{
     $this->session->set_flashdata('failure','User Not Added');
     return redirect('Admin/addusers');
     }
       
    }
     public function selectusersbyid($user_id)
    {
      $query = $this->db->where('user_id',$user_id)->get('users');  
         return $query->result(); 
    }

public function update_usersbyid($userid,array $product)
    {
    return $this->db->where('user_id',$userid)
              ->update('users',$product);
          
    }

    public function delusers($userid)
    {
    return $this->db->delete('users',['user_id'=>$userid]);
        
    }
     /* rb */


<--------------------- * Admin view *----------------------->

1) add_user library
2) add_user 
3) userdetails
4) update_users
5)library
6)libraryuser_fees
7)addlib_fees