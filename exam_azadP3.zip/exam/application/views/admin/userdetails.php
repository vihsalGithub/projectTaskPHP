  
    <style type="text/css">
        .form-group{
          font-size: 20px;
        }
        .form-group label{
          font-weight: bold
        }
    </style>
    
    <div id="wrapper">

     <?php include "sidebar.php" ;?>
      <div id="content-wrapper">

        <div class="container-fluid">
            <div class="border margin20  padding10 whitebg col-xl-12 col-md-12  col-sm-12">
                   <h2>Profile</h2> 
                  <?php echo $this->session->flashdata('adUSerPassFlachCheck') ; ?>

           </div>
             <!-- Icon Cards-->
            <div class="row border margin20  padding10 ">
           
          <?php //print_r($userData) ; ?>
          <!--*****START*******-->
          
          

           
            <div class="col-sm-12" style="margin-bottom: 20px;">          
              <img class=" imgcenter " width="100px" src="<?php echo base_url().'/'.$userData->image ?>">
            </div>
            <div class="col-sm-6">          
                    <div class="form-group">
                      <label class="control-label">Name:</label> 
                       <?php echo $userData->first_name.' '.$userData->last_name ?> 
                     </div>
            </div>
            <div class="col-sm-6"> 
                    <div class="form-group">
                      <label class="control-label" for="useremail">Email:</label> 
                        <?php echo $userData->email ?>
                    </div>
            </div>
             <div class="col-sm-6"> 
                      <div class="form-group">
                      <label class="control-label" for="fatehername">Contact No. :</label>
                        <?php echo $userData->contact_no ?>
                    </div>  
            </div>
            <div class="col-sm-6">                     
                      <div class="form-group">
                      <label class="control-label" for="fatehername">Aadhaar No./ID No. :</label>
                        <?php echo $userData->aadhar_no ?>
                    </div>
            </div>
            <div class="col-sm-6"> 
                      <div class="form-group">
                      <label class="control-label" for="fatehername">Date Of Birth :</label>
                        <?php echo $userData->birth_date ?>
                    </div>
            </div>
            <div class="col-sm-6"> 
                    <div class="form-group">
                      <label class="control-label" for="fatehername">Father Name:</label>        
                        <?php echo $userData->father_name?>
                    </div>
            </div>
            <div class="col-sm-6"> 
                   <div class="form-group">
                       <label class="control-label"> Fathers Occuption :</label> 
                       <?php echo $userData->father_occ ?> 
                    </div>
            </div>
            <div class="col-sm-6"> 
                    <div class="form-group">
                      <label class="control-label" for="useremail"> Mothers Name :</label> 
                        <?php echo $userData->mother_name ?>
                    </div>
            </div>
            <div class="col-sm-6"> 
                    <div class="form-group">
                      <label class="control-label" for="fatehername">Mothers Occuption :</label>         
                        <?php echo $userData->mother_occ?>
                    </div>
            </div>
            <div class="col-sm-6"> 
                    <div class="form-group">
                      <label class="control-label" for="Pincode">Gender :</label>
                       <?php echo $userData->gender  ?>
                    </div>
            </div>
            <div class="col-sm-6">              
                    <div class="form-group">
                      <label class="control-label" for="userstatus">BloodGroup :</label>
                      <?php echo $userData->blood_group    ?> 
                    </div>
            </div>
            <div class="col-sm-6"> 
                      <div class="form-group">
                      <label class="control-label" for="fatehername">Joining Date :</label>
                        <?php echo $userData->joining_date ?>
                    </div>
            </div>
            <div class="col-sm-6"> 
                      <div class="form-group">
                      <label class="control-label" for="fatehername">Batch Time :</label>
                        <?php echo $userData->batch_time ?>
                    </div>
            </div>
            <div class="col-sm-6"> 
                        <div class="form-group">
                      <label class="control-label" for="userstatus">Status:</label>
                      <?php echo $userData->status    ?> 
                    </div>
            </div>
            <div class="col-sm-12"> 
                <div class="form-group">
                 <button class="btn btn-info" style="margin-bottom: 5px;"><a style="color: #fff;" href="<?php echo base_url('admin/updateusers/').$userData->user_id ?>">Edit</a></button>
                </div>
            </div>

                
          
          
          
          
          <!--*****END********-->

     </div>

        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>
    
    <script type="text/javascript">
    
      $("#frmregistration").click(function(){
        $('form[id="registration_form"]').validate({
          
          var  waitimg = '<?php echo base_url('uploads/ashg/loader.gif') ?>' ;
        rules: {
          firstName: 'required',
          lastName: 'required',
          contactNo: 'required',
          inputEmail: 'required',
          inputPassword: 'required',
          confirmPassword: 'required',
          userAddress: 'required',
          },
           errorPlacement: function(){
            return false;   /*suppresses error message text*/
          },
          submitHandler: function(form) {
          return true ;
          }
        });
      });
         </script>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->
