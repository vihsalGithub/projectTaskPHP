
    <div id="wrapper">
     <?php include "sidebar.php" ;?>
      <div id="content-wrapper">
        <div class="container-fluid">
          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              Members Information</div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>SN.</th>
                      <th>Image</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Contact</th>
                      <th>Qualification</th>
                      <th>Status</th>
                      <th>Details</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>SN</th>
                      <th>Image</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Contact</th>
                      <th>Qualification</th>
					  <th>Status</th>
                      <th>Details</th>
                    </tr>
                  </tfoot>
                  <tbody>
				  <?php foreach ($userData as $key => $value) { ?>
                    <tr>
					  <td><?php echo $key + 1 ?></td>
					  <td><img width="30px" height="30px" src="<?php 
							if($value->image){
								echo base_url().'/'.$value->image ;
							}else{
								echo base_url().'/'.LOGOURL ;
							}
							?>"/></td>
                      <td><?php echo $value->first_name .' '.$value->first_name  ?></td>
                      <td><?php echo $value->email  ?></td>
					  <td><?php echo $value->contact_no  ?></td>
					  <td><?php echo $value->qualifiaction  ?></td>
					  <td><?php  if($value->status){
						      echo '<label>Activat</label>';
								}else{
								 echo '<label>Deactive</label>';	
								}  ?></td>
					   <td><a href="<?php echo base_url('admin/userdetails').'/'.base64_encode($value->user_id) ?>">View Details</a></td>
                    </tr>
				  <?php } ?>
                 
                  </tbody>
                </table>
              </div>
            </div>
          </div>
		  
		   <!-- Area Chart Example-->
          <div class="card mb-3 display-none">
            <div class="card-header">
              <i class="fas fa-chart-area"></i>
              Area Chart Example</div>
            <div class="card-body">
              <canvas id="myAreaChart" width="100%" height="30"></canvas>
            </div>
            <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
          </div>
        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->
