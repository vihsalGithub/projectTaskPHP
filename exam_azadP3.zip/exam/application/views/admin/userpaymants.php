
    <div id="wrapper">

     <?php include "sidebar.php" ;?>
      <div id="content-wrapper">
        <div class="container-fluid">
      
             <!-- Icon Cards-->
          <div class="row">
		      <!--*****START*******-->
    		      <div class="border margin20  padding10 whitebg col-xl-11 col-md-11  col-sm-11">
                <h2>Exam User Paymants</h2> 
                  <div class="alert alert-success">
                      <p><b>Total Amount: Rs.</b><span><?php echo $totalAmount[0]->amount ; ?></span>&nbsp&nbsp&nbsp
                  <span><b>Total Active User:</b> <?php echo $totalActiveUser ; ?></span>&nbsp&nbsp&nbsp
                  <span><b>Total Deactive:</b> <?php echo $totalDeactiveUser ; ?></span>&nbsp&nbsp&nbsp
                  <span><b>Total User:</b> <?php echo $totalUser ; ?></span></p>
                    </div>
                  
                  <table class="table table-bordered" id="example" cellspacing="0">
                      <thead>
                      <tr>
                        <th>SN</th>
                        <th>User Name</th>
                        <th>Package</th>
                        <th>Amount(In INR)</th>
                        <th>Date</th>
                      </tr>
                      </thead>
                      <tfoot>
                      <tr>
                        <th>SN</th>
                        <th>User Name</th>
                        <th>Package</th>
                        <th>Amount(In INR)</th>
                        <th>Date</th>
                      </tr>
                      </tfoot>
                      <tbody>
                        <?php
                          foreach ($paymantsData as $key => $paymValue) {
                           ?>
                            <tr>
                            <td><?php echo $key+1 ?></td>
                            <td><?php echo $paymValue->name ?></td>
                            <td><?php 
                              $oe_package = $this->db->select('name')->from('oe_package ')->where('pack_id',$paymValue->productinfo)->get()->row();
                            echo $oe_package->name ;
                             ?></td>
                            <td><?php echo $paymValue->amount ?></td>
                            <td><?php echo $paymValue->date ?></td>
                          </tr>
                           <?php
                          }
                        ?>
                         
                      </tbody>
                  </table>

                <?php  // print_r($totalAmount[0]->amount) ;
                  //  echo count($paymantsData);
                   // echo $totalAmount;
                    //echo $totalActiveUser;
                 ?>
    				    
              </div>
		      <!--*****END********-->
	         </div>
        </div>

<script type="text/javascript">
  $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
             'csv', 'excel', 'pdf', 'print'
        ]
    } );
} );
</script>
        <!-- /.container-fluid -->
        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>
		
      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->
