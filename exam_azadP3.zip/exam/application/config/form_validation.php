<?php
$config=[
            'events_validation'=>[
                                [ 
                                'field'=>'title',
                                'label'=>'Event Title',
                                'rules'=>'required'
                                ],
                                [ 
                                'field'=>'eventdate',
                                'label'=>'Event date',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'eventtime',
                                'label'=>'Event Time',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'description',
                                'label'=>'Description',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'address',
                                'label'=>'Address',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'cpname',
                                'label'=>'Contact Persont Name',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'cpemail',
                                'label'=>'Contact Persont Email',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'cpcontact',
                                'label'=>'Contact Persont Contact',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'cpaddress',
                                'label'=>'Contact Persont Address',
                                'rules'=>'required'
                                ]
            
                      ],
                      
 
  'users_validation'=>[
                                [ 
                                'field'=>'first_name',
                                'label'=>'First Name',
                                'rules'=>'required'
                                ],
                                [ 
                                'field'=>'last_name',
                                'label'=>'Last Name',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'joining_date',
                                'label'=>' Joining Date',
                                'rules'=>'required'
                                ]
                                 ,
                                [ 
                                'field'=>'batch_time',
                                'label'=>' Batch Time',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'description',
                                'label'=>'Description',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'address',
                                'label'=>'Address',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'contact_no',
                                'label'=>'Contact No.',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'aadhar_no',
                                'label'=>'Aadhaar No./ID No.',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'father_name',
                                'label'=>'Fathers Name',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'father_occ',
                                'label'=>'Fathers Occuption',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'mother_name',
                                'label'=>'Mothers Name',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'mother_occ',
                                'label'=>'Mothers Occuption',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'birth_date',
                                'label'=>'Date Of Birth',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'gender',
                                'label'=>'Gender',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'blood_group',
                                'label'=>'BloodGroup',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'blood_donation',
                                'label'=>'Blood Donation',
                                'rules'=>'required'
                                ]
                                ,
                                [ 
                                'field'=>'status',
                                'label'=>'Status',
                                'rules'=>'required'
                                ]
            
            
                      ],

];


?>