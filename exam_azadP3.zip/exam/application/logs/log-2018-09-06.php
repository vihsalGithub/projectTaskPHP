<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-06 18:30:27 --> Severity: Notice --> Undefined variable: ques_id E:\xamppp\htdocs\lakhanpatel\application\controllers\Onlineexam.php 330
ERROR - 2018-09-06 18:30:27 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questionedit.php 20
ERROR - 2018-09-06 18:30:27 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questionedit.php 26
ERROR - 2018-09-06 18:30:27 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questionedit.php 32
ERROR - 2018-09-06 18:30:27 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questionedit.php 38
ERROR - 2018-09-06 18:30:27 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questionedit.php 44
ERROR - 2018-09-06 18:30:27 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questionedit.php 50
ERROR - 2018-09-06 18:30:27 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questionedit.php 56
ERROR - 2018-09-06 18:30:27 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questionedit.php 62
ERROR - 2018-09-06 18:30:27 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questionedit.php 68
ERROR - 2018-09-06 18:30:27 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questionedit.php 75
ERROR - 2018-09-06 18:30:27 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questionedit.php 81
ERROR - 2018-09-06 18:30:27 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questionedit.php 87
ERROR - 2018-09-06 18:30:27 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questionedit.php 93
ERROR - 2018-09-06 18:30:27 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questionedit.php 99
ERROR - 2018-09-06 18:30:27 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questionedit.php 105
ERROR - 2018-09-06 18:30:27 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questionedit.php 111
ERROR - 2018-09-06 18:30:27 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questionedit.php 114
ERROR - 2018-09-06 19:03:10 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 26
ERROR - 2018-09-06 19:03:10 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 26
ERROR - 2018-09-06 19:03:10 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 26
ERROR - 2018-09-06 19:03:10 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 26
ERROR - 2018-09-06 19:03:10 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 26
ERROR - 2018-09-06 19:03:10 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 26
ERROR - 2018-09-06 19:03:10 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 26
ERROR - 2018-09-06 19:03:10 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 26
ERROR - 2018-09-06 19:03:10 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 26
ERROR - 2018-09-06 19:04:03 --> Severity: Parsing Error --> syntax error, unexpected '"' E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 17
ERROR - 2018-09-06 19:05:01 --> Severity: 4096 --> Object of class stdClass could not be converted to string E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 27
ERROR - 2018-09-06 19:05:01 --> Severity: Notice --> Object of class stdClass to string conversion E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 27
ERROR - 2018-09-06 19:05:28 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:05:28 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:05:28 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:05:28 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:05:28 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:05:28 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:05:28 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:05:28 --> Severity: Notice --> Trying to get property of non-object E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:06:46 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:06:46 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:06:46 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:06:46 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:06:46 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:06:46 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:06:46 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:06:46 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:06:46 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:07:58 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:07:58 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:07:58 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:07:58 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:07:58 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:07:58 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:07:58 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:07:58 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:07:58 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 29
ERROR - 2018-09-06 19:07:58 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 35
ERROR - 2018-09-06 19:07:58 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 35
ERROR - 2018-09-06 19:07:58 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 35
ERROR - 2018-09-06 19:07:58 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 35
ERROR - 2018-09-06 19:07:58 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 35
ERROR - 2018-09-06 19:07:58 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 35
ERROR - 2018-09-06 19:07:58 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 35
ERROR - 2018-09-06 19:07:58 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 35
ERROR - 2018-09-06 19:07:58 --> Severity: Notice --> Undefined property: stdClass::$Name E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_addqus.php 35
