<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-04 18:53:09 --> Severity: Parsing Error --> syntax error, unexpected '.' E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_allqus_sub.php 37
ERROR - 2018-09-04 18:53:26 --> Severity: Parsing Error --> syntax error, unexpected '.' E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_allqus_sub.php 37
ERROR - 2018-09-04 18:53:58 --> Severity: Parsing Error --> syntax error, unexpected '.' E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_allqus_sub.php 37
ERROR - 2018-09-04 19:28:32 --> Severity: Notice --> Undefined variable: id E:\xamppp\htdocs\lakhanpatel\application\controllers\Onlineexam.php 284
ERROR - 2018-09-04 19:28:32 --> Severity: Notice --> Undefined variable: quesWithSub E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_allqus_sub.php 31
ERROR - 2018-09-04 19:28:32 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_allqus_sub.php 31
ERROR - 2018-09-04 19:29:07 --> Severity: Notice --> Undefined variable: id E:\xamppp\htdocs\lakhanpatel\application\controllers\Onlineexam.php 284
ERROR - 2018-09-04 19:29:07 --> Severity: Warning --> Missing argument 4 for My_Model::getFilterTable(), called in E:\xamppp\htdocs\lakhanpatel\application\controllers\Onlineexam.php on line 284 and defined E:\xamppp\htdocs\lakhanpatel\application\core\MY_Model.php 93
ERROR - 2018-09-04 19:29:07 --> Severity: Notice --> Undefined variable: id E:\xamppp\htdocs\lakhanpatel\application\core\MY_Model.php 98
ERROR - 2018-09-04 19:29:07 --> Severity: Notice --> Undefined variable: id E:\xamppp\htdocs\lakhanpatel\application\core\MY_Model.php 99
ERROR - 2018-09-04 19:29:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IS NULL' at line 3 - Invalid query: SELECT `id`
FROM `oe_questions`
WHERE  IS NULL
ERROR - 2018-09-04 19:29:41 --> Severity: Warning --> Missing argument 4 for My_Model::getFilterTable(), called in E:\xamppp\htdocs\lakhanpatel\application\controllers\Onlineexam.php on line 284 and defined E:\xamppp\htdocs\lakhanpatel\application\core\MY_Model.php 93
ERROR - 2018-09-04 19:29:41 --> Severity: Notice --> Undefined variable: id E:\xamppp\htdocs\lakhanpatel\application\core\MY_Model.php 98
ERROR - 2018-09-04 19:29:41 --> Severity: Notice --> Undefined variable: id E:\xamppp\htdocs\lakhanpatel\application\core\MY_Model.php 99
ERROR - 2018-09-04 19:29:41 --> Severity: Notice --> Undefined variable: quesWithSub E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_allqus_sub.php 31
ERROR - 2018-09-04 19:29:41 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_allqus_sub.php 31
ERROR - 2018-09-04 19:31:00 --> Severity: Warning --> Missing argument 4 for My_Model::getFilterTable(), called in E:\xamppp\htdocs\lakhanpatel\application\controllers\Onlineexam.php on line 284 and defined E:\xamppp\htdocs\lakhanpatel\application\core\MY_Model.php 93
ERROR - 2018-09-04 19:31:00 --> Severity: Notice --> Undefined variable: id E:\xamppp\htdocs\lakhanpatel\application\core\MY_Model.php 98
ERROR - 2018-09-04 19:31:00 --> Severity: Notice --> Undefined variable: id E:\xamppp\htdocs\lakhanpatel\application\core\MY_Model.php 99
ERROR - 2018-09-04 19:31:00 --> Severity: Notice --> Undefined variable: quesWithSub E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_allqus_sub.php 31
ERROR - 2018-09-04 19:31:00 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_allqus_sub.php 31
ERROR - 2018-09-04 19:31:46 --> Severity: Notice --> Undefined variable: quesWithSub E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_allqus_sub.php 31
ERROR - 2018-09-04 19:31:46 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_allqus_sub.php 31
ERROR - 2018-09-04 19:32:06 --> Severity: Notice --> Undefined variable: quesWithSub E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_allqus_sub.php 31
ERROR - 2018-09-04 19:32:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_allqus_sub.php 31
ERROR - 2018-09-04 19:39:04 --> 404 Page Not Found: Assets/textediter
ERROR - 2018-09-04 19:39:04 --> 404 Page Not Found: Assets/textediter
ERROR - 2018-09-04 19:39:04 --> 404 Page Not Found: Assets/textediter
ERROR - 2018-09-04 19:39:18 --> 404 Page Not Found: Assets/textediter
