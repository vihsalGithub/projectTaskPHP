<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-03 20:12:42 --> Severity: Notice --> Undefined variable: groupById E:\xamppp\htdocs\lakhanpatel\application\core\MY_Model.php 108
ERROR - 2018-09-03 20:12:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamppp\htdocs\lakhanpatel\system\database\DB_query_builder.php 1137
ERROR - 2018-09-03 20:38:15 --> Severity: Error --> Call to undefined method My_Model::questionGroupBy() E:\xamppp\htdocs\lakhanpatel\application\controllers\Onlineexam.php 235
ERROR - 2018-09-03 20:43:01 --> Severity: Error --> Call to undefined method Onlineexam_model::group_by() E:\xamppp\htdocs\lakhanpatel\application\models\Onlineexam_model.php 18
ERROR - 2018-09-03 20:55:16 --> Severity: Notice --> Undefined variable: oe_qus_groupby E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questions.php 52
ERROR - 2018-09-03 20:55:54 --> Severity: Notice --> Undefined variable: oe_qus_groupby E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questions.php 52
ERROR - 2018-09-03 20:56:25 --> Severity: Notice --> Undefined variable: oe_qus_groupby E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questions.php 52
ERROR - 2018-09-03 20:56:29 --> Severity: Notice --> Undefined variable: oe_qus_groupby E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questions.php 52
ERROR - 2018-09-03 20:56:30 --> Severity: Notice --> Undefined variable: oe_qus_groupby E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questions.php 52
ERROR - 2018-09-03 20:56:31 --> Severity: Notice --> Undefined variable: oe_qus_groupby E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questions.php 52
ERROR - 2018-09-03 20:56:36 --> Severity: Notice --> Undefined variable: oe_qus_groupby E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questions.php 52
ERROR - 2018-09-03 20:56:37 --> Severity: Notice --> Undefined variable: oe_qus_groupby E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questions.php 52
ERROR - 2018-09-03 20:57:42 --> Severity: Notice --> Undefined variable: oe_qus_groupby E:\xamppp\htdocs\lakhanpatel\application\views\onlineexam\oe_questions.php 52
