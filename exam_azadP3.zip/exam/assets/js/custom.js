var   base_url = 'https://lakhanpatel.com/exam';   
$(document).ready(function () {

	
		$('form[id="login_form"]').validate({
				rules: {
					userName: 'required',
					userPass: 'required',
				  },
				   errorPlacement: function(){
						return false;  /*// suppresses error message text*/
					},
				  submitHandler: function(form) {
					loginchaked_js();
				  }
		});

	function loginchaked_js(){
	  var username = $("#userName").val();
	  var userPass = $("#userPass").val();
	  var url = base_url+'/home/logincheck';
	  $.ajax({
           type: "POST",
           url: url,
           data:  $("#login_form").serialize(), // serializes the form's elements.
           success: function(data)
           {
               /*alert(data); // show response from the php script.  */
			  window.location.replace(data);

           }
         });
	}
		
	$("#frmregistration").click(function(){
		$('form[id="registration_form"]').validate({
		rules: {
			firstName: 'required',
			lastName: 'required',
			contactNo: 'required',
			inputEmail: 'required',
			inputPassword: 'required',
			confirmPassword: 'required',
			userAddress: 'required',
		  },
		   errorPlacement: function(){
				return false;   /*suppresses error message text*/
			},
		  submitHandler: function(form) {
			registration_form_js()
		  }
		});
	});

	$("#submitUP").show();
	function registration_form_js(){
		//alert();
		  $("#messageBoxDiv").text('');
		  var url = base_url+'/home/registration_form';
		  $.ajax({
	           type: "POST",
	           url: url,
	           data:  $("#registration_form").serialize(), // serializes the form's elements.
	           success: function(data)
	           {
	           	  //alert(data);
				  var values = JSON.parse(data);
				  if(values.status){
					  $("#messageBoxDiv").append('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+values.message+'</div>');
				  	alert(values.url);
				  	window.location.replace(values.url);
				  }else{
				  	$("#messageBoxDiv").append('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+values.message+'</div>');
				  }
	           }
	        });
	}


	
	$('#inputPassword, #confirmPassword').on('keyup', function () {
	  if ($('#inputPassword').val() == $('#confirmPassword').val()) {
		$('#message').html('Matching').css('color', 'green');
	  } else 
		$('#message').html('Not Matching').css('color', 'red');
	});




});







