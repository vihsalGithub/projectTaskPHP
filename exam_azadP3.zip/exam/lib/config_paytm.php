<?php
/*
- Use PAYTM_ENVIRONMENT as 'PROD' if you wanted to do transaction in production environment else 'TEST' for doing transaction in testing environment.
- Change the value of PAYTM_MERCHANT_KEY constant with details received from Paytm.
- Change the value of PAYTM_MERCHANT_MID constant with details received from Paytm.
- Change the value of PAYTM_MERCHANT_WEBSITE constant with details received from Paytm.
- Above details will be different for testing and production environment.
*/


/*define('PAYTM_ENVIRONMENT', 'PROD'); 
define('PAYTM_MERCHANT_KEY', 'AXZoA&n&0&gVBJwx'); 
define('PAYTM_MERCHANT_MID', 'AzadSe84935563268281'); 
define('PAYTM_MERCHANT_WEBSITE', 'WEBPROD'); 
*/
define('PAYTM_ENVIRONMENT', 'TEST');
define('PAYTM_MERCHANT_KEY', 'wOvQAeNF@gr40nmZ');
define('PAYTM_MERCHANT_MID', 'AzadSe94276749354666'); 
define('PAYTM_MERCHANT_WEBSITE', 'WEBSTAGING');



$PAYTM_STATUS_QUERY_NEW_URL='https://securegw-stage.paytm.in/merchant-status/getTxnStatus';
$PAYTM_TXN_URL='https://securegw-stage.paytm.in/theia/processTransaction';
if (PAYTM_ENVIRONMENT == 'PROD') {
	// echo "dsajdsa" ;die;
	$PAYTM_STATUS_QUERY_NEW_URL='https://securegw.paytm.in/merchant-status/getTxnStatus';
	$PAYTM_TXN_URL='https://securegw.paytm.in/theia/processTransaction';
}
define('PAYTM_REFUND_URL', '');
define('PAYTM_STATUS_QUERY_URL', $PAYTM_STATUS_QUERY_NEW_URL);
define('PAYTM_STATUS_QUERY_NEW_URL', $PAYTM_STATUS_QUERY_NEW_URL);
define('PAYTM_TXN_URL', $PAYTM_TXN_URL);
?>
