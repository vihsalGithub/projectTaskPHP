<?php include('header.php') ?>


		<?php include('templats/homeslider.php') ?>
		<?php include('templats/aboutus.php') ?>
		<?php include('templats/courses.php') ?>
		<?php include('templats/counter.php') ?>
		<?php include('templats/events.php') ?>
		<?php include('templats/team.php') ?>
		<?php include('templats/latestnews.php') ?>
		<?php include('templats/product.php') ?>
		<?php include('templats/testimonial.php') ?>
		
	
		

        
        
		

       

        

		

		
		
    <?php include('footer.php'); ?>