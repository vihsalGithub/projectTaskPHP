<?php 

/*echo '<pre>';
print_r($_GET);*/

$child_no  = $_GET['child_no'] ;
$adult_no = $_GET['adult_no'] ;
$total = ($child_no+$adult_no);
$date1=date_create($_GET['check_in']);
$date2=date_create($_GET['check_out']);
$diff =date_diff($date1,$date2);
$dateDiffrence = $diff->days ;

if($_GET['roomBook'] <1){
	//echo "revert on location1";
	header('Location: index.php?message=1');
}else if($total >=9){
	header('Location: index.php?message=2');
}else if($dateDiffrence >30){
	header('Location: index.php?message=3');
}



include("header.php");


 ?>
<style type="text/css">
	.booking_input{
		padding-left: 7px;
	}
	.card-footer p {
		font-size: 13px;
		margin-bottom: 0rem; 
	}
</style>
	<div class="container" style="margin-top: 50px;padding-top: 150px;">
		<div class="row text-center">
			<?php
			include('api/checkAvaialability.php');
				 $hotelsDataArray = $hotelsData->hotels ;
				/*echo '<pre>';
				 print_r($hotelsData->hotels); 
				 echo '</pre>';*/
			foreach ($hotelsDataArray as $key => $value) {
			?>
			 <div class="col-lg-3 col-md-6 mb-4">
		        <div class="card h-100">
		          <img class="card-img-top" src="https://cdn.hotelbeds.com/giata/<?php echo $arrayImage[$key]?>" alt="">
		          <div class="card-body">
		            <h4 class="card-title"><?php echo $value->name ;?></h4>
		          </div>
		          <div class="card-footer">
		          	<p><b>Hotel Type</b><?php echo $value->categoryName ;?></p>  
		          	<p><b>Minimum Rate</b><?php echo $value->minRate ;?></p>
		          	<p><b>Maximum Rate</b><?php echo $value->maxRate ;?></p>
		            	<?php //foreach ($value->rooms[0] as $key3 => $value3) { ?>	
	                     <form  method="get" action="booknow.php">
	                        <input type="hidden" name="ratekey" value="<?php echo $value->rooms[0]->rates[0]->rateKey ?>">
	                        <input type="hidden" name="rateType" value="<?php echo $value->rooms[0]->rates[0]->rateType ?>">
	                        <input type="hidden" name="child_no" value="<?php echo $child_no ?>">
	                        <input type="hidden" name="adult_no" value="<?php echo $adult_no ?>">
	                        <input type="hidden" name="check_in" value="<?php echo $check_in ?>">
	                        <input type="hidden" name="check_out" value="<?php echo $check_out ?>">
	                        <input type="hidden" name="hotelCode" value="<?php echo $value->code ?>">
	                        <input type="hidden" name="roomBook" value="<?php echo $roomBook  ?>">
	                        <input type="hidden" name="img_src" value="https://cdn.hotelbeds.com/giata/<?php echo $arrayImage[$key]?>">
	                          <button class="btn btn-success" type="submit" name="submit" style="margin: 10px;" href="">Bookin Confirm</button>
	                     </form>
				    <?php //} ?>
		          </div>
		        </div>
		      </div>
			<?php
				}
			?>
	    </div>
	</div>
</div>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="styles/bootstrap-4.1.2/bootstrap.min.js"></script>

<script src="plugins/OwlCarousel2-2.3.4/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/colorbox/jquery.colorbox-min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>