<?php

include("config.php");
$from = 1; 
$to = 203;

$check_in = $_GET['check_in'];
$checkInArray =  explode('/', $check_in);
$check_out = $_GET['check_out'];
$checkOutArray =  explode('/', $check_out);
$checkInDate  = $checkInArray[2].'-'.$checkInArray[0].'-'.$checkInArray[1];
$checkOutDate  = $checkOutArray[2].'-'.$checkOutArray[0].'-'.$checkOutArray[1];
if(!empty($_GET['selectCountryName'])){
  $country = $_GET['selectCountryName'];
}else{
  $country = DEFAULTCOUNTRY;
}


if(!empty($_GET['shiftDays'])){
  $shiftDays = $_GET['shiftDays'];
}else{
  $shiftDays = SHIFTDAYS;
}

$date1=date_create($_GET['check_in']);
$date2=date_create($_GET['check_out']);
$diff =date_diff($date1,$date2);
$shiftDays = $diff->days ;


if(!empty($_GET['roomBook'])){
  $roomBook = $_GET['roomBook'];
}else{
  $roomBook = ROOMBOOK;
}

if(!empty($_GET['child_no'])){
  $child_no = $_GET['child_no'];
}else{
  $child_no = CHILDNO;
}
if(!empty($_GET['adult_no'])){
  $adult_no = $_GET['adult_no'];
}else{
  $adult_no = ADULTNO;
}
$pax = '';
for($i=0;$i<$adult_no;$i++){

  if($child_no ==0){
    $comma1 = '';  
  }else{ $comma1 = ','; }
  $pax .= '{"type": "AD","age": '.DEFAULT_ADULT_AGE.'}'.$comma1;
}
for($i=0;$i<$child_no;$i++){
  if($i==($child_no-1)){$comma = '';
  }else{ $comma = ',';} 
  $pax .= '{"type": "CH","age": '.DEFAULT_CHILD_AGE.'}'.$comma;
}
//echo $pax ; die;
$selectCityName = $_GET['selectCityName'] ;
//https://api.test.hotelbeds.com/hotel-content-api/1.0/hotels?fields=all&destinationCode=AEM&countryCode=US&language=ENG&from=1&to=100&useSecondaryLanguage=false
$endpoint = $host."/hotel-content-api/1.0/hotels?fields=all&destinationCode=".$selectCityName."&countryCode=".$country."&language=ENG&from=".$from."&to=".$to."&useSecondaryLanguage=false";
try
{ 
  $curl = curl_init();
  curl_setopt_array($curl, array(
  CURLOPT_RETURNTRANSFER => 1,
  CURLOPT_URL => $endpoint,
  CURLOPT_HTTPHEADER => $header_data
  ));
  $resp = curl_exec($curl);
  $resDataArray = json_decode($resp) ;
  $hotelData = $resDataArray->hotels ;
   if(!empty($hotelData)){
      $arrayName = array();
      $arrayImage = array();
      foreach ($hotelData as $key => $value) {
          $arrayName[$key] = $value->code ;
          if(!empty($value->images[0]->path)){
                      $arrayImage[$key] = $value->images[0]->path ;
          }else{
            $arrayImage[$key]  = '';
          }
          //https://cdn.hotelbeds.com/giata/00/000005/000005a_hb_ba_010.jpg
      }
      $hotelEndAPi = $host."/hotel-api/1.0/hotels";
            $hotelApiBody = '{
                              "stay": {
                                "checkIn": "'.$checkInDate.'",
                                "checkOut": "'.$checkOutDate.'",
                                "shiftDays": "'.$shiftDays.'"
                              },
                              "occupancies": [
                                {
                                  "rooms": '.$roomBook.',
                                  "adults": '.$adult_no.',
                                  "children": '.$child_no.',
                                  "paxes": ['.$pax.']
                                }
                              ],
                              "hotels": {
                                "hotel": ['.implode(",",$arrayName).']
                              }
                            }';
                //print_r($hotelApiBody); die;
            $curlHotel = curl_init();
            curl_setopt_array($curlHotel, array(
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_URL => $hotelEndAPi,
            CURLOPT_HTTPHEADER => $header_data,
            CURLOPT_POSTFIELDS  => $hotelApiBody
            ));
            $respHotel = curl_exec($curlHotel);
            $resDataArrayHotel = json_decode($respHotel) ;
            $hotelsData = $resDataArrayHotel->hotels;
            /*echo '<pre>';
            print_r($hotelsData);
            echo  '</pre>';*/
   }else{
       echo "<h3>No Data available</h3>";
   }
  curl_close($curl);

} catch (Exception $ex) {
  //printf("Error while sending request, reason: %s\n",$ex->getMessage());
}
?>