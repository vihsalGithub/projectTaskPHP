<?php

/*echo '<pre>';
print_r($_GET); 
echo '</pre>';
*/




$date1=date_create($_GET['check_in']);
$date2=date_create($_GET['check_out']);
$diff =date_diff($date1,$date2);
$shiftDays = $diff->days ;
$inDate = date_format($date1,"Y-m-d") ;
$outDate = date_format($date2,"Y-m-d") ;
//print_r(date_format($date1,"Y-m-d")); die;



if(!empty($_GET['roomBook'])){
  $roomBook = $_GET['roomBook'];
}else{
    $roomBook = 1;
}



if(!empty($_GET['child_no'])){
  $child_no = $_GET['child_no'];
}else{
  $child_no = CHILDNO;
}


if(!empty($_GET['adult_no'])){
  $adult_no = $_GET['adult_no'];
}else{
  $adult_no = ADULTNO;
}

$hotelCode = $_GET['hotelCode'];

$pax = '';
for($i=0;$i<$adult_no;$i++){

  if($child_no ==0){
    $comma1 = '';  
  }else{ $comma1 = ','; }
  $pax .= '{"type": "AD","age": '.DEFAULT_ADULT_AGE.'}'.$comma1;
}
for($i=0;$i<$child_no;$i++){
  if($i==($child_no-1)){$comma = '';
  }else{ $comma = ',';} 
  $pax .= '{"type": "CH","age": '.DEFAULT_CHILD_AGE.'}'.$comma;
}


$endpoint = "https://api.test.hotelbeds.com/hotel-api/1.0/hotels";
 $hotelApiBodyForRoom = '{
  "stay": {
    "checkIn": "'.$inDate.'",
    "checkOut": "'.$outDate.'",
    "shiftDays": "'.$shiftDays.'"
  },
  "occupancies": [
    {
      "rooms": 1,
      "adults": '.$adult_no.',
      "children": '.$child_no.',
      "paxes": ['.$pax.']
    }
  ],
  "hotels": {
    "hotel": ['.$hotelCode.']
  }
}';
               //  print_r($hotelApiBodyForRoom); die;
try 
{ 
  $curl = curl_init();
  curl_setopt_array($curl, array(
  CURLOPT_RETURNTRANSFER => 1,
  CURLOPT_URL => $endpoint,
  CURLOPT_HTTPHEADER => $header_data,
  CURLOPT_POSTFIELDS  => $hotelApiBodyForRoom
  ));
  $respArra1 = curl_exec($curl);
  $hotelForRoomRes = json_decode($respArra1) ;
  if(!empty($hotelForRoomRes->hotels)){
    $hotelRooms = $hotelForRoomRes->hotels->hotels[0]->rooms ;
    $ratKeyOption = '';
    foreach ($hotelRooms as $key => $roomValue) {
      $ratKeyOption .= '<option value="'.$roomValue->rates[0]->rateKey.'">'.ucfirst($roomValue->name).'('.$roomValue->rates[0]->net.')'.'</option>';
    }
  }
  //die;
  curl_close($curl);
} catch (Exception $ex) {
  //printf("Error while sending request, reason: %s\n",$ex->getMessage());
}
?>