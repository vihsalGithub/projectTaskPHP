<?php


/*Jorge*/
/*$apiKey = "u4gac8yqxt6g9z2evwgsum7p";
$Secret = "ZnNCBEqrMf";*/


/*VISHAL*/
$apiKey = "q8pc784bn86c9dv4gd7hfy9u";
$Secret = "TReJ7eUEJX";

/*ram*/
/*$apiKey = "nhw5ugvcjdcmnergp6rw4c7h";
$Secret = "gam3Q8x3ef";*/

define("SECRATEKEY", $Secret) ;
define("APIKEY", $apiKey) ;
$signature = hash("sha256", APIKEY.SECRATEKEY.time());
//echo $signature ; die;
$host = "https://api.test.hotelbeds.com" ;
//$host = "api.test.hotelbeds.com" ;
define("SIGNATURE", $signature) ;
$header_data = array(
    "Accept: application/json",
    "Accept-Encoding: 122.168.95.220",
    "X-Originating-IP: gzip",
    "Api-Key:".APIKEY,
    "X-Signature:".SIGNATURE,
    "Content-Type: application/json"
);
$language = 'ENG' ;
define("APIHEDERDATA", $header_data);
define("LANGUAGE", $language);
define("DEFAULTCOUNTRY","US");
define("SHIFTDAYS",2);
define("ROOMBOOK",1);
define("CHILDNO",0);
define("ADULTNO",1);
define("DEFAULT_ADULT_AGE",30);
define("DEFAULT_CHILD_AGE",8);
define("HOTELBEDSIMGSRC","https://cdn.hotelbeds.com/giata/");

error_reporting(0);

?>