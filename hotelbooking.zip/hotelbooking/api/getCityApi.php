<?php

include("config.php");
$from = 1;
$to = 1000;
if(!empty($_POST['country'])){
  $country = $_POST['country'];
}else{
  $country = DEFAULTCOUNTRY;
}
//https://api.test.hotelbeds.com/hotel-content-api/1.0/locations/destinations?fields=all&countryCodes=US&language=ENG&from=1&to=203&useSecondaryLanguage=false
$endpoint = $host."/hotel-content-api/1.0/locations/destinations?fields=all&countryCodes=".$country."&language=".LANGUAGE."&from=".$from."&to=".$to."&useSecondaryLanguage=false";
try
{ 
  $curl = curl_init();
  curl_setopt_array($curl, array(
  CURLOPT_RETURNTRANSFER => 1,
  CURLOPT_URL => $endpoint,
  CURLOPT_HTTPHEADER => $header_data
  ));
  $resp = curl_exec($curl);
  $resDataArray = json_decode($resp) ;
   $cityData = $resDataArray->destinations ;
      $cityOption = '';
     if(count($cityData)){
     	 foreach ($cityData as $key => $value) {
        $selected = '';
        if($value->code == "MIA"){
           $selected ="selected";
        }else{
          $selected ="";
        }
     	 	$cityOption .= '<option '.$selected.' value="'.$value->code.'">'.$value->name->content.'</option>';
     	 }

       if($resDataArray->total >1000){
            $from1 = 1000;
            $to1 = 2000;
            $endpoint1 = $host."/hotel-content-api/1.0/locations/destinations?fields=all&countryCodes=".$country."&language=".LANGUAGE."&from=".$from1."&to=".$to1."&useSecondaryLanguage=false";
            try
            { 
              $curl1 = curl_init();
              curl_setopt_array($curl, array(
              CURLOPT_RETURNTRANSFER => 1,
              CURLOPT_URL => $endpoint1,
              CURLOPT_HTTPHEADER => $header_data
              ));
              $resp1 = curl_exec($curl1);
              $resDataArray1 = json_decode($resp1) ;
               $cityData1 = $resDataArray1->destinations ;
                 if(count($cityData1)){
                   foreach ($cityData1 as $key1 => $value1) {
                    $cityOption .= '<option  value="'.$value1->code.'">'.$value1->name->content.'</option>';
                    
                   }
                 }
              curl_close($curl1);
            } catch (Exception $ex) {
            } 
            //$cityOption .= '<option  value="">Vishal</option>';    
          }

     }




     echo $cityOption ;

    /* echo '<pre>';
     print_r($cityData);
     echo '</pre>';*/
     
  curl_close($curl);

} catch (Exception $ex) {
  //printf("Error while sending request, reason: %s\n",$ex->getMessage());
}




?>