<?php
include("config.php");
$hotelApiBody = '{
	"stay": {
		"checkIn": "2019-06-08",
		"checkOut": "2019-06-10",
		"shiftDays": "2"
	},
	"occupancies": [
		{
			"rooms": 1,
			"adults": 2,
			"children": 1,
			"paxes": [
				{
					"type": "AD",
					"age": 30
				},
				{
					"type": "AD",
					"age": 30
				},
				{
					"type": "CH",
					"age": 8
				}
			]
		}
	],
	"hotels": {
		"hotel": [1550]
  },
  "filter": {
    "maxRooms": 5,
    "minRate": 100.000,
    "maxRate": 1700.000,
	"maxRatesPerRoom": 2
  }
}';

$endpoint ="https://api.test.hotelbeds.com/hotel-api/1.0/hotels";
/*$endpoint ="https://api.test.hotelbeds.com/hotel-content-api/1.0/hotels?fields=all&language=ENG&from=1&to=1&useSecondaryLanguage=false";*/
try
{ 
  $curl = curl_init();
  curl_setopt_array($curl, array(
  CURLOPT_RETURNTRANSFER => 1,
  CURLOPT_URL => $endpoint,
  CURLOPT_HTTPHEADER => $header_data,
              CURLOPT_POSTFIELDS  => $hotelApiBody

  ));
  $resp = curl_exec($curl);
  $resDataArray = json_decode($resp) ;
  

  /*$hotelsData = $resDataArray->hotels ;
  foreach ($hotelsData as $key => $value) {
  	echo '<pre>';
  	  print_r($value->images[0]->path) ;
  	echo '</pre>';
  }*/
  echo '<pre>';
  print_r($resDataArray->hotels->hotels[0]->rooms[0]->rates[0]->rateKey);
  echo '<br>';
  print_r($resDataArray->hotels->hotels[0]->rooms[0]->rates[0]->rateType);
  echo '</pre>';
     
  curl_close($curl);

} catch (Exception $ex) {
  //printf("Error while sending request, reason: %s\n",$ex->getMessage());
}