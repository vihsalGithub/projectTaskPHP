<?php

include("config.php");
;
$from = 1;
$to = 203;
//https://api.test.hotelbeds.com/hotel-content-api/1.0/locations/countries?fields=all&language=ENG&from=1&to=100&useSecondaryLanguage=false
$endpoint = $host."/hotel-content-api/1.0/locations/countries?fields=all&".LANGUAGE."=ENG&from=".$from."&to=".$to."&useSecondaryLanguage=false";
try
{ 
  $curl = curl_init();
  curl_setopt_array($curl, array(
  CURLOPT_RETURNTRANSFER => 1,
  CURLOPT_URL => $endpoint,
  CURLOPT_HTTPHEADER => $header_data
  ));
  $resp = curl_exec($curl);
  $resDataArray = json_decode($resp) ;
   $countryData = $resDataArray->countries ;

     if(count($countryData)){
     	  $countryOption = '';
     	 foreach ($countryData as $key => $value) {
        if($value->code == "US"){
           $selected ="selected";
        }else{
          $selected ="";
        }
     	 	$countryOption .= '<option '.$selected.' value="'.$value->code.'">'.$value->description->content.'</option>';
     	 }
     }
     echo $countryOption ;
    /* echo '<pre>';
     print_r($countryData);
     echo '</pre>';*/
     
  curl_close($curl);

} catch (Exception $ex) {
  //printf("Error while sending request, reason: %s\n",$ex->getMessage());
}
?>