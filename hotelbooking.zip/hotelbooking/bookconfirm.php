<?php
include("api/config.php");
//SECRATEKEY  //APIKEY   // SIGNATURE
/*echo '<pre>';
print_r($_GET);*/

$holderName = $_GET['holderName'];
$holderSirName = $_GET['holderSirName'];
$holderEmail = $_GET['holderEmail'];
$holderPhoneNo = $_GET['holderPhoneNo'];
$totalAdult = $_GET['totalAdult'];
$totalChild = $_GET['totalChild'];
$inDate = $_GET['inDate'];
$outDate = $_GET['outDate'];
$rateKeyGet = $_GET['rateKey'];
$rateType = $_GET['rateType'];



/*echo '<pre>';
print_r($_GET);

die;*/

if($rateType == 'RECHECK'){
		$endpointRecheck= 'https://api.test.hotelbeds.com/hotel-api/1.0/checkrates';
		$recheckBody = '{
						"language": "CAS",
						"upselling": "True",
						"rooms": [{
							"rateKey": "'.$rateKeyGet.'"
						},
						{
							"rateKey": "'.$rateKeyGet.'"
						}]
					}';
		try{	
				$curl = curl_init();
				curl_setopt_array($curl, array(
				CURLOPT_RETURNTRANSFER => 1,
				CURLOPT_URL => $endpointRecheck,
				CURLOPT_HTTPHEADER => $header_data,
				CURLOPT_POSTFIELDS => $recheckBody
				));
				$resp = curl_exec($curl);
				if(json_decode($resp)){
					$resArray = json_decode($resp) ;
          if(empty($resArray->error)){
            $rateKey = $resArray->hotel->rooms[0]->rates[0]->rateKey ;
          }else{
              header('Location: errortemp.php') ;
          }
				}else{
			       echo '<h1 class="text-center">Developer Over Rate</h1>' ;
				}
				curl_close($curl);
			} catch (Exception $ex) {
				printf("Error while sending request, reason: %s\n",$ex->getMessage());
			}
}else{
	$rateKey = $rateKeyGet ;
}



$pax = '';
for($i=0;$i<$totalAdult;$i++){
	$adultMemFName  = "adultMemFName_".$i ;
	$adultMemSName  = "adultMemSName_".$i ;
	$adultAge  = "adultMemAge_".$i ;
  if($totalChild ==0){$comma1 = '';}
  else{$comma1 = ',';}
  $pax .= '{
          "roomId": "1",
          "name": "'.$_GET[$adultMemFName].'",
          "type": "AD",
          "surname": "'.$_GET[$adultMemSName].'"
        }'.$comma1;
}
for($i=0;$i<$totalChild;$i++){
	$childMemFName  = "adultMemFName_".$i ;
	$childMemSName  = "adultMemSName_".$i ;
	$childAge  = "adultMemAge_".$i ;
	if($i==($totalChild-1)){$comma = '';
	}else{ $comma = ',';} 
  $pax .= '{
          "roomId": "1",
          "name": "'.$_GET[$childMemFName].'",
          "type": "CH",
          "surname": "'.$_GET[$childMemSName].'"
        }'.$comma;
}

$endpoint = "https://api.test.hotelbeds.com/hotel-api/1.0/bookings";

$body = '{
		"holder": {
			"name": "'.$holderName.'",
			"surname": "'.$holderSirName.'"
		},
		"rooms": [{
			"rateKey": "'.$rateKey.'",
			"paxes": ['.$pax.']
		}],
		"clientReference": "IntegrationAgency",
		"remark": "Booking remarks are to be written here.",
		"tolerance" : 50.00
	}';

try
	{	
		$curl = curl_init();
		curl_setopt_array($curl, array(
		CURLOPT_RETURNTRANSFER => 1,
		CURLOPT_URL => $endpoint,
		CURLOPT_HTTPHEADER => $header_data,
		CURLOPT_POSTFIELDS => $body
		));
		$resp = curl_exec($curl);
		if(json_decode($resp)){
			$confirmedResponse = json_decode($resp) ;
		}else{
	       echo '<h1 class="text-center">Developer Over Rate</h1>' ;
		}
		curl_close($curl);
	} catch (Exception $ex) {
		printf("Error while sending request, reason: %s\n",$ex->getMessage());
	}

//echo $pax  ; 
//echo '<br>';
//print_r($_GET);
//die;	  
/*echo '<pre>';
print_r($confirmedResponse); 
echo '</pre>';  */
include("header.php");

//print_r($confirmedResponse);
	      	?>	
	<div class="container" style="margin-top: 50px;padding-top: 150px;">
		<div class="row text-center">
	      <div class="col-lg-8 col-md-8" style="margin: auto;padding: 50px 0px;">
	        <div class="card h-100">

            
	        	<?php
              if($confirmedResponse->booking){
              	   $booking  = $confirmedResponse->booking ;
                ?>
                <h1>Confirmed</h1>
                <table class="table">
              <tbody>
                <tr>
                  <td><b>Holder Name</b></td>
                  <td><?php echo $booking->holder->name; ?></td>
                </tr>
                
                <tr>
                  <td><b>Status</b></td>
                  <td><?php echo $booking->status ?></td>
                </tr>

                <tr>
                  <td><b>Creation Date</b></td>
                  <td><?php echo $booking->creationDate ?></td>
                </tr>

                <tr>
                  <td><b>checkIn Date</b></td>
                  <td><?php echo $booking->hotel->checkIn ?></td>
                </tr> 

                <tr>
                  <td><b>checkOut Date</b></td>
                  <td><?php echo $booking->hotel->checkOut ?></td>
                </tr>

                <tr>
                  <td><b>Hotel Name</b></td>
                  <td><?php echo $booking->hotel->name ?></td>
                </tr>

                <tr>
                  <td><b>Hotel categoryName</b></td>
                  <td><?php echo $booking->hotel->categoryName ?></td>
                </tr>

                <tr>
                  <td><b>Hotel destinationName</b></td>
                  <td><?php echo $booking->hotel->destinationName ?></td>
                </tr>

                <tr>
                  <td><b>Hotel zoneName</b></td>
                  <td><?php echo $booking->hotel->zoneName ?></td>
                </tr>
                <tr>
                  <td><b>Total Rooms</b></td>
                  <td><?php echo $booking->hotel->rooms[0]->rates[0]->rooms ?></td>
                </tr>
                 <tr>
                  <td><b>Total Adults</b></td>
                  <td><?php echo $booking->hotel->rooms[0]->rates[0]->adults ?></td>
                </tr>
                <tr>
                  <td><b>Total Children</b></td>
                  <td><?php echo $booking->hotel->rooms[0]->rates[0]->children ?></td>
                </tr>
                <tr>
                  <td><b>Total Paymant</b></td>
                  <td><?php echo $booking->hotel->totalNet ?></td>
                </tr>
                <!-- <tr>
                  <td><b>Total pendingAmount</b></td>
                  <td><?php echo $booking->hotel->pendingAmount ?></td>
                </tr> -->
                <tr>
                  <td><b>currency</b></td>
                  <td><?php echo $booking->hotel->currency ?></td>
                </tr>
              </tbody>
            </table>

                <?php
                 
              }else{
                echo '<pre>';
                print_r($resDataArray);
              }
              
	        	?>
	        </div>
	      </div>
	  		
	    </div>
	</div>

</div>

<script src="js/jquery-3.3.1.min.js"></script>
<script src="styles/bootstrap-4.1.2/popper.js"></script>
<script src="styles/bootstrap-4.1.2/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.3.4/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/progressbar/progressbar.min.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="plugins/jquery-datepicker/jquery-ui.js"></script>
<script src="plugins/colorbox/jquery.colorbox-min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>