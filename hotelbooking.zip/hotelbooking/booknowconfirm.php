
<?php

include("hotelapi/config.php");
//SECRATEKEY  //APIKEY   // SIGNATURE
/*echo '<pre>';
print_r($_GET);*/

$holderName = $_GET['holderName'];
$holderSirName = $_GET['holderSirName'];
$holderEmail = $_GET['holderEmail'];
$holderPhoneNo = $_GET['holderPhoneNo'];
$totalAdult = $_GET['totalAdult'];
$totalChild = $_GET['totalChild'];
$inDate = $_GET['inDate'];
$outDate = $_GET['outDate'];
$rateKey = $_GET['rateKey'];



$pax = '';
for($i=0;$i<$totalAdult;$i++){
	$adultMemFName  = "adultMemFName_".$i ;
	$adultMemSName  = "adultMemSName_".$i ;
	$adultAge  = "adultMemAge_".$i ;
  if($totalChild ==0){$comma1 = '';}
  else{$comma1 = ',';}
  $pax .= '{
          "age": '.$_GET[$adultAge].',
          "name": "'.$_GET[$adultMemFName].'",
          "type": "ADULT",
          "surname": "'.$_GET[$adultMemSName].'"
        }'.$comma1;
}
for($i=0;$i<$totalChild;$i++){
	$childMemFName  = "adultMemFName_".$i ;
	$childMemSName  = "adultMemSName_".$i ;
	$childAge  = "adultMemAge_".$i ;
	if($i==($totalChild-1)){$comma = '';
	}else{ $comma = ',';} 
  $pax .= '{
          "age": '.$_GET[$childAge].',
          "name": "'.$_GET[$childMemFName].'",
          "type": "CHILD",
          "surname": "'.$_GET[$childMemSName].'"
        }'.$comma;
}

//echo $pax  ; 

$endpoint = "https://".$host."/activity-api/3.0/bookings";
$body = '{
  "language": "en",
  "clientReference": "Agency test",
  "holder": {
    "name": "'.$holderName.'",
    "email": "'.$holderEmail.'",
    "surname": "'.$holderSirName.'",
    "telephones": [
      "'.$holderPhoneNo.'"
    ]
  },
  "activities": [
    {
      "preferedLanguage": "en",
      "serviceLanguage": "en",
      "rateKey": "'.$rateKey.'",
      "from": "'.$inDate.'",
      "to": "'.$outDate.'",
      "paxes": ['.$pax.']
    }
  ]
}';

/*$body2 ='{ "language": "en", "clientReference": "Agency test", "holder": { "name": "vishal", "email": "vishal@gmail.com", "surname": "sharma", "telephones": [ "9926701108" ] }, "activities": [ { "preferedLanguage": "en", "serviceLanguage": "en", "rateKey": "gr8rh4jcnm8j5lcvlpslr5n1cu", "from": "2019-02-07", "to": "2019-02-07", "paxes": [{ "age": 20, "name": "vishal", "type": "ADULT", "surname": "sharma" },{ "age": 20, "name": "ggg", "type": "ADULT", "surname": "jjj" },{ "age": 20, "name": "vishal", "type": "CHILD", "surname": "sharma" }] } ] }';*/
//echo '<br>';
try
{	
	$curl = curl_init();
	curl_setopt_array($curl, array(
	CURLOPT_RETURNTRANSFER => 1,
	CURLOPT_URL => $endpoint,
	CURLOPT_HTTPHEADER => $header_data,
  CURLOPT_CUSTOMREQUEST => "PUT",
	CURLOPT_POSTFIELDS  => $body
	));
	$resp = curl_exec($curl);
  $resDataArray = json_decode($resp) ;
curl_close($curl);
} catch (Exception $ex) {
	printf("Error while sending request, reason: %s\n",$ex->getMessage());
}
?>
<?php
	   
include("header.php");
$booking  = $resDataArray->booking ;
	      	?>	
	<div class="container" style="margin-top: 50px;padding-top: 150px;">
		<div class="row text-center">
	      <div class="col-lg-8 col-md-8" style="margin: auto;padding: 50px 0px;">
	        <div class="card h-100">

            <h1>Hotel Detail</h1>
	        	<?php
              if($resDataArray->booking){
                ?>

                <table class="table">
              <tbody>
                <tr>
                  <td><b>Holder Name</b></td>
                  <td><?php echo $booking->holder->name; ?></td>
                </tr>
                <tr>
                  <td><b>Holder Email</b></td>
                  <td><?php echo $booking->holder->email ; ?></td>
                </tr>
                <tr>
                  <td><b>Status</b></td>
                  <td><?php echo $booking->status ?></td>
                </tr>
                <tr>
                  <td><b>pendingAmount</b></td>
                  <td><?php echo $booking->pendingAmount ?></td>
                </tr>
                <tr>
                  <td><b>currency</b></td>
                  <td><?php echo $booking->currency ?></td>
                </tr>
                 <tr>
                  <td><b>creationDate</b></td>
                  <td><?php echo $booking->creationDate ?></td>
                </tr>

                <tr>
                  <td><b>Hotel name</b></td>
                  <td><?php echo $booking->agency->sucursal->name ?></td>
                </tr>

                <tr>
                  <td><b>Hotel street</b></td>
                  <td><?php echo $booking->agency->sucursal->street ?></td>
                </tr>

                <tr>
                  <td><b>Hotel city</b></td>
                  <td><?php echo $booking->agency->sucursal->city ?></td>
                </tr>

                <tr>
                  <td><b>Hotel operationId</b></td>
                  <td><?php echo $booking->agency->sucursal->operationId ?></td>
                </tr>
                
              </tbody>
            </table>

                <?php
                 
              }else{
                echo '<pre>';
                print_r($resDataArray);
              }
              
	        	?>
	        </div>
	      </div>
	  		
	    </div>
	</div>

</div>

<script src="js/jquery-3.3.1.min.js"></script>
<script src="styles/bootstrap-4.1.2/popper.js"></script>
<script src="styles/bootstrap-4.1.2/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.3.4/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/progressbar/progressbar.min.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="plugins/jquery-datepicker/jquery-ui.js"></script>
<script src="plugins/colorbox/jquery.colorbox-min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>