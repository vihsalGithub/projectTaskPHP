
<?php

include("api/config.php");
//SECRATEKEY  //APIKEY   // SIGNATURE
/*
print_r($_GET);
echo "hello"; die;*/

$rateKey = $_GET['ratekey'];
$roomBook = $_GET['roomBook'];
$rateType = $_GET['rateType'];
$adult = $_GET['adult_no'];
$child = $_GET['child_no']; 
$hotelCode = $_GET['hotelCode'];
$check_in = $_GET['check_in'];
$checkInArray =  explode('/', $check_in);
$check_out = $_GET['check_out'];
$checkOutArray =  explode('/', $check_out);
$inDate  = $checkInArray[2].'-'.$checkInArray[0].'-'.$checkInArray[1];
$outDate  = $checkOutArray[2].'-'.$checkOutArray[0].'-'.$checkOutArray[1];
 

include("api/ratKeyWithRoom.php");


 /*print_r($_GET['ratekey']); 
echo $rateKey;
 die;*/

$hotelDetailEndPoint = "https://api.test.hotelbeds.com/hotel-content-api/1.0/hotels/".$hotelCode."?language=ENG&useSecondaryLanguage=false" ;
//echo $hotelDetailEndPoint ; die;
try
{	
	$curl = curl_init();
	curl_setopt_array($curl, array(
	CURLOPT_RETURNTRANSFER => 1,
	CURLOPT_URL => $hotelDetailEndPoint,
	CURLOPT_HTTPHEADER => $header_data,
	));
	$hotelRes = curl_exec($curl);
  $hotelResArray = json_decode($hotelRes) ;
curl_close($curl);
} catch (Exception $ex) {
	printf("Error while sending request, reason: %s\n",$ex->getMessage());
}
?>
<?php
/*echo '<pre>';
print_r($hotelResArray->hotel->rooms);
echo '</pre>';
echo '<br>';
die;*/

include("header.php");
	      	?>
	 <style type="text/css">
	 	.booking_button:hover {
    background: rgba(31, 30, 30, 0.88);
    color: #fff;
}
.booking_button{
	float: left;
	padding: 16px;
}
.booknowform{
	padding: 10px;
	padding-top: 20px;
	text-align: left;
    color: #353232;
}
	 </style>
	<div class="container" style="margin: 50px 0px;padding-top: 150px;">
		<div class="row text-center" >
		
	      <div class="col-lg-4 col-md-4" >
	        <div class="card h-100">
	        	<h3>Booking Details</h3>
				<form action="bookconfirm.php" class="booknowform" method="get">
					<div class="form-group">
						<label for="email">Holder Name: </label>
						<input type="text" value="" class="form-control" name="holderName" required="required">
					</div>
					<div class="form-group">
						<label for="email">Holder Surname: </label>
						<input type="text" value="" class="form-control" name="holderSirName" required="required">
					</div>
					<div class="form-group">
						<label for="email">Holder email: </label>
						<input type="text" value="" class="form-control" name="holderEmail" required="required">
					</div>
					<div class="form-group">
						<label for="email">Holder Phone No.: </label>
						<input type="text" value="" class="form-control" name="holderPhoneNo" required="required">
					</div>
					<div class="form-group">
						 <label>Available Room</label>
						  <select class="form-control" name="rateKey" required="required">
						  	<option value="">Select Room</option>
						    <?php echo $ratKeyOption ; ?>
						  </select>
					</div>
					<div class="form-group">
						<label for="email">Adult Members Name: </label>
						<?php for($i=0;$i<$adult ;$i++){?>
						<div class="form-group">
						<label>Adult-<?php echo ($i+1) ?> Information</label>
						<input type="text" value="" placeholder="first name" class="form-control" name="adultMemFName_<?php echo $i ?>" required="required">
						</div>
						<div class="form-group">
						<input type="text" value="" placeholder="last name" class="form-control" name="adultMemSName_<?php echo $i ?>" required="required">
						<input type="number" value="" placeholder="age" class="form-control" name="adultMemAge_<?php echo $i ?>" required="required">
						</div>
						<?php } ?>
						<input type="hidden" value="<?php echo $adult ?>" class="form-control" name="totalAdult" required="required">
					</div>
					<div class="form-group">
						<?php for($i=0;$i<$child ;$i++){?>
						<label for="email">Adult Members Name: </label>
						<div class="form-group">
						<label>Child-<?php echo ($i+1) ?> Information</label>
						<input type="text" value=""  placeholder="first name" class="form-control" name="childMemFName_<?php echo $i ?>" required="required">
						</div>
						<div class="form-group">
						<input type="text" value=""  placeholder="last name" class="form-control" name="childMemSName_<?php echo $i ?>" required="required">
						<input type="number" value="" placeholder="age" class="form-control" name="childMemAge_<?php echo $i ?>" required="required">
						</div>
						<?php } ?>

						<input type="hidden"  value="<?php echo $child ?>"  class="form-control" name="totalChild" required="required">
						<input type="hidden"  value="<?php echo $rateKey ?>"  class="form-control" >
						<input type="hidden"  value="<?php echo $rateType ?>"  class="form-control" name="rateType" required="required">
						<input type="hidden"  value="<?php echo $inDate ?>"  class="form-control" name="inDate" required="required">
						<input type="hidden"  value="<?php echo $outDate ?>"  class="form-control" name="outDate" required="required">
					</div>

				<div><button type="submit" class="booking_button trans_200">Confirm Now</button></div>
				</form>
	        </div>
	      </div>
	      <div class="col-lg-8 col-md-8">
	      	<?php 
	      		if(!empty($hotelResArray->hotel)){

	      			$hotelDetail = $hotelResArray->hotel ;
	      	?>
	      		<div class="row">
	      			<div class="col-md-12">
	      				<h1><?php echo $hotelDetail->name->content ; ?></h1>
	      				<img src="<?php echo $_GET['img_src'] ;?>" style="width: 100%" />
	      			</div>
	      			
				    <div class="col-md-12">
				    	<p>
				    		<table class="table">
				    			<tr>
				    				<td>Destination</td>
				    				<td><?php echo $hotelDetail->destination->name->content ; ?></td>
				    			</tr>
				    			<tr>
				    				<td>Country</td>
				    				<td><?php echo $hotelDetail->country->description->content ; ?></td>
				    			</tr>
				    			<tr>
				    				<td>state</td>
				    				<td><?php echo $hotelDetail->state->name ; ?></td>
				    			</tr>
				    			<tr>
				    				<td>postalCode</td>
				    				<td><?php echo $hotelDetail->postalCode ; ?></td>
				    			</tr>
				    			<tr>
				    				<td>email</td>
				    				<td><?php echo $hotelDetail->email ; ?></td>
				    			</tr>

				    			<tr>
				    				<td>Phone No (for Booking)</td>
				    				<td><?php echo $hotelDetail->phones[0]->phoneNumber ; ?></td>
				    			</tr>
				    		</table>
				    	</p>
				    	<p>
				    		<h3>About Hotel</h3>
				    		<?php echo $hotelDetail->description->content ; ?>
				    	</p>
				    	<p>
				    		<h3>Available Rooms Type in Hotel</h3>
				    		<table class="table">
				    			<tr>
				    				<td>SN</td>
				    				<td>type</td>
				    				<td>description</td>
				    			</tr>
				    			<?php
				    				foreach ($hotelResArray->hotel->rooms as $key2 => $rooms) {
				    			?>	
				    			    <tr>
				    			    	<td><?php echo ($key2+1) ?></td>
				    			    	<td class="text-capitalize"><?php echo $rooms->description ;?></td>
				    			    	<td><?php echo $rooms->type->description->content ;?></td>
				    			    </tr>	
				    			<?php
				    				}
				    			?>
				    		</table>
				    	</p>
				    </div>


				    <div class="clearfix"></div>
				    <div class="col-md-12">
				    	<h3>Image Gallery</h3>
				    </div>
	      			<?php
	      				foreach ($hotelDetail->images as $key => $images) {
	      			?>
					    <div class="col-md-2" style="padding:0px;margin-top:10px;">
					      <div class="thumbnail">
					        <a href="<?php echo HOTELBEDSIMGSRC.$images->path ; ?>" target="_blank">
					          <img src="<?php echo HOTELBEDSIMGSRC.$images->path ; ?>" alt="Lights" style="width:100%;height:150px;">
					        </a>
					      </div>
					    </div>
					<?php } ?>
				    <div class="clearfix"></div>
				</div>
			<?php }else{
				echo '<div><h3>No detail Found</h3></div>';
			}?>
	      </div>
	    </div>
	</div>

</div>

<script src="js/jquery-3.3.1.min.js"></script>
<script src="styles/bootstrap-4.1.2/popper.js"></script>
<script src="styles/bootstrap-4.1.2/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.3.4/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/progressbar/progressbar.min.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="plugins/jquery-datepicker/jquery-ui.js"></script>
<script src="plugins/colorbox/jquery.colorbox-min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>