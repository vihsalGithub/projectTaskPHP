<?php include("header.php"); ?>
<style type="text/css">
	.booking_input{
		padding-left: 7px;
	}

	input:-webkit-autofill,
input:-webkit-autofill:hover,  
input:-webkit-autofill:focus
textarea:-webkit-autofill,
textarea:-webkit-autofill:hover
textarea:-webkit-autofill:focus,
select:-webkit-autofill,
select:-webkit-autofill:hover,
select:-webkit-autofill:focus {
  border: 1px solid green;
  -webkit-text-fill-color: green;
  -webkit-box-shadow: 0 0 0px 1000px #000 inset;
  transition: background-color 5000s ease-in-out 0s;
  display: none;
}
</style>
	<div class="home">
		<div class="home_slider_container">
			<div class="owl-carousel owl-theme home_slider">
				
				<!-- Slide -->
				<div class="slide">
					<div class="background_image" style="background-image:url(images/index_1.jpg)"></div>
					<div class="home_container">
						<div class="container">
							<div class="row">
								<div class="col">
									<div class="home_content text-center">
										<div class="home_title">Hotel Booking</div>
										<div class="booking_form_container">
											<?php
												if(isset($_GET['message'])){

													if($_GET['message'] ==1){
														$message = '<p class="text-danger">Please Inter valid rooms no.</p>';
													}elseif($_GET['message'] ==2){
														$message = '<p class="text-danger">Adult and Children total member should be lessthan 9</p>' ;
													}elseif($_GET['message'] ==3){
														$message = '<p class="text-danger">you can only search hotels in 30 days diffrence</p>' ;
													}else{
														$message = '';
													}
													echo $message ;
													
												}
											?>
											<form action="checkavailable.php" class="booking_form" method="get">
					 							<div class="d-flex flex-xl-row flex-column align-items-start justify-content-start" style=" margin-bottom:20px;">
													<div class="booking_input_container d-flex flex-lg-row flex-column align-items-start justify-content-start">
															<div id="">
															  <select style="height: 54px;text-align: center;"class="form-control booking_input booking_input_a booking_in" name="selectCountryName" id="selectCountryName" required="required" >
															  	<!-- <option value="MIA">Miami Area - FL</option> -->
															    <option value="hh" >Select Country</option>
															     <?php 
															     	include("api/getCountryApi.php");
															     	echo $countryOption ;
															     ?>
															  </select>
														</div>
													</div>
													</div>
													<div class="d-flex flex-xl-row flex-column align-items-start justify-content-start">
													<div class="booking_input_container d-flex flex-lg-row flex-column align-items-start justify-content-start">
														
														<div class="cityAppendDiv">
															<select style="height: 54px;text-align: center;" class="form-control booking_input booking_input_a booking_in" name="selectCityName" id="selectCityName" required="required">
																<option value="MIA">Miami Area - FL</option>
															</select>
														</div>
														<div>
															<input type="text"  class=" datepicker booking_input booking_input_a booking_in" name="check_in" placeholder="Check in" required="required"  autocomplete="off">
														</div>
														<div>
															<input type="text"  class="datepicker booking_input booking_input_a booking_out"  name="check_out" placeholder="Check out" required="required" autocomplete="off">
														</div>
														<div>
															<input type="number" class="booking_input booking_input_b" placeholder="Children" required="required"  name="child_no" id="child_no" >
														</div>
														<div>
															<input type="number" class="booking_input booking_input_b" placeholder="Adult"  value="" name="adult_no" id="adult_no" required="required">
														</div>
														<div>
															<input type="number" class="booking_input booking_input_b" placeholder="Room"  value="" name="roomBook" id="roomBook" required="required">
														</div>
													</div>
													<div><button id="booking_Search" class="booking_button trans_200">Book Now</button></div>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="styles/bootstrap-4.1.2/bootstrap.min.js"></script>

<script src="plugins/OwlCarousel2-2.3.4/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/colorbox/jquery.colorbox-min.js"></script>
<script src="js/custom.js"></script>

<script type="text/javascript">

	 
	 
	 $('#selectCountryName').change(function() {
	    //console.log($(this).val())
	    var selectCountry = $(this).val() ;
	    $.ajax({
	    	type:'POST',
	    	data:{country:selectCountry},
	    	url:'http://localhost/hotelbooking/api/getCityApi.php',
	    	cache: false,
	    	success:function(data){
	    		 
	    		var appendData = '<select style="height: 54px;text-align: center;"class="form-control booking_input booking_input_a booking_in" name="selectCityName" id="selectCityName" required="required" >'+data+'</select>';
	    		console.log(appendData);
	    		$(".cityAppendDiv").text('');
	    		$(".cityAppendDiv").append(appendData);
	    	} 
	    });
	});

	 $(document).ready(function(){
		 	$.ajax({
		    	type:'POST',
		    	data:{country:'US'},
		    	url:'http://localhost/hotelbooking/api/getCityApi.php',
		    	cache: false,
		    	success:function(data){
		    		var appendData = '<select style="height: 54px;text-align: center;"class="form-control booking_input booking_input_a booking_in" name="selectCityName" id="selectCityName" required="required" >'+data+'</select>';
		    		console.log(appendData);
		    		$(".cityAppendDiv").text('');
		    		$(".cityAppendDiv").append(appendData);
		    	} 
		    });
		});
</script>

</body>
</html>