<?php

require_once 'config.php';

if (isset($_POST['employee_id'])) {

    $employee_id = $_POST['employee_id'];
    $data = json_decode(file_get_contents("php://input"));
    $delete = "DELETE FROM login WHERE employee_id='$employee_id'";
//        var_dump($delete);
    if (mysqli_query($con, $delete)) {
        echo 'Data Deleted';
    } else {
        echo 'Something Goes Wrong';
    }
}
?>
