<?php
require_once 'config.php';
// check username or password from database
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$first_name = $request->first_name;
$password = $request->password;
$qry = mysqli_query($con,"SELECT * FROM `login` WHERE `first_name` ='$first_name' and `password` = '$password'");
$row = mysqli_num_rows($qry);
if ($row > 0) {
   echo "1";
} else {
    echo"0";
}

?>

 
