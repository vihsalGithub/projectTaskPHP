var app = angular.module('angularPostPHP', ['ngCookies']);
app.controller('loginCtrl', function ($scope, $http, $cookies) {
    // Retrieving a cookie
    $scope.signup = function () {
        window.location = 'signup.html';
    };
    $scope.login = function () {
        var request = $http({
            method: "post",
            url: "login.php", 
            data: {
                first_name: $scope.first_name,
                password: $scope.password
            },
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        });
        /* Successful HTTP post request or not */
        request.success(function (data) {
            $cookies.put('first_name', $scope.first_name);
            if (data == 1) {
                    window.location = 'home.html';
            } else {
                $scope.responseMessage = "E-mail or Password is incorrect";
            }
        });
    };
});