
<?php

include("config.php");
$postdata = file_get_contents("php://input");
$data = json_decode($postdata);

$employee_id = $data->employeeid;
$first_name = $data->firstname;
$last_name = $data->lastname;
$email = $data->email;

$query ="UPDATE login SET first_name = '$first_name', last_name = '$last_name', email = '$email' WHERE employee_id = '$employee_id'";
if(mysqli_query($con, $query)){
  echo 'Data Updated....';
}else{
  echo 'Something goes wrong....';
}
