<?php
require_once 'config.php';
$postdata = file_get_contents("php://input");
$data = json_decode($postdata);
$first_name = $data->first_name;
$last_name = $data->last_name;
$email = $data->email;
$password = $data->password;
$result = mysqli_query($con,"insert into login(first_name,last_name,email,password) values('$first_name','$last_name','$email','$password')");
//var_dump($result);
if ($result > 0) {
   echo "1";
} else {
    echo"0";
}

