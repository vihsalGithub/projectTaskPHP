
<?php

include("config.php");
header('Content-Type: application/json');
$result = mysqli_query($con, "select * from login");
$json = array();
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_array($result)) {
        $employee_id = $row['employee_id'];
        $first_name = $row['first_name'];
        $last_name = $row['last_name'];
        $email = $row['email'];
        $data = array("employee_id" => $employee_id, "first_name" => $first_name, "last_name" => $last_name, "email" => $email);
        array_push($json, $data);
    }
    echo json_encode(array("Data" => $json));
}

mysqli_close($con);
