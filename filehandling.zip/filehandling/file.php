
<!DOCTYPE html>
<html lang="en">
<head>
  <title>File Handling</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {height: 450px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      padding-top: 20px;
      background-color: #f1f1f1;
      height: 100%;
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height:auto;} 
    }
  </style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Projects</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
    </div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <div class="row content" style="padding-bottom:50px;">
    <div class="col-sm-2 sidenav">
      <p><a href="#">Link</a></p>
      <p><a href="#">Link</a></p>
      <p><a href="#">Link</a></p>
    </div>
    <div class="col-sm-8 text-left" style="padding-bottom:50px;"> 
      <h1>Welcome</h1>
      <?php
 $file = "json.php" ;
$myfile = fopen($file, "r") or die("Unable to open file!");
$x = fread($myfile,filesize($file));
$array =   json_decode($x);
//echo '<pre>';
//print_r($array->Employees);
//echo   count($array->Employees);
echo '<table class="table ">
		<th>
			<td>jobTitleName</td>
			<td>firstName</td>
			<td>lastName</td>
		</th>';
  foreach ($array->Employees as $key => $value) {
	echo'<tr>
			<td>'.$value->userId.'</td>
			<td>'.$value->jobTitleName.'</td>
			<td>'.$value->firstName.'</td>
			<td>'.$value->lastName.'</td>
		</tr>';
  }
 echo '</table>';

echo '<div class="col-md-8 col-md-offset-2">' ;
 echo '<form  id="formsubmit" method="post">
		  <div class="form-group">
		    <label for="email">User Id</label>
		    <input type="text" class="form-control" id="userid" required name="userid">
		  </div>
		  <div class="form-group">
		    <label for="email">Job title</label>
		    <input type="text" class="form-control" id="jobtitle" required name="jobtitle">
		  </div>

		  <div class="form-group">
		    <label for="pwd">First Name:</label>
		    <input type="text" class="form-control" id="fname" required  name="fname">
		  </div>
		  <div class="form-group">
		    <label for="pwd">Last name:</label>
		    <input type="text" class="form-control" id="lname" required name="lname">
		  </div>
		  
		  <button type="submit" id="formBtn" name="formBtn" class="btn btn-default">Submit</button>
		</form>';
echo '</div>';
fclose($myfile);

?>
    </div>
    <div class="col-sm-2 sidenav">
      <div class="well">
        <p>ADS</p>
      </div>
      <div class="well">
        <p>ADS</p>
      </div>
    </div>
  </div>
</div>

<footer class="container-fluid text-center">
  <p>Footer Text</p>
  <script>
  	$("#formBtn").click(function(){
  	  //	e.preventDefault();
  	  	var userid = $("#userid").val();
  	  	var jobtitle = $("#jobtitle").val();
  	  	var fname = $("#fname").val();
  	  	var lname = $("#lname").val();
  	  	$.ajax({
		    type : 'POST',
		    url : 'ajax.php',
/*		    data : {'userid':userid,'jobtitle':jobtitle,'fname':fname,'lname':lname} ,*/
		    data : $('#formsubmit').serialize() ,
		    success:function(result){
                 alert(result);
                console.log(result);
             }
  	  	});
  	});

  </script>
</footer>

</body>
</html>


