<?php
//echo "ajax";
//$array = $_REQUEST["userid"] ;
 //echo $_POST['userid'] ;
 /*$userid = $_POST['userid']; 
	$jobtitle = $_POST['jobtitle'];
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];

	$arrayLastElement = array(
				'userId'=> $userid ,
				'jobTitleName'=> $jobtitle , 
				'firstName'=> $fname ,
				'lastName'=> $lname ,
			) ;
    echo json_encode($arrayLastElement) ;*/
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
	$userid = $_POST['userid'];
	$jobtitle = $_POST['jobtitle'];
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];

	$arrayLastElement = array(
				'userId'=> $userid ,
				'jobTitleName'=> $jobtitle ,
				'firstName'=> $fname ,
				'lastName'=> $lname ,
			) ;


	$file = "json.php" ;
	$myfile = fopen($file, "r") or die("Unable to open file!");
	$x = fread($myfile,filesize($file));
	$array =   json_decode($x);
	$myobject = arrayToObject($arrayLastElement);
	array_push($array->Employees,$myobject);
	$data['Employees'] = $array->Employees ;
	$josn = json_encode($data) ;


	$myfile = fopen("json.php", "w") or die("Unable to open file!");
		if(fwrite($myfile, $josn)){
			echo "write success fully";
		}
		fclose($myfile);
	
}else{
	echo "hello";
}


function array_to_obj($array, &$obj)
{
	foreach ($array as $key => $value)
	{
	  if (is_array($value))
	  {
	  $obj->$key = new stdClass();
	  array_to_obj($value, $obj->$key);
	  }
	  else
	  {
	    $obj->$key = $value;
	  }
	}
	return $obj;
}
function arrayToObject($array)
{
	 $object= new stdClass();
	 return array_to_obj($array,$object);
}
