<?php


if(isset($_POST['submit_form'])){
	$user_email = $_POST['user_email'];
	if(empty($user_email)){
		$user_email = "vishal.sharma@vitwebdevelopment.com";
	}
	$user_password = $_POST['user_password'];
	if(empty($user_password)){
		$user_password = "Vishal@#123";
	}



	$from_email = $_POST['from_email'];
	if(empty($from_email)){
		$from_email = "info@vitwebdevelopment.com";
	}
	$from_name = $_POST['from_name'];
	if(empty($from_name)){
		$from_name = "VIT Web Devloment";
	}



	$user_subject = $_POST['user_subject'];
	if(empty($user_subject)){
		$user_subject = "VIT Web Devloment";
	}



	$multiple_email_check = $_POST['multiple_email_check'];

  	
	$email_sent_to = $_POST['email_sent_to'];
	if(empty($email_sent_to)){
		$email_sent_to = "vishalsharma.developer@gmail.com";
	}

	$messageBody = $_POST['message'];
	if(empty($messageBody)){
		$messageBody = "";
	}
}


require("class.phpmailer.php");
$mail = new PHPMailer();
$mail->IsSMTP();
$mail->Host = "vitwebdevelopment.com";
$mail->SMTPAuth = true;
$mail->Port = 587;
$mail->Username = $user_email;
$mail->Password = $user_password ;
$mail->From = $from_email;
$mail->FromName = $from_name ;


$multiple_email_check ;

if($multiple_email_check ==2){
	$sendEmailArray = explode(',', $email_sent_to);
  	$size = sizeof($sendEmailArray); //die;
  	//print_r($sendEmailArray) ; die;
  	for($i=0;$i<=$size ;$i++){
  		$mail->AddAddress($sendEmailArray[$i]);
		//echo $sendEmailArray[$i] ;
		$mail->IsHTML(true);
		$mail->Subject = $user_subject;
		$mail->Body = $messageBody;
  	}
}else{
	$mail->AddAddress($email_sent_to);
	$mail->IsHTML(true);
	$mail->Subject = $user_subject;
	$mail->Body = $messageBody;
}


$mail->AddReplyTo($from_email);



if(!$mail->Send()){
/*echo "Message could not be sent. <p>";
echo "Mailer Error: " . $mail->ErrorInfo;*/
$redirectUrl = "emailform.php?message=0";
	header('Location:emailform.php?message=0');
	exit;
}else{
	$redirectUrl = "emailform.php?message=1";
	header('Location:emailform.php?message=1');
	echo "email is sent" ;
}

?>  