<!DOCTYPE html>
<html lang="en">
<head>
  <title>Email Mailer Script</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

</head>
<body>

<div class="container">
      <div class="row">
    <div class="col-md-6 col-md-offset-3" id="form_container">
        <h2>Emial Sender</h2>
        <p>
           Please send your message below. We will get back to you at the earliest!
        </p>
        <form role="form" method="post" id="reused_form" action="emailsubmit.php">

            <div class="row">
                <div class="col-sm-12 form-group">
                        <?php
                            if(isset($_GET['message'])){
                                if($_GET['message']==1){
                                    echo '<div class="alert alert-success fade in alert-dismissible" style="margin-top:18px;">
                                            <a href="emailform.php" class="close" >×</a>Email sent succefully
                                        </div>';
                                }else{
                                    echo '<div class="alert alert-danger fade in alert-dismissible" style="margin-top:18px;">
                                            <a href="emailform.php" class="close" >×</a>Something went wrong
                                        </div>';
                                }
                            }
                        ?>
                </div>
                
            </div>

            <div class="row">
                <div class="col-sm-6 form-group">
                    <label for="name">
                        User Email:</label>
                    <input type="text" class="form-control" id="user_email" name="user_email" required value="vishal.sharma@vitwebdevelopment.com">
                </div>
                <div class="col-sm-6 form-group">
                    <label for="email">
                        Password:</label>
                    <input type="password" class="form-control" id="user_password" name="user_password" required value="Vishal@#123">
                </div>
            </div>

            <div class="row">
                <div class="col-sm-6 form-group">
                    <label for="name">
                        From:</label>
                    <input type="email" class="form-control" id="from_email" name="from_email" required value="info@vitwebdevelopment.com">
                </div>
                <div class="col-sm-6 form-group">
                    <label for="email">
                        From Name:</label>
                    <input type="text" class="form-control" id="from_name" name="from_name" required value="VIT Web Devloment">
                </div>
            </div>




            <div class="row">
                <div class="col-sm-12 form-group">
                    <label for="name">
                        Subject:</label>
                    <input type="text" class="form-control" id="user_subject" name="user_subject" required value="VIT Web Devloment">
                </div>
            </div>


            <div class="row">
                <div class="col-sm-12 form-group"><b>Check Form Multiple Email:</b></div>
                <div class="col-sm-6 form-group">
                    <label for="name" style="font-weight: normal;">Single Email:</label>
                    <input type="radio"  name="multiple_email_check"  value="1"  >
                </div>
                <div class="col-sm-6 form-group">
                    <label for="name"  style="font-weight: normal;">Multiple Email:</label>
                    <input type="radio" name="multiple_email_check" checked="checked"  value="2">
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12 form-group">
                    <label for="name">
                        Email Send to:</label>
                    <input type="text" class="form-control" id="email_sent_to" name="email_sent_to" required value="vishalsharma.developer@gmail.com,kamalkishorbodana01@gmial.com,manoj.vds1@gmail.com">
                </div>
            </div>

            <?php
            include("emailbody.php") ;
            ?>
            <div class="row">
                <div class="col-sm-12 form-group">
                    <label for="message">
                        Message:</label>
                    <textarea class="form-control" type="textarea" name="message" id="message" maxlength="6000" rows="7" value="<?php echo $emailbody ;?>"></textarea>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12 form-group">
                    <button type="submit" class="btn btn-lg btn-default pull-right" name="submit_form" id="submit_form" >Send →</button>
                </div>
            </div>

        </form>

        <div id="success_message" style="width:100%; height:100%; display:none; ">
            <h3>Posted your message successfully!</h3>
        </div>
        <div id="error_message"
                style="width:100%; height:100%; display:none; ">
                    <h3>Error</h3>
                    Sorry there was an error sending your form.

        </div>
    </div>
</div
</div>

</body>
</html>
