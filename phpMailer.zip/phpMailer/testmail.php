<?php


$emailbody = '<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title>email</title>
</head>
<body style="font-family:Arial, Helvetica, sans-serif">
<div class="top-hading" style="text-align:center; padding:10px 0px;">
<a href="#" style="font-size:14px; color:#000; text-decoration:none;">VIEW THIS EMAIL ONLINE</a></div>

<div class="full-page-mode" style="width:600px; margin:0px auto; background-color:#fff; height:800px;">

<div class="logo-block" style="text-align:center; padding:10px 0px; background-color: rgba(0,0,0,.8)">
<img src="http://vitwebdevelopment.com/DEMO/promostions-email/img/vit_logo.png" alt="logo" style="width:150px;">
</div>

<table align="center">
<tbody>
<tr>
<td>
<ul style="width:100%; text-align:center; padding:0px;">
<li style="float:left; list-style:none; margin:0px 5px; font-size:14px;">
<a href="http://vitwebdevelopment.com/" style="text-decoration:none; color:#000; border-left: 2px solid #00ccfc; padding: 0px 10px;">HOME</a></li>

<li style="float:left; list-style:none; margin:0px 5px; font-size:14px;">
<a href="http://vitwebdevelopment.com/services/" style="text-decoration:none; color:#000; border-left: 2px solid #00ccfc; padding: 0px 10px;">SERVICES</a></li>

<li style="float:left; list-style:none; margin:0px 5px; font-size:14px;">
<a href="http://vitwebdevelopment.com/portfolio/" style="text-decoration:none; color:#000; border-left: 2px solid #00ccfc; padding: 0px 10px;">PORTFOLIO</a></li>

<li style="float:left; list-style:none; margin:0px 5px; font-size:14px;">
<a href="http://vitwebdevelopment.com/enquiry/" style="text-decoration:none; color:#000; border-left: 2px solid #00ccfc; padding: 0px 10px;">ENQUIRY</a></li>

<li style="float:left; list-style:none; margin:0px 5px; font-size:14px;">
<a href="http://vitwebdevelopment.com/contact-us/" style="text-decoration:none; color:#000; border-left: 2px solid #00ccfc;; padding: 0px 10px;">CONTACT US</a></li>

</ul>

</td>
</tr>

<tr>
<td style="text-align:center; padding:20px 0px;">
<img src="http://vitwebdevelopment.com/DEMO/promostions-email/img/Web-Development.png" alt="img" width="500px;">
</td>
</tr>
</tbody>
</table>
<table>
<tbody style="box-shadow: 0px 1px 2px rgba(0,0,0,0.4);">
<h1 style="text-align:center; font-size:24px; background-color:#01a1d8; padding:10px 0px; color:#fff; margin:10px 0px;">OUR WORK</h1>
<tr>
<td style="text-align:center; width:50%;">
<a href="https://www.planteshop.dk/"><img src="http://vitwebdevelopment.com/DEMO/promostions-email/img/magento-website.png" alt="img" style="width:95%;"></a>
</td>

<td style="width:50%; padding: 10px 20px;">
<h3 style="color: #F76B44;">MAGENTO</h3>
<p style="font-size:14px; color:#3c3a3a;">VIT Web Development provides  Magento development services   For Small as well as large business. We hold expertise in the field of Magento design and development, offering an array of e-commerce solutions for an interactive shopping website that cover all needs of their business such as promotions, shipping, merchandising and payments.</p>
<a href="http://vitwebdevelopment.com/services/magento-development/" style="text-decoration:none; background-color:#01a1d8; color:#fff; padding:7px 7px; font-size:12px;
border-radius:5px;">READ MORE</a>
</td>
</tr>
</tbody>
</table>
<table>
<tbody style="box-shadow: 0px 1px 2px rgba(0,0,0,0.4);">
<tr>
<td style="width:50%; padding: 10px 20px;">
<h3 style="color: #016794;">WORDPRESS</h3>
<p style="font-size:14px; color:#3c3a3a;">VIT Web Development is a certified WordPress development company in India. We offer a Development and Designing that you can maintain easily including its content, images, multimedia and other crucial data. Our WordPress Developers take a templates and transform it into a customized websites according to your Business needs.</p>
<a href="http://vitwebdevelopment.com/services/website-developement/wordpress-development/" style="text-decoration:none; background-color:#01a1d8; color:#fff; padding:7px 7px; font-size:12px;
border-radius:5px;">READ MORE</a>
</td>
<td style="text-align:center; width:50%;">
<a href="http://hometeches.com/"><img src="http://vitwebdevelopment.com/DEMO/promostions-email/img/wordpress-website.png" alt="img" style="width:95%;"></a>
</td>
</tr>
</tbody>
</table>
<table>
<tbody style="box-shadow: 0px 1px 2px rgba(0,0,0,0.4);">
<tr>
<td style="text-align:center; width:50%;">
<a href="https://www.selectacoin.com/"><img src="http://vitwebdevelopment.com/DEMO/promostions-email/img/prestasope-website.png" alt="img" style="width:95%;"></a>
</td>
<td style="width:50%; padding: 10px 20px;">
<h3 style="color: #525453;">PRESTASHOP</h3>
<p style="font-size:14px; color:#3c3a3a;">VIT Web Development is one of the fastest growing PrestaShop Development Company   in India with satisfied client base.We offer quality and modern Prestashop template design features that allow you to customize your website without having to pay the large amount of fees. PrestaShop Development  provides unique and fully-functional store for your business needs. It is the best open source ecommerce solution for online business owners worldwide.</p>
<a href="http://vitwebdevelopment.com/e-commerce-development-service/prestashop-development/" style="text-decoration:none; background-color:#01a1d8; color:#fff; padding:7px 7px; font-size:12px;
border-radius:5px;">READ MORE</a>
</td>
</tr>
</tbody>
</table>
<table>
<tbody style="box-shadow: 0px 1px 2px rgba(0,0,0,0.4);">
<tr>
<td style="width:50%; padding: 10px 20px;">
<h3 style="color: #f23e39;">JOOMLA</h3>
<p style="font-size:14px; color:#3c3a3a;">Today, Joomla is used universally to power almost every type of Website, from simple, to large business website like social networking website, e-commerce store, community website job & recruitment boards or online forums. Our Experienced Joomla development team create powerful  Joomla websites & applications that can helps you to increase your business effectively.</p>
<a href="http://vitwebdevelopment.com/services/website-developement/joomla-development/" style="text-decoration:none; background-color:#01a1d8; color:#fff; padding:7px 7px; font-size:12px;
border-radius:5px;">READ MORE</a>
</td>

<td style="text-align:center; width:50%;">
<a href="http://www.admissionsoverseas.com/"><img src="http://vitwebdevelopment.com/DEMO/promostions-email/img/joomla-website.png" alt="img" style="width:95%;"></a>
</td>

</tr>
</tbody>
</table>



<table>
<tbody style="box-shadow: 0px 1px 2px rgba(0,0,0,0.4);">
<tr>
<td style="text-align:center; width:50%;">
<a href="http://www.vinsani.com/"><img src="http://vitwebdevelopment.com/DEMO/promostions-email/img/php-wesite.png" alt="img" style="width:95%;"></a>
</td>
<td style="width:50%; padding: 10px 20px;">
<h3 style="color: #6380b3;">PHP</h3>
<p style="font-size:14px; color:#3c3a3a;">PHP is an open-source server-side scripting language designed for Web development to produce dynamic web pages. It is one of the first developed scripting languages to be embedded into an HTML source document rather than calling an external file to process data.
Adopting the best technology frameworks and methodologies, PHP solutions offered by VIT Web Development offer highly professional and sophisticated development services</p>
<a href="http://vitwebdevelopment.com/services/website-developement/php-development/" style="text-decoration:none; background-color:#01a1d8; color:#fff; padding:7px 7px; font-size:12px;
border-radius:5px;">READ MORE</a>
</td>
</tr>
</tbody>
</table>


<table>
<tbody style="box-shadow: 0px 1px 2px rgba(0,0,0,0.4);">
<tr>
<td style="width:50%; padding: 10px 20px;">
<h3 style="color: #ee4323;">CODEIGNITER</h3>
<p style="font-size:14px; color:#3c3a3a;">PHP is an open-source server-side scripting language designed for Web development to produce dynamic web pages. It is one of the first developed scripting languages to be embedded into an HTML source document rather than calling an external file to process data.
Adopting the best technology frameworks and methodologies, PHP solutions offered by VIT Web Development offer highly professional and sophisticated development services</p>
<a href="#" style="text-decoration:none; background-color:#01a1d8; color:#fff; padding:7px 7px; font-size:12px;
border-radius:5px;">READ MORE</a>
</td>
<td style="text-align:center; width:50%;">
<a href="https://www.mediafalcon.com/"><img src="http://vitwebdevelopment.com/DEMO/promostions-email/img/ci-website.png" alt="img" style="width:95%;"></a>
</td>
</tr>
</tbody>
</table>
<div class="visit-info" style="width:100%; padding:10px 0px; text-align:center;">
<a href="http://vitwebdevelopment.com/portfolio/" style="color: #01a1d8; text-decoration:none; font-size:16px; font-weight:bold;">VISIT OUR PORTFOLIO FOR MORE DETAILS</a>
</div>
<table width="100%" style="background-color:rgba(0,0,0,.8); margin-top:10px;">
<tbody style="box-shadow: 0px 1px 2px rgba(0,0,0,0.4);">
<tr>
<td width="33%" style="padding:0px 10px;">
<h4 class="widget-title" style="font-size:13px; text-align:left; color: #01a1d8;">ECOMMERCE DEVELOPMENT</h4>
<div class="menu-ecommerce-development-container"><ul id="menu-ecommerce-development" class="menu" style="padding:0px; list-style:none;"><li id="menu-item-168" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-168"><a href="http://vitwebdevelopment.com/e-commerce-development-service/prestashop-development/" style="text-decoration:none; font-size:13px; color:#fff;">PrestaShop Development</a></li>
<li id="menu-item-169" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-169"><a href="http://vitwebdevelopment.com/e-commerce-development-service/oscommerce-development/" style="text-decoration:none; font-size:13px; color:#fff;">OsCommerce Development</a></li>
<li id="menu-item-170" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-170"><a href="http://vitwebdevelopment.com/e-commerce-development-service/opencart-development/" style="text-decoration:none; font-size:13px; color:#fff;">OpenCart Development</a></li>
<li id="menu-item-171" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-171"><a href="http://vitwebdevelopment.com/services/magento-development/" style="text-decoration:none;font-size:13px; color:#fff;">Magento Development</a></li>
</ul></div>
</td>
<td width="33%" style="padding:0px 10px;">
<h4 class="widget-title" style="font-size:13px; text-align:left; color: #01a1d8;">WEB DEVELOPMENT SERVICES</h4>
<div class="menu-web-development-services-container"><ul id="menu-web-development-services" class="menu" style="padding:0px;
list-style:none;"><li id="menu-item-174" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-174"><a href="http://vitwebdevelopment.com/services/website-developement/" style="text-decoration:none; font-size:13px; color:#fff;">Web Development</a></li>
<li id="menu-item-173" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-173"><a href="http://vitwebdevelopment.com/services/website-developement/php-development/" style="text-decoration:none; font-size:13px; color:#fff;">PHP Development</a></li>
<li id="menu-item-172" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-172"><a href="http://vitwebdevelopment.com/services/website-developement/joomla-development/" style="text-decoration:none; font-size:13px; color:#fff;">Joomla Development</a></li>
<li id="menu-item-175" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-175"><a href="http://vitwebdevelopment.com/services/website-developement/wordpress-development/" style="text-decoration:none; font-size:13px; color:#fff;">WordPress Development</a></li>
</ul></div>
</td>
<td width="33%" style="padding:0px 10px;">
<h4 class="widget-title" style="font-size:13px; text-align:left; color: #01a1d8;">MORE ABOUTS</h4>
<div class="menu-footer_menu-container"><ul id="menu-footer_menu" class="menu" style="padding:0px; list-style:none;">
<li id="menu-item-162" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-162"><a href="http://vitwebdevelopment.com/about-us/" style="text-decoration:none; font-size:13px; color:#fff;">About Us</a></li>
<li id="menu-item-166" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-89 current_page_item menu-item-166"><a href="http://vitwebdevelopment.com/portfolio/" style="text-decoration:none; font-size:13px; color:#fff;">Portfolio</a></li>
<li id="menu-item-1416" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1416"><a href="http://vitwebdevelopment.com/services/" style="text-decoration:none; font-size:13px; color:#fff;">Services</a></li>
<li id="menu-item-165" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-165"><a href="http://vitwebdevelopment.com/contact-us/" style="text-decoration:none; font-size:13px; color:#fff;">Contact Us</a></li>
</ul></div>
</td>
</tr>
</tbody>
</table>
<div class="contact-mail" style="width:100%; background-color:#000; color:#fff; float:left; padding-bottom:10px;">
<span style="font-size:12px; padding:5px 0px 0px 5px; width:100%; float:left;"><span><img src="http://vitwebdevelopment.com/DEMO/promostions-email/img/skype-icon.png" alt="img" style="width:20px;position: relative;top: 6px;background: #fff;border-radius: 50%;margin: 0px 5px;"></span> :manoj.vds1,amitmishra2u,anyphpwork</span>
<span style="font-size:12px; padding:0px 0px 0px 5px; width:100%; float:left; "><span><img src="http://vitwebdevelopment.com/DEMO/promostions-email/img/mail-icon.png" alt="img" style="width:20px;position: relative;top: 6px;background: #fff;border-radius: 50%;margin: 0px 5px;  "></span> manoj.vds1@gmail.com , amitmishra2u@gmail.com , vitwebdevelopment@gmail.com</span>
</div>
</div>
</body>
</html>';



echo $emailbody ; die;








require("class.phpmailer.php");
$mail = new PHPMailer();

$mail->IsSMTP();
$mail->Host = "vitwebdevelopment.com";

$mail->SMTPAuth = true;
//$mail->SMTPSecure = "ssl";
$mail->Port = 587;
/*$mail->Username = "vishal.sharma@vitwebdevelopment.com";
$mail->Password = "Vishal@#123";*/

$mail->Username = "vishal.sharma@vitwebdevelopment.com";
$mail->Password = "Vishal@#123";

$mail->From = "vishal.sharma@vitwebdevelopment.com";
$mail->FromName = "VIT Web Devloment";

$mail->AddAddress("vishalsharma.developer@gmail.com");
$mail->AddReplyTo("vishalsharma.developer@gmail.com");
$mail->IsHTML(true);
include("emailbody.php") ;
//echo $emailbody ; die;
$mail->Subject = "VIT Web Devloment";
$mail->Body = $emailbody; 

//echo $emailbody ; die;
//$mail->AltBody = "This is the body in plain text for non-HTML mail clients";

if(!$mail->Send())
{
echo "Message could not be sent. <p>";
echo "Mailer Error: " . $mail->ErrorInfo;
exit;
}

print_r($mail->ErrorInfo);

echo "Message has been sent";

?>